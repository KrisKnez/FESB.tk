#include"asmc.c"

VAR string DB(100);
VAR prompt DB(14) = "Unesi string:";

PROC_DECL(STR2UPPER)   /* deklariranje procedura*/ 
PROC_DECL(TOUPPER)      

PROC(MAIN)             /* glavna procedura */
   PUTS(prompt)
   GETS(string)        /* dobavi string           */ 
   LEA(eax,string)     /* adresa stringa u eax    */
   PUSH(eax)           /* stavi argument na stog  */ 
   CALL(STR2UPPER)     /* pretvori u velika slova */
   ADD(esp,4)          /* o�isti stog             */
   PUTS(string)        /* ispi�i string           */  
   PUTC(10)
   RET(0)
ENDP

PROC(TOUPPER)                    /* char TOUPPER(char)   */    
	MOVZX(eax, BYTE(M_[esp+4]))  /* dobavi znak sa stoga */
    CMP(eax, 'a')                /* usporedi s 'a'       */ 
	JL(kraj)                     /* ako je manji, zavr�i */
	CMP(eax, 'z')                /* usporedi s 'z'       */ 
	JG(kraj)                     /* ako je ve�i zavr�i   */
	SUB(eax, 'a')                /* pretvori malo slovo  */
    ADD(eax, 'A')                /* u veliko slovo       */  
kraj:                            /* rezultat u eax       */    
    RET(0)
ENDP

PROC(STR2UPPER)                  /* void STR2UPPER(char *)  */
	PUSH(ebp)
	MOV(ebp,esp)	
    MOV(ebx, DWORD(M_[ebp+8]))   /* adresa stringa u ebx    */
	MOV(edi,0)                   /* broja� petlje i=0       */
start:
    MOVZX(eax, BYTE(M_[ebx+edi]))/* dobavi znak s[i]        */
	CMP(eax,0)                   /* ako je kraj stringa     */
	JE(kraj)	                 /* zavr�i pelju, ina�e     */ 
	PUSH(eax)                    /* stavi znak kao argument */
	CALL(TOUPPER)                /* pretvori u velika slova */
	ADD(esp,4)
    MOV(BYTE(M_[ebx+edi]), eax)	 /* ponovo zapi�i znak      */
	INC(edi)	  	             /* i++                     */
	JMP(start)                   /* ponovi petlju           */   
kraj:	
	POP(ebp)
    RET(0)
ENDP

