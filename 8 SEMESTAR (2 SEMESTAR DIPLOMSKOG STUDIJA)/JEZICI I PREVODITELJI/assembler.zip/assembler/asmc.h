#ifndef _C_ASM_INTEL_
#define _C_ASM_INTEL_

#include  <stdio.h>

/*****************************************************************************/
/*  ASMC - SIMULATOR ASEMBLERA ZA HIPOTETI�KI 32-bitni INTEL-ov PROCESOR     */
/*****************************************************************************/

typedef unsigned char  Byte;
typedef unsigned short Word;
typedef unsigned int   DWord;

#define WSIZE sizeof(Word)
#define DWSIZE sizeof(DWord)

/* memorija za stog */
#define STACK_SIZE 65536

extern Byte _STACK[];
extern DWord eax, ebx, edx, ecx, edi, esi, ebp, esp;

/* registar stanja */
struct flagreg {
	unsigned Z:1;
	unsigned S:1;
};
extern struct flagreg FLAG;

extern char * M_;

/*****************************************************************************/
/*  Pretvorba tipa i dobava adrese                                           */
/*****************************************************************************/
/* Va�no: sve globalne varijable su reference niza bajta, �ak i za 1 znak */

/*Dobava vrijednosti elementa niza x[n] ili registra*/
#define DWORD(x) (*((DWord *)&(x)))  
#define WORD(x)  (*((Word *) &(x)))  
#define BYTE(x)  (*((Byte *) &(x)))

/* adresa reference ili elementa niza ili registra*/
#define ADR(x)  ((DWord)&(x))
/* ili microsoft naziv */
#define OFFSET(x)  ADR(x)

/* Makro za podjelu DWord u 4 bajta - little endian format */
#define D_(i) (Byte)(i),(Byte)((unsigned)(i)>>8),\
	          (Byte)((unsigned)(i)>>16),(Byte)((unsigned)(i)>>24)
/* Makro za podjelu Word u 2 bajta - little endian format */
#define W_(i) (Byte)(i),(Byte)((unsigned)(i)>>8)

/****************************************************************************/
/* Definiranje globalnih (i externih) varijabli - sve tipa Byte[]                           */
/****************************************************************************/
#define VAR  Byte
#define PUBLIC  
#define PRIVATE static
#define EXTERN  extern 

#define DB(n) [n]
#define DW(n) [n*2]
#define DD(n) [n*4]

/* Primjer:  
 * Definira niz bajta koji mo�e sadr�avati s 3 DWord
 *  VAR x DD(3);    
 * Inicijalizira niz bajta s 3 DWORD:23,11,55769
 *  VAR x DD(3) = {D_(23), D_(11),  D_(55769)};  
 * Inicijalizira string  Byte x[6]= "hello" 
 *  VAR s DB(6) = "hello";   
 * Inicijalizira znak c  na vrijednost {'\n'} 
 *  VAR c DB(1) = {'\n'};    
*/

/*****************************************************************************/
/*  PODSKUP INSTRUKCIJA PENTIUM PROCESORA                                    */
/*****************************************************************************/
/* korist se kratica: r-registar, m-memorija, i-cjelobrojna konstanta

/* Rad sa stogom - stog se puni prema ni�im adresama u inkrementu od DWSIZE*/
#define PUSH(rm)	  esp -= DWSIZE; *(DWord *)esp= (DWord)(rm); 
#define POP(rm) 	  rm = *(DWord *)esp; esp += DWSIZE;

/* Dobava iz memorije/registra/konst u registar/memoriju */
#define MOV(rm,rmi)   rm = rmi;         /*MOV za signed ili unsigned DWord*/
#define MOVSX(r,rm)   r = (int)(rm);    /*MOV - sign extended za Word ili Byte*/
#define MOVZX(r,rm)   r = (DWord)(rm);  /*MOV - zero extended (unsigned) -||- */
#define LEA(r,m)      r = (DWord)&(m);  /*load effective address           */

/* Usporedba koja mijenja registar stanja (FLAG registar) */
#define CMP(r,mri)    {int tmp = (int)r - (int)(mri);\
	                  if(tmp < 0)  FLAG.S = 1; else FLAG.S = 0;\
					  if(tmp == 0) FLAG.Z = 1; else FLAG.Z = 0; }
#define TEST(r,mri)   if(r & (DWord)(mri)) FLAG.Z = 0; else FLAG.Z = 1; 

/* Skokovi: u ASMC,skokovi su dozvoljeni samo unutar potprograma 
            i samo na imenovane labele */

/* Bezuvjetni skok na label:*/
#define JMP(label)    goto label;

/* Skok na label: ovisan o stanju FLAG registra nakon CMP(op1, op2) ili TEST*/
#define JG(label)     if(!FLAG.S && !FLAG.Z) goto label;/* Greater         */
#define JL(label)     if(FLAG.S) goto label;            /* Less            */
#define JGE(label)    if(!FLAG.S || FLAG.Z) goto label; /* Greater or Equal*/
#define JLE(label)    if(FLAG.S || FLAG.Z) goto label;  /* Less of Equal   */
#define JE(label)     if(FLAG.Z) goto label;            /* Equal           */
#define JNE(label)    if(!FLAG.Z) goto label;           /* NotEqual        */
#define JZ(label)     if(FLAG.Z) goto label;            /* Zero            */
#define JNZ(label)    if(!FLAG.Z) goto label;           /* NotZero         */

/* Postavlja bajt  u r, prema  stanju FLAG registra nakon CMP(op1, op2) ili TEST*/
#define SETG(r)     if(!FLAG.S && !FLAG.Z) r |= 1;
#define SETL(r)     if( FLAG.S)            r |= 1;
#define SETGE(r)    if(!FLAG.S || FLAG.Z)  r |= 1;
#define SETLE(r)    if( FLAG.S || FLAG.Z)  r |= 1;
#define SETE(r)     if( FLAG.Z)            r |= 1;         
#define SETNE(r)    if(!FLAG.Z)            r |= 1;      
#define SETZ(r)     if( FLAG.Z)            r |= 1;
#define SETNZ(r)    if(!FLAG.Z)            r |= 1;      


/* Poziv potprograma, tzv. procedure (PUSH(-1) simulira pam�enje adrese povrata)*/
typedef void (*PFUN)(void); 
/*#define CALL(proc)    PUSH(-1); proc(); */
#define CALL(proc)    PUSH(-1); (*((PFUN)(proc)))();  

/* Deklariranje procedure */
#define PROC_DECL(proc)  void proc(void);   

/* Definiranje procedure */
#define PROC(proc)    void proc() {  

/*Povrat iz potprograma: �isti stog n-bajta + pop(adresa povrata?) */
#define RET(n) esp += DWSIZE + n;  return;  
#define ENDP }

/* Aritmeti�ke operacije */

/* Zbrajanje i oduzimanje za signed ili unsigned  */
#define ADD(mr, mri)  (mr) += (DWord)(mri);
#define SUB(mr, mri)  (mr) -= (DWord)(mri);

/* Mno�enje sa unsigned/signed tipovima*/
#define MUL(r, mri)  (r) *= (DWord)(mri);
#define IMUL(r,mri)  (int)(r) = (int)(r) * (int)(mri);

/* Dijeljenje sa unsigned/signed tipovima - samo s eax registarom*/
#define CDQ   /*pretvara double word u quad word:  eax->edx:eax - nije implementirano*/
#define DIV(mri)     edx = eax % (DWord)(mri); eax /= (DWord)(mri); 
#define IDIV(mri)    edx = (int)eax % (int)(mri); eax = (int)eax / (int)(mri); 

#define INC(mr)       ++(mr);
#define DEC(mr)       --(mr);
#define NEG(mr)       (mr) = -(int)(mr);

/* Bit zna�ajne logi�ke  operacije */
#define NOT(r)      (r) ~= (DWord)(r);
#define AND(r, mri) (r) &= (DWord)(mri);
#define OR(r,  mri) (r) |= (DWord)(mri);
#define XOR(r, mri) (r) ^= (DWord)(mri);

#define SAL(r, n)   (r) <<= n;
#define SAR(r, n)   (r) >>= n;
#define SHL(r, n)   (r) <<= n;
#define SHR(r, n)   (r) >>= n;

/******************************************************************************/
/*       standardni ulaz/izlaz  (string-S, cijeli broj-I, unsigned-U znak-C)                 */
/******************************************************************************/

/* ispis pomo�u printf funkcija - samo 1 argument*/
#define PUTS(a)  printf("%s",(char *)(a));
#define PUTI(mr) printf("%d",(int) mr);
#define PUTU(mr) printf("%u",(unsigned) mr);
#define PUTC(mr) printf("%c",(int) mr);

/* dobava podataka - samo jedan argument*/
#define GETS(a)  gets((char*)(a)); fflush(stdin);
#define GETI(mr) {int i; scanf("%d", &i); mr = i; fflush(stdin); }
#define GETU(mr) {unsigned d; scanf("%u", &d); mr = d; fflush(stdin); }
#define GETC(mr) {mr = getchar(); fflush(stdin);}
/* Mo�e se koristiti i bilo koja funkcija C jezika */
/*    ako je argument x vrijednost -> DWORD(x) ili WORD(x) ili BYTE(x) ili reg*/
/*    ako je argument x adresa -> ADR(x)*/
#endif
