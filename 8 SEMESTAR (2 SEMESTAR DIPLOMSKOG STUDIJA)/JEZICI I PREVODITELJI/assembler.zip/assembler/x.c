#include <stdio.h>

short int  x[4] = {77, 1, 22, 3}; 

int SumaNiza(int N, short int niz[])
{
   int sum;	
   while (--N >= 0) {
       sum +=  niz[N];
   }
   return sum;
}

void main()
{
  printf("Rezultat: %d", SumaNiza(4,x));
}

