
struct st {
	char ime[40] ;
	int broj;
};

struct br {
	char c ;
	int niz[10];
};

struct br hhh[10];
struct st stds[100];
int i,j, num =0;

int main()
{
	
	while(1) {
	gets(stds[num].ime);
	if(stds[num].ime[0] ==0)
		break;
	scanf("%d",stds[num].broj);
	num++;	
    }
	
	for(i=0;i<10;i++)
		for(j=0;j<10;j++)
	{
	      hhh[i].c = 'a';
		hhh[i].niz[j] = 1;
	}
	
return 0;	
}