#include  "asmc.h"

/************************************************************************/
/*  ASMC - SIMULATOR ASEMBLERA ZA HIPOTETI�KI INTEL 32-bitni PROCESOR   */
/************************************************************************/
#include "asmc.h"

Byte _STACK[STACK_SIZE];

/* programibilni registri procesora */
DWord eax, ebx, edx, ecx, edi, esi, ebp, esp;

/* registar stanja */
struct flagreg FLAG;

char * M_ = NULL;

void MAIN(void); /*ime glavnog potprograma u ASMC

/* Poziv glavog ASMC potprograma MAIN i rezerviranje memorije za stog*/
int main()
{ 
	 esp = (DWord)&_STACK[STACK_SIZE-8];
	 MAIN();
	 return 0;
}
