/*Datoteka: swap.c*/
#include"asmc.c"

char * _ = NULL;

#define tmp DWORD(M_[ebp-4])
#define px  DWORD(M_[ebp+8])
#define py  DWORD(M_[ebp+12])

VAR  unos DD(21) = "Unesi cijeli broj: ";
VAR  swaprez DD(13) = "Nakon swap: ";

PROC(swap)
   PUSH(ebp)
   MOV(ebp,esp)
   SUB(esp,4)   
   MOV(ebx, px)                /* ebx = px   */
   MOV(eax, DWORD(M_[ebx]))    /* eax = *ebx  (eax <=> *px) */
   MOV(tmp, eax)               /* tmp = *px */
   MOV(edx, py)                /* edx = py  */
   MOV(eax, DWORD(M_[edx]))    /* eax = *edx, (eax <=> *py) */    
   MOV(DWORD(M_[ebx]), eax)    /* *px = *py */
   MOV(eax, tmp)               /* eax = tmp */
   MOV(DWORD(M_[edx]), eax)    /* *py = tmp */
   MOV(esp,ebp)
   POP(ebp)
   RET(0)
ENDP

#define x DWORD(M_[ebp-4])
#define y DWORD(M_[ebp-8])

PROC(MAIN)      
   PUSH(ebp)
   MOV(ebp,esp)
   SUB(esp,8)     /* lok. varijable x i y */
   PUTS(unos)
   GETI(x)        /* dobavi vrijednost x*/
   PUTS(unos)
   GETI(y)        /* dobavi vrijednost y*/
   LEA(eax,y)     /* dobavi adresu od y*/ 
   PUSH(eax)      /* stavi na stog */
   LEA(eax,x)     /* dobavi adresu od x*/
   PUSH(eax)      /* stavi na stog */ 
   CALL(swap)     /* pozovi swap */ 
   ADD(esp,8)     /* o�isti argumente sa stoga */
   PUTS(swaprez)
   PUTC(10)
   PUTI(x)        /* ispi�i x */
   PUTC(10)
   PUTI(y)        /* ispi�i y */
   PUTC(10)
   MOV(esp,ebp)     /* o�isti lokalne varijable*/
   POP(ebp)
   RET(0)
ENDP

