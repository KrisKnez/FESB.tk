#include"asmc.c"

VAR  x      DW(4) = {W_(77), W_(1), W_(22), W_(3) }; 
VAR  s      DB(11) = "Rezultat: ";                      

PROC_DECL(SumaNiza)  /*unaprijedna deklaracija procedure*/

PROC(MAIN)   
   LEA(eax,x)        /* adresa od niza x u eax    */
   PUSH(eax)         /* 2. argument - adresa niza */
   PUSH(4)           /* 1. argument broj elemenata*/
   CALL(SumaNiza)    /* poziv procedure           */
   ADD(esp,8)        /* �i��enje stoga            */ 
   PUTS(s)           /* ispis "Rezultat: "        */
   PUTI(eax)         /* ispis rezultata iz  eax   */
   PUTC(10)          /*  nova linija              */   
   RET(0)
ENDP


/* argumenti i lokalne varijable */
#define N DWORD(M_[ebp+8])
#define niz DWORD(M_[ebp+12])
#define sum DWORD(M_[ebp-4])

PROC(SumaNiza)      /* int SumaNiza(int N, short int niz[])*/
   PUSH (ebp)
   MOV (ebp, esp)
   SUB(esp,4)       /* mjesto za varijablu suma */  
   MOV (sum, 0)	    /* po�etno suma = 0         */
   MOV (edi, N)     /* broj elemenata N u edi */
   MOV (ebx, niz )  /* adresa niza u ebx */
petlja:
   DEC (edi)        /* while (--N >= 0) */   
   CMP (edi, 0)    
   JL  (kraj) 		   
   MOVSX (eax, WORD(M_[ebx+edi*2]))  /* eax = x[edi] */
   ADD (sum,eax)                     /* sum += eax */ 
   JMP(petlja)  
kraj:
   MOV(eax,sum)    /* rezultat u eax */               
   MOV(esp,ebp)    /* regeneriraj stog */  
   POP (ebp)
   RET(0)
ENDP

