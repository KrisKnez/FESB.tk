/*rad s lokalnim varijablama*/
#include"asmc.c"

#define x   DWORD(M_[ebp-4])
#define y   DWORD(M_[ebp-8])
#define tmp DWORD(M_[ebp-12])

PROC(MAIN)          
   PUSH(ebp)         /* sa�uvaj vrijednost ebp */
   MOV(ebp,esp)      /* ebp pokazuje na stog */
   SUB(esp, 8)       /* rezerviraj na stogu 8 bajta*/
   MOV(x,2)          /* x = 2*/
   MOV(y,4)          /* y = 4*/
   SUB(esp,4)        /* int tmp = *(ebp-12);*/ 
   MOV(eax,x)        /* eax = x */
   MOV(tmp,eax)      /* tmp = x */
   MOV(eax,y)        /* eax = y */
   MOV(x, eax)       /* x = y*/
   MOV(eax,tmp)      /* eax = tmp */
   MOV(y, eax)       /* y = tmp*/
   ADD(esp,4)        /* vrati stog od tmp */
   PUTI(x)           /* ispi�i vrijednost x*/
   PUTC(10)          /* nova linija */
   PUTI(y)           /* ispi�i vrijednost y*/
   PUTC(10)          /* nova linija */
   ADD(esp,8)        /* vrati stog od x i y*/
   POP(ebp)          /* vrati ebp */
   RET(0)            /* kraj procedure */
ENDP
