/* ra�una sumu niza*/

#include"asmc.c"
/*suma niza - pokaziva�ki pristup */

VAR dniz  DD(5) = {D_(100), D_(-100), D_(-100), D_(1), D_(1)};
VAR suma  DD(1);
VAR str DB(15) ="Suma niza: ";

PROC(MAIN)          
    MOV(DWORD(suma),0)         /* postavi suma = 0 */	
    MOV(ecx, 0)                /* broja� ecx =0    */ 
    LEA(edi, dniz)             /* edi sadr�i adresu niza */  
petlja:   
    CMP(ecx,5)                 /* usporedi ecx s maks. indeksom*/
    JGE(izlaz)                 /* prekini ako je ecx>=5*/
    MOV(eax, DWORD(suma))      /* dobavi sumu */
    ADD(eax,DWORD(M_[edi]))    /* dodaj element niza*/
    MOV(DWORD(suma), eax)      /* postavi ukupnu sumu */    
    INC(ecx)                   /* pove�aj broja� petlje */
    ADD(edi,4)                 /* pove�aj pokaziva� za 4 bajta */
    JMP(petlja)                /* vrati se na po�etak petlje*/
izlaz:
    PUTS(str)
	PUTI(DWORD(suma))          /* ispi�i rezultat*/
    PUTC(10)                   /* nova linija */   
    RET(0)                     /* kraj procedure */
ENDP
