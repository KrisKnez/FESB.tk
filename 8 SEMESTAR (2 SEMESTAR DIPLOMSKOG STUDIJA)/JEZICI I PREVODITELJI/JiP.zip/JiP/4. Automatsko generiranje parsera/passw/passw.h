    
    typedef struct user_str {
      char* name;		/* symbolic user id */
      char* password;	/* encrypted of course */
      int   uid;		/* numerical user id */
      int   gid;		/* numerical group id */
      char* gcos_field;		/* full name */
      char* home_dir;		/* his home directory */
      char* login_shell;	/* the shell to use on login */
      struct user_str *next;	/* a linked list */
    } *User;
