
# line 1 "mikro.y"
  
#include<stdio.h>
#include<stdlib.h>
#include <stdarg.h> 
#include "global.h"


extern int lineno;
int g_parse_error;
extern TreeNode * AST;


# line 14 "mikro.y"
typedef union  {
	tValue val;
	int ival;	
	Symbol *sp;
	TreeNode *np;		
	VarList *vlist;
	char *str;
} YYSTYPE;
# define T_PRINT 257
# define T_INT 258
# define T_FLOAT 259
# define T_ID 260
# define T_NUM_INT 261
# define T_NUM_FLOAT 262
#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern short yyerrflag;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
YYSTYPE yylval, yyval;
# define YYERRCODE 256

# line 73 "mikro.y"


void yyerror(char *fmt, ...)
{
	va_list args;
	va_start(args, fmt);
    fprintf(stdout,"Line %d:", lineno);  
	vfprintf(stdout, fmt, args);
	fprintf(stdout,"\n");
	va_end(args);
	g_parse_error++;
}short yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
	};
# define YYNPROD 25
# define YYLAST 223
short yyact[]={

  20,   8,   9,  10,   7,   8,  33,  15,   7,  16,
  25,  34,  27,  30,  39,  28,  18,  29,  31,   5,
  17,   4,   2,  13,  12,  24,   3,   1,   6,  11,
  14,  13,  19,   0,   0,   0,   0,  26,   0,   0,
   0,  32,   0,   0,   0,   0,   0,  37,  38,  35,
  36,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
  21,  22,  23 };
short yypact[]={

-256,-1000,-256,-252,-1000,-1000,-253, -52, -40,-1000,
-1000,-252,-1000,-1000, -34,-1000, -40, -47, -28, -29,
 -40,-1000,-1000,-1000,-1000,-254, -48,-1000, -40, -40,
 -40, -40, -27,-1000,-1000,-1000,-1000,-1000,-1000,-1000 };
short yypgo[]={

   0,  20,  16,  32,  19,  26,  30,  28,  27,  22,
  21 };
short yyr1[]={

   0,   8,   8,   8,   9,   9,  10,   6,   6,   7,
   7,   5,   5,   4,   4,   1,   1,   1,   2,   2,
   2,   3,   3,   3,   3 };
short yyr2[]={

   0,   0,   2,   1,   1,   2,   3,   1,   3,   1,
   1,   1,   2,   4,   3,   1,   3,   3,   1,   3,
   3,   3,   1,   1,   1 };
short yychk[]={

-1000,  -8,  -9,  -5, -10,  -4,  -7, 260, 257, 258,
 259,  -5, -10,  -4,  -6, 260,  61,  -1,  -2,  -3,
  40, 260, 261, 262,  59,  44,  -1,  59,  43,  45,
  42,  47,  -1, 260,  59,  -1,  -1,  -2,  -2,  41 };
short yydef[]={

   1,  -2,   0,   3,   4,  11,   0,   0,   0,   9,
  10,   2,   5,  12,   0,   7,   0,   0,  15,  18,
   0,  22,  23,  24,   6,   0,   0,  14,   0,   0,
   0,   0,   0,   8,  13,  16,  17,  19,  20,  21 };
 
# define YYFLAG -1000 
# define YYERROR goto yyerrlab 
# define YYACCEPT return(0) 
# define YYABORT return(1) 
 
/*	parser for yacc output	*/ 
 
int yydebug = 0; /* 1 for debugging */ 
YYSTYPE yyv[YYMAXDEPTH]; /* where the values are stored */ 
int yychar = -1; /* current input token number */ 
int yynerrs = 0;  /* number of errors */ 
short yyerrflag = 0;  /* error recovery flag */ 
 
int yyparse()  
{ 
 
	short yys[YYMAXDEPTH]; 
	short yyj, yym; 
	register YYSTYPE *yypvt; 
	register short yystate, *yyps, yyn; 
	register YYSTYPE *yypv; 
	register short *yyxi; 
 
	yystate = 0; 
	yychar = -1; 
	yynerrs = 0; 
	yyerrflag = 0; 
	yyps= &yys[-1]; 
	yypv= &yyv[-1]; 
 
 yystack:    /* put a state and value onto the stack */ 
 
	if( yydebug  ) printf( "state %d, char 0%o\n", yystate, yychar ); 
		if( ++yyps> &yys[YYMAXDEPTH] ) { yyerror( "yacc stack overflow" ); return(1); } 
		*yyps = yystate; 
		++yypv; 
		*yypv = yyval; 
 
 yynewstate: 
 
	yyn = yypact[yystate]; 
 
	if( yyn<= YYFLAG ) goto yydefault; /* simple state */ 
 
	if( yychar<0 ) if( (yychar=yylex())<0 ) yychar=0; 
	if( (yyn += yychar)<0 || yyn >= YYLAST ) goto yydefault; 
 
	if( yychk[ yyn=yyact[ yyn ] ] == yychar ){ /* valid shift */ 
		yychar = -1; 
		yyval = yylval; 
		yystate = yyn; 
		if( yyerrflag > 0 ) --yyerrflag; 
		goto yystack; 
		} 
 
 yydefault: 
	/* default state action */ 
 
	if( (yyn=yydef[yystate]) == -2 ) { 
		if( yychar<0 ) if( (yychar=yylex())<0 ) yychar = 0; 
		/* look through exception table */ 
 
		for( yyxi=yyexca; (*yyxi!= (-1)) || (yyxi[1]!=yystate) ; yyxi += 2 ) ; /* VOID */ 
 
		while( *(yyxi+=2) >= 0 ){ 
			if( *yyxi == yychar ) break; 
			} 
		if( (yyn = yyxi[1]) < 0 ) return(0);   /* accept */ 
		} 
 
	if( yyn == 0 ){ /* error */ 
		/* error ... attempt to resume parsing */ 
 
		switch( yyerrflag ){ 
 
		case 0:   /* brand new error */ 
 
			yyerror( "syntax error" ); 
		yyerrlab: 
			++yynerrs; 
 
		case 1: 
		case 2: /* incompletely recovered error ... try again */ 
 
			yyerrflag = 3; 
 
			/* find a state where "error" is a legal shift action */ 
 
			while ( yyps >= yys ) { 
			   yyn = yypact[*yyps] + YYERRCODE; 
			   if( yyn>= 0 && yyn < YYLAST && yychk[yyact[yyn]] == YYERRCODE ){ 
			      yystate = yyact[yyn];  /* simulate a shift of "error" */ 
			      goto yystack; 
			      } 
			   yyn = yypact[*yyps]; 
 
			   /* the current yyps has no shift onn "error", pop stack */ 
 
			   if( yydebug ) printf( "error recovery pops state %d, uncovers %d\n", *yyps, yyps[-1] ); 
			   --yyps; 
			   --yypv; 
			   } 
 
			/* there is no state on the stack with an error shift ... abort */ 
 
	yyabort: 
			return(1); 
 
 
		case 3:  /* no shift yet; clobber input char */ 
 
			if( yydebug ) printf( "error recovery discards char %d\n", yychar ); 
 
			if( yychar == 0 ) goto yyabort; /* don't discard EOF, quit */ 
			yychar = -1; 
			goto yynewstate;   /* try again in the same state */ 
 
			} 
 
		} 
 
	/* reduction by production yyn */ 
 
		if( yydebug ) printf("reduce %d\n",yyn); 
		yyps -= yyr2[yyn]; 
		yypvt = yypv; 
		yypv -= yyr2[yyn]; 
		yyval = yypv[1]; 
		yym=yyn; 
			/* consult goto table to find next state */ 
		yyn = yyr1[yyn]; 
		yyj = yypgo[yyn] + *yyps + 1; 
		if( yyj>=YYLAST || yychk[ yystate = yyact[yyj] ] != -yyn ) yystate = yyact[yypgo[yyn]]; 
		switch(yym){ 
			 

case 1:
# line 34 "mikro.y"
{AST = NULL;} break;
case 2:
# line 35 "mikro.y"
{AST = yypvt[-0].np;} break;
case 3:
# line 36 "mikro.y"
{AST = yypvt[-0].np;} break;
case 6:
# line 41 "mikro.y"
{insertVars(yypvt[-2].ival, yypvt[-1].vlist);} break;
case 7:
# line 43 "mikro.y"
{yyval.vlist = addVarList(insert(yypvt[-0].str, 0), NULL); } break;
case 8:
# line 44 "mikro.y"
{yyval.vlist = addVarList(insert(yypvt[-0].str, 0), yypvt[-2].vlist); } break;
case 9:
# line 46 "mikro.y"
{yyval.ival = IntType;} break;
case 10:
# line 47 "mikro.y"
{yyval.ival = FloatType;} break;
case 11:
# line 49 "mikro.y"
{yyval.np = appendStatement(yypvt[-0].np, NULL); } break;
case 12:
# line 50 "mikro.y"
{yyval.np = appendStatement(yypvt[-0].np, yypvt[-1].np); } break;
case 13:
# line 54 "mikro.y"
{Symbol *sp = lookup(yypvt[-3].str);
								if(sp == NULL)	yyerror("Variabla nije deklarirana\n");		
								yyval.np = makeStatement(NodeAssign, yypvt[-1].np, sp);	
								} break;
case 14:
# line 58 "mikro.y"
{yyval.np = makeStatement(NodePrint, yypvt[-1].np, NULL);} break;
case 15:
# line 60 "mikro.y"
{yyval.np = yypvt[-0].np; } break;
case 16:
# line 61 "mikro.y"
{yyval.np = makeExpression('+', yypvt[-2].np, yypvt[-0].np); } break;
case 17:
# line 62 "mikro.y"
{yyval.np = makeExpression('-', yypvt[-2].np, yypvt[-0].np); } break;
case 18:
# line 64 "mikro.y"
{yyval.np = yypvt[-0].np;} break;
case 19:
# line 65 "mikro.y"
{yyval.np = makeExpression('*', yypvt[-2].np, yypvt[-0].np); } break;
case 20:
# line 66 "mikro.y"
{yyval.np = makeExpression('*', yypvt[-2].np, yypvt[-0].np); } break;
case 21:
# line 68 "mikro.y"
{yyval.np = yypvt[-1].np;} break;
case 22:
# line 69 "mikro.y"
{yyval.np = makeVarNode(yypvt[-0].str);  } break;
case 23:
# line 70 "mikro.y"
{yyval.np = makeNode(NodeNumInt, yypvt[-0].val, NULL); } break;
case 24:
# line 71 "mikro.y"
{yyval.np = makeNode(NodeNumFloat, yypvt[-0].val, NULL);} break;  
		} 
		goto yystack;  /* stack new state and value */ 
} 
 
