/**************** Symbol.c **************/
#include <string.h>
#include "global.h"
 
static Symbol *symtable = NULL;

Symbol* lookup(char *str)	/* find- return *sym or NULL if not found*/
{
  Symbol *sym;
  for (sym=symtable; sym !=NULL; sym = sym->next)
    if (strcmp(sym->name, str) == 0) 
    {                            
       return sym;        
    }   
  return NULL;
}

Symbol *insert(char *name,int type)	
{  
  Symbol *sym = malloc(sizeof(Symbol));   
  if (sym == NULL) 
	  sys_error("No memory");    
  sym->name=name;
  sym->type = type;  
  sym->val.f = 0;
  sym->next = symtable;
  symtable = sym;
  return sym;
}

void delete_table()
{
  Symbol *sym = symtable;
  while (symtable != NULL)
  {
	symtable = sym -> next;
	free(sym->name); 
	free(sym);
  }   
}

VarList *addVarList(Symbol *sp, VarList *list)
{
	VarList *vp = (VarList *) malloc(sizeof(VarList));
	if (vp == NULL)
		sem_error("Out of Memory");	
	vp->sp = sp;
	vp->next = list;
	return vp;
}

void insertVars(int subtype, VarList * list)
{
	while(list != NULL) {		
		list->sp->type = subtype;		
		insert(list->sp->name, list->sp->type);
		list = list->next;
    }	
}
