
typedef union  {
	tValue val;
	int ival;	
	Symbol *sp;
	TreeNode *np;		
	VarList *vlist;
	char *str;
} YYSTYPE;
extern YYSTYPE yylval;
# define T_PRINT 257
# define T_INT 258
# define T_FLOAT 259
# define T_ID 260
# define T_NUM_INT 261
# define T_NUM_FLOAT 262
