
Can't predict rule:4, line:3
List of productions and Predict sets:
  0.	Deklaracija -> Tip IdList    Predict: {  INT FLOAT } 
  1.	Tip -> INT    Predict: {  INT } 
  2.	Tip -> FLOAT    Predict: {  FLOAT } 
  3.	IdList$20 -> , ID IdList$20    Predict: {  , } 
  4.	IdList$20 ->    Predict: {  } 
  5.	IdList -> ID IdList$20    Predict: {  ID } 
