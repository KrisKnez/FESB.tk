#ifndef INC_PARSER_H
#define INC_PARSER_H

#ifdef USE_LEX
	extern char *yytext;
	int yylex();
	#define getToken  yylex
	#define lexeme  yytext
#else
	int getToken();
	extern char *lexeme;
#endif


extern int lookahead;

#define ID_TOKEN  257
#define END_TOKEN  260
#define NUM_TOKEN  269

void Naredba();
void Izraz();
void Clan();
void Faktor();

#endif
