
/***********  LL(1) Parser  ************/

#include <stdio.h>

#include "gr1_par.h"


int lookahead;

void SyntaxError(int code) 
{
	printf("Error:%d\n",code);
	exit(1); 
}

void match(int t) 
{
	 if(lookahead == t) lookahead = getToken();
	 else SyntaxError(-1);
}

void Naredba() 
{
	switch (lookahead) {
	case ID_TOKEN: 
		match(ID_TOKEN); 
		match('='); 
		Izraz(); 
		match(END_TOKEN); 
		break;

	default:
		Error(0);
	}
} /* end of Naredba*/

void Izraz() 
{
	switch (lookahead) {
	case ID_TOKEN: case NUM_TOKEN: case '(': 
		Clan(); 
		if (lookahead == '+' || lookahead == '-' ) { 
			if (lookahead == '+' ) {
				match('+'); 
				Izraz(); 
			}
			else if (lookahead == '-' ) {
				match('-'); 
				Izraz(); 
			}
		}
		break;

	default:
		Error(1);
	}
} /* end of Izraz*/

void Clan() 
{
	switch (lookahead) {
	case ID_TOKEN: case NUM_TOKEN: case '(': 
		Faktor(); 
		if (lookahead == '*' || lookahead == '/' ) { 
			if (lookahead == '*' ) {
				match('*'); 
				Clan(); 
			}
			else if (lookahead == '/' ) {
				match('/'); 
				Clan(); 
			}
		}
		break;

	default:
		Error(2);
	}
} /* end of Clan*/

void Faktor() 
{
	switch (lookahead) {
	case NUM_TOKEN: 
		match(NUM_TOKEN); 
		break;

	case ID_TOKEN: 
		match(ID_TOKEN); 
		break;

	case '(': 
		match('('); 
		Izraz(); 
		match(')'); 
		break;

	default:
		Error(3);
	}
} /* end of Faktor*/

