
/***********  LL(1) Parser  ************/

#include <stdio.h>

#include "mikro.grm_par.h"


int lookahead;

void SyntaxError(int code) 
{
	printf("Error:%d\n",code);
	exit(1); 
}

void match(int t) 
{
	 if(lookahead == t) lookahead = getToken();
	 else SyntaxError(-1);
}

void ParseMikro() 
{
	switch (lookahead) {
	case T_DONE: case T_INT: case T_FLOAT: case T_ID: case T_PRINT: 
		DeclarationList(); 
		StatementList(); 
		match(T_DONE); 
		break;

	default:
		Error(0);
	}
} /* end of ParseMikro*/

void DeclarationList() 
{
	switch (lookahead) {
	case T_DONE: case T_INT: case T_FLOAT: case T_ID: case T_PRINT: 
		while (lookahead == T_INT || lookahead == T_FLOAT ) { 
				Declaration(); 
		}
		break;

	default:
		Error(1);
	}
} /* end of DeclarationList*/

void StatementList() 
{
	switch (lookahead) {
	case T_DONE: case T_ID: case T_PRINT: 
		while (lookahead == T_ID || lookahead == T_PRINT ) { 
				Statement(); 
		}
		break;

	default:
		Error(2);
	}
} /* end of StatementList*/

void Declaration() 
{
	switch (lookahead) {
	case T_INT: case T_FLOAT: 
		VarType(); 
		VarList(); 
		match(';'); 
		break;

	default:
		Error(3);
	}
} /* end of Declaration*/

void VarType() 
{
	switch (lookahead) {
	case T_INT: 
		match(T_INT); 
		break;

	case T_FLOAT: 
		match(T_FLOAT); 
		break;

	default:
		Error(4);
	}
} /* end of VarType*/

void VarList() 
{
	switch (lookahead) {
	case ID: 
		match(ID); 
		while (lookahead == ',' ) { 
				match(','); 
				match(ID); 
		}
		break;

	default:
		Error(5);
	}
} /* end of VarList*/

void Statement() 
{
	switch (lookahead) {
	case T_ID: 
		match(T_ID); 
		match('='); 
		Expression(); 
		match(';'); 
		break;

	case T_PRINT: 
		match(T_PRINT); 
		Expression(); 
		match(';'); 
		break;

	default:
		Error(6);
	}
} /* end of Statement*/

void Expression() 
{
	switch (lookahead) {
	case T_ID: case '(': case T_NUM_INT: case T_NUM_FLOAT: 
		Term(); 
		if (lookahead == '+' || lookahead == '-' ) { 
			if (lookahead == '+' ) {
				match('+'); 
				Expression(); 
			}
			else if (lookahead == '-' ) {
				match('-'); 
				Expression(); 
			}
		}
		break;

	default:
		Error(7);
	}
} /* end of Expression*/

void Term() 
{
	switch (lookahead) {
	case T_ID: case '(': case T_NUM_INT: case T_NUM_FLOAT: 
		Factor(); 
		if (lookahead == '*' || lookahead == '/' ) { 
			if (lookahead == '*' ) {
				match('*'); 
				Term(); 
			}
			else if (lookahead == '/' ) {
				match('/'); 
				Term(); 
			}
		}
		break;

	default:
		Error(8);
	}
} /* end of Term*/

void Factor() 
{
	switch (lookahead) {
	case '(': 
		match('('); 
		Expression(); 
		match(')'); 
		break;

	case T_ID: 
		match(T_ID); 
		break;

	case T_NUM_INT: 
		match(T_NUM_INT); 
		break;

	case T_NUM_FLOAT: 
		match(T_NUM_FLOAT); 
		break;

	default:
		Error(9);
	}
} /* end of Factor*/

