 /*************** lexer.c ***************/
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "global.h"

#define BSIZE 33

char lexeme[BSIZE];    /* lexeme string */
tValue tokenval;       /* int or float value for numbers */
int lineno=1;
FILE * input = stdin;
static int pos=0;

void syn_error(char *str)	/* error handling */
{
  printf("Line %d, Pos %d: %s\n",lineno,pos,str);
  exit(1);	
}

int getToken(void)  /* Scanner */
{      
    int ch=getc(input); pos++;
	
	/* skip while spaces */
	while (ch ==' ' || ch =='\t') { ch=getc(input); pos++; }		
    while (ch =='\n') { ch=getc(input); lineno++; pos=1; }

	if (isdigit(ch))
	{   
	    int i=0;
	    while (isdigit(ch))  {
	         lexeme[i]=ch;    
	         ch=getc(input); pos++; i++;
 	         if (i >= BSIZE) syn_error ("Buffer overflow");
        }
        if(ch != '.'){
			lexeme[i]= '\0';
			tokenval.i=atoi(lexeme);
			if (ch != EOF){	ungetc(ch,input); 	pos--;	}     
			return T_NUM_INT;
		}
		else { 
			 lexeme[i]='.';
			 ch = getc(input); pos++; i++;
			 while (isdigit(ch)) { /* decimal part */
	             lexeme[i]= ch;    
	             ch = getc(input); pos++; i++;
 	             if (i >= BSIZE) syn_error ("Buffer overflow");
			 }
			 lexeme[i]='\0';
			 tokenval.f=(float)atof(lexeme);
			 if (ch != EOF){ ungetc(ch, input); pos--; }     					      
			 return T_NUM_FLOAT;
		}
	}
    else if (isalpha(ch))   /* t is ident */
    {
       int i=0;
       while (isalnum(ch)) /* t - alphanumeric */
       {
          lexeme[i]= ch;
          ch=getc(input); pos++; i++;
 	      if (i >= BSIZE) syn_error ("Buffer overflow");
       }       
	   lexeme[i]= '\0';              
	   if (ch != EOF)  {ungetc(ch, input); pos--; }
	   
	   if (!strcmp(lexeme, "int"))
		   return T_INT;
	   else if (!strcmp(lexeme, "float"))
		   return T_FLOAT;
	   else if (!strcmp(lexeme, "print"))
		   return T_PRINT;
	   else
		   return T_ID;
    }
    else if (ch == EOF) 
       return T_DONE;
    else
	{ /* neki operatori su separatori: (, ), ; ...  */
       tokenval.op = ch;
	   return ch;
	}  
}
