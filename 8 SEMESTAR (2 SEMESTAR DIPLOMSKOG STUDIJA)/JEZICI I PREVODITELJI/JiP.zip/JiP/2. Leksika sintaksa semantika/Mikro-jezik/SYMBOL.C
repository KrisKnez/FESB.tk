/**************** Symbol.c **************/
#include <string.h>
#include "global.h"
 
static Symbol *symtable = NULL;

Symbol* lookup(char *str)	/* find- return *sym or NULL if not found*/
{
  Symbol *sym;
  for (sym=symtable; sym !=NULL; sym = sym->next)
    if (strcmp(sym->name, str) == 0) 
    {                            
       return sym;        
    }   
  return NULL;
}

Symbol *insert(char *s,int type)	
{
  char *lex;
  Symbol *sym = malloc(sizeof(Symbol));   
  if (sym == NULL) 
	  syn_error("No memory");    
  lex = malloc(strlen(s)+1);
  if (lex == NULL) 
	  syn_error("No memory");
  strcpy(lex,s);
  sym->name=lex;
  sym->type = type;  
  sym->val.f = 0;
  sym->next = symtable;
  symtable = sym;
  return sym;
}

void delete_table()
{
  Symbol *sym = symtable;
  while (symtable != NULL)
  {
	symtable = sym -> next;
	free(sym->name); 
	free(sym);
  }   
}