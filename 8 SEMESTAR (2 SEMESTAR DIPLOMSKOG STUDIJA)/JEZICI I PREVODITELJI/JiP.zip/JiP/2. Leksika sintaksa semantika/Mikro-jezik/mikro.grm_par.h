#ifndef INC_PARSER_H
#define INC_PARSER_H

#ifdef USE_LEX
	extern char *yytext;
	int yylex();
	#define getToken  yylex
	#define lexeme  yytext
#else
	int getToken();
	extern char *lexeme;
#endif


extern int lookahead;

#define T_DONE  259
#define ID  265
#define T_INT  268
#define T_FLOAT  269
#define T_ID  272
#define T_PRINT  275
#define T_NUM_INT  286
#define T_NUM_FLOAT  287

void ParseMikro();
void DeclarationList();
void StatementList();
void Declaration();
void VarType();
void VarList();
void Statement();
void Expression();
void Term();
void Factor();

#endif
