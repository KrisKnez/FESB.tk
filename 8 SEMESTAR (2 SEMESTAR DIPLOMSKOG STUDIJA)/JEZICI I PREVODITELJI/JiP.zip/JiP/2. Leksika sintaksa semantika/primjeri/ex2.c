/*jednoprolazni interpreter aritmeti�kih izraza*/


/* BNF - gramatika              Semanti�ke akcije
 ****************************************************************
 * Naredba :  Izraz             printf(Izraz.val)
			  END;        
 * Izraz : Clan                 Izraz.val = Clan.val 
         | Clan  "+" Izraz;     Izraz.val = Clan.val + Izraz.val
         | Clan  "-" Izraz;     Izraz.val = Clan.val - Izraz.val
 * Clan : Faktor                Clan.val =  Faktor.val 
        | Faktor "*" Clan ;     Clan.val =  Faktor.val * Clan.val
        | Faktor "/" Clan ;     Clan.val =  Faktor.val / Clan.val
 * Faktor : NUM                 Faktor.val = NUM.val
          | "(" Izraz ")" ;     Faktor.val = Izraz.val
*/                    

/* EBNF - gramatika            Semanti�ke akcije
 *************************************************************** 
 * Naredba :  Izraz            printf(Izraz.val)
			  END;        
 * Izraz : Clan                val = Clan.val 
          ( "+" Izraz;         val += Izraz.val
            | "-" Izraz;       val -= Izraz.val
			)                  Izraz.val = val
 * Clan : Faktor               val =  Faktor.val 
        (    "*" Clan ;        val *=  Clan.val
           | "/" Clan ;        val /=  Clan.val
		)                      Clan.val = val 
 * Faktor : NUM                Faktor.val = NUM.val
          | "(" Izraz ")" ;    Faktor.val = Izraz.val
*/                    


#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define BAD_TOKEN   0
#define NUM         2
#define END         3 

typedef int Token;

int lookaheadToken;
char lexeme[64]; /* lexeme string */


void reportError(char *str)	/* error handling */
{
  printf("%s\n",str);
  exit(1);	
}

int GetToken(void)  /* Scanner */
{ 
  int ch;
  while(1)
  { 
    ch=getchar(); 
	if (ch == ' '  || ch=='\t') 
	    continue; /* presko�i bujele znakove */
    if (ch == '\n'  || ch == EOF) return END;
    
	lexeme[0]=(char)ch; lexeme[1]='\0';
	
	if (isdigit(ch)) { /* dobavi realni broj */
            int i = 1;     /* prva znamenka je u lexeme[0]*/
            ch=getchar(); 
            while(isdigit(ch) && i<62) {
                lexeme[i++]=(char)ch; ch=getchar(); 
            } 
            if(ch == '.') {             
               lexeme[i++]=(char)ch; ch=getchar(); 
               while(isdigit(ch) && i<62){
                   lexeme[i++]=(char)ch; ch=getchar(); 
               }	
            }
            lexeme[i] = '\0';
            if (ch != EOF) ungetc(ch,stdin); 	      
            return NUM;     		
	}
    else if(ch == '+' || ch == '-' || ch == '*' 
         || ch == '/' || ch == '(' || ch == ')' )
    	return ch;
    else
    	return BAD_TOKEN;	
  }
}

void match(Token s)
{
  if (lookaheadToken == s)
    lookaheadToken = GetToken();
  else
    reportError("syntax error");
} 

double parseIzraz();
double parseClan();
double parseFaktor();

void parseNaredba()
{            
  double val;
  val = parseIzraz();             
  if (lookaheadToken == END)
  printf("Rezultat= %f\n", val);
  else
  printf("Error!\n");
} 

double parseIzraz()
{                     
  double val =  parseClan();
  if (lookaheadToken == '+') {
    match('+');
    val += parseIzraz();    
  }
  if (lookaheadToken == '-') {
    match('-');    
	val -= parseIzraz();        
  }
  return val;
} 

double parseClan()
{
  double val = parseFaktor();
  if (lookaheadToken == '*') {
      match('*');
      val *= parseClan();      
  }
  if (lookaheadToken == '/') {
	  double val2;
      match('/');
      val2= parseClan();     
      if(val2 != 0)    /* dijeljenje s nulom */
	  val /= val2;
  }
  return val;
} 

double parseFaktor()
{                        
  double val;
  if (lookaheadToken == NUM) {
    val = atof(lexeme); 
    lookaheadToken=GetToken(); 
  }  
  else if (lookaheadToken == '(') {
    match('(');
    val = parseIzraz();
    match(')');
  } else
    reportError("Nedostaje faktor!");
  return val;
} 

int main() 
{
     lookaheadToken=GetToken();
     parseNaredba();
	 printf("\n");
	 
  return 0;
}


/*
C:\> ex2
5*2+3
Rezultat= 13.00

*/