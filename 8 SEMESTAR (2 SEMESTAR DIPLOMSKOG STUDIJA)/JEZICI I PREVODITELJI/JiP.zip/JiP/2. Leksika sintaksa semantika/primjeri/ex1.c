/*
simple stack mashine:

PUSH  NUM   push value
POP         pop top value
PUSHV ID    push contents of ID
PUSHA ID    push addres of data at ID
ASSIGN      rvalue on top is placed 
            in the lvalue (addres)  below it,  both poped
COPY        push copy of top value on the stack
ADD, SUB, 
MUL, DIV, MOD - pop opr2, pop opr1, push (opr1 op opr2)
 */

/* BNF -gramatika               Semanti�ke akcije
 * Naredba : ID_TOKEN           print("PUSHA" ,id)
              "=" Izraz 
			  END_TOKEN;        print("ASSIGN")
 * Izraz : Clan  
         | Clan  "+" Izraz;     print("ADD")
         | Clan  "-" Izraz;     print("SUB")
 * Clan : Faktor 
        | Faktor "*" Clan ;     print("MUL")
        | Faktor "/" Clan ;     print("DIV")
 * Faktor : NUM_TOKEN           print("PUSH" , num)
          | ID_TOKEN            print("PUSHV" , id)
          | "(" Izraz ")" ; 
*/                    
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define BAD_TOKEN         0
#define ID_TOKEN          1
#define NUM_TOKEN         2
#define END_TOKEN         3 

typedef int Token;

int lookaheadToken;
char lexeme[2]; /* lexeme string */


void reportError(char *str)	/* error handling */
{
  printf("%s\n",str);
  exit(1);	
}

int GetToken(void)  /* Scanner */
{ 
  int t;
  while(1)
  { 
    t=getchar(); 
	if (t == ' '  || t=='\t') 
	    continue; /* skip white spaces */
    if (t == '\n' || t==EOF) return END_TOKEN;
    lexeme[0]=(char)t; lexeme[1]='\0';
	if (isdigit(t)) 
		return NUM_TOKEN;
	else if (isalpha(t))  
		return ID_TOKEN;
    else if(t == '+' || t == '-' || t == '*' 
         || t == '/' || t == '(' || t == ')' || t == '=')
    	return t;
    else
    	return BAD_TOKEN;	
  }
}

void match(Token s)
{
  if (lookaheadToken == s)
    lookaheadToken = GetToken();
  else
    reportError("syntax error");
} 


void parseIzraz();
void parseClan();
void parseFaktor();

void parseNaredba()
{            
  if(lookaheadToken==ID_TOKEN) 
     printf("PUSHA %s\n",lexeme);
  match(ID_TOKEN);              
  match('=');   
  parseIzraz();             
  printf("ASSIGN\n");
  match(END_TOKEN);
} 

void parseIzraz()
{                     
  parseClan();
  if (lookaheadToken == '+') {
    match('+');
    parseIzraz();
    printf("ADD \n");
  }
  if (lookaheadToken == '-') {
    match('-');
    parseIzraz();
    printf("SUB \n");
  }
} 

void parseClan()
{
  parseFaktor();
  if (lookaheadToken == '*') {
      match('*');
      parseClan();
      printf("MUL \n");
  }
  if (lookaheadToken == '/') {
      match('/');
      parseClan();     
      printf("DIV \n");
  }
} 

void parseFaktor()
{                        
  if (lookaheadToken == ID_TOKEN){
     printf("PUSHV %s\n",lexeme);
     lookaheadToken=GetToken(); 
  }
  else if (lookaheadToken == NUM_TOKEN) {
    printf("PUSH %s\n",lexeme); 
    lookaheadToken=GetToken(); 
  }  
  else if (lookaheadToken == '(') {
    match('(');
    parseIzraz();
    match(')');
  } else
    reportError("Faktor expected");
} 

int main() 
{
     lookaheadToken=GetToken();
     parseNaredba();
	 printf("\n");
	 
  return 0;
}


/*
C:\> ex1
a=b*(c+3)+d
PUSHA a
PUSHV b
PUSHV c
PUSH 3
ADD
MUL
PUSHV d
ADD
ASSIGN
rezult je u varijabli  a
*/