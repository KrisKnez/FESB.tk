Copyright Field Grass Soup, 1999-2000

Microsoft Developer Studio wizard for generating Bison and Flex project.

Includes the source code for Visual C++ port of these tools.

This product is licensed under terms of the GNU General Public License. See
GPL.txt for details.

In no case will author be responsible for anything resulting from use of this software,
including but not limited to catching a fire by your computer.


Contact author at alex@fg-soup.com

Alex Gitelman

