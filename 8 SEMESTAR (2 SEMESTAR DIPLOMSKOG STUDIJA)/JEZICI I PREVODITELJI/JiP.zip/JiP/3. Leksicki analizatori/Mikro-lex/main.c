
/***********  LL(1) Parser  ************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "global.h"

/* vrsta �vora */
typedef enum {NodeAssign, NodePrint, NodeOp, NodeId, NodeNumInt, NodeNumFloat,
              NodeItoF} tNodeKind;

typedef struct treenode TreeNode;

struct treenode {
  tNodeKind nodekind;  /* vrst �vora                                  */
  tType type;          /* tip Izraza ( tip varijable je u Symtable)   */
  tValue val;          /* vrijednost za broj, token ili operator      */
  Symbol *sym;         /* pokaziva� na simbol u  Symtable             */
  TreeNode *left;      /* pokaziva� na prvi operand izraza            */
  TreeNode *right;     /* pokaziva� drugog operanda ili liste naredbi */  
};

TreeNode *makeNode(tNodeKind ntype, tValue val, Symbol * psym)
{
    TreeNode *t = malloc(sizeof (TreeNode));
    if(t != NULL)
    {
       t->nodekind = ntype;
       t->val = val;
	   t->sym = psym;
       t->left = t-> right = NULL;
    }
    return t;
}

TreeNode *makeExpression(int op, TreeNode *left, TreeNode *right) 
{
    tValue val;
	TreeNode *t;  
	val.op=op;
	t = makeNode(NodeOp, val, NULL);
    if(t != NULL) {
       t->left = left; 
       t-> right = right;	   
    }
    return t;
}

TreeNode *makeStatement(tNodeKind ntype, TreeNode *exprnode, Symbol *psym)
{
    TreeNode *t = malloc(sizeof (TreeNode));
    if(t != NULL)
    {
       t->nodekind = ntype;       
       t->left = exprnode;
	   t->sym = psym;
	   t->right = NULL;
    }
    return t;
}


TreeNode *ParseMikro();
TreeNode * StatementList();
void DeclarationList();
void Declaration();
tType VarType();
void VarList(tType type);
TreeNode *Statement();
TreeNode *Expression();
TreeNode *Term();
TreeNode *Factor();

/* global variable */
int lookahead;


void SyntaxError(int code) 
{
	printf("SyntaxError:%d\n",code);
	exit(1); 
}

void match(int t) 
{
	 if(lookahead == t) lookahead = getToken();
	 else SyntaxError(-1);
}

TreeNode * ParseMikro() 
{
	TreeNode *node = NULL;
	switch (lookahead) {
	case T_INT: case T_FLOAT: case T_ID: case T_PRINT: 
		DeclarationList(); 
		node = StatementList(); 
		break;

	default:
		SyntaxError(0);
	}
	return node;
} /* end of ParseMikro*/

void DeclarationList() 
{
	switch (lookahead) {
	case T_INT: case T_FLOAT: case T_ID: case T_PRINT: 
		while (lookahead == T_INT || lookahead == T_FLOAT ) { 
				Declaration(); 
		}
		break;
	default:
		SyntaxError(1);
	}
} /* end of DeclarationList*/

void Declaration() 
{
	tType t;
	switch (lookahead) {
	case T_INT: case T_FLOAT: 
		t = VarType(); 
		VarList(t); 
		match(';'); 
		break;
	default:
		SyntaxError(3);
	}
} /* end of Declaration*/

tType VarType() 
{
	switch (lookahead) {
	case T_INT: 
		match(T_INT); 
		return IntType;

	case T_FLOAT: 
		match(T_FLOAT); 
		return FloatType;

	default:
		SyntaxError(4);
	}
	return 0;
} /* end of VarType*/

void VarList(tType tip) 
{
	switch (lookahead) {
	case T_ID: 
		insert(lexeme, tip);
		match(T_ID); 
		while (lookahead == ',' ) { 
				match(','); 
				insert(lexeme, tip);
				match(T_ID); 
		}
		break;

	default:
		SyntaxError(5);
	}
} /* end of VarList*/

TreeNode * StatementList() 
{
	TreeNode *last, *first = NULL;	
	switch (lookahead) {
	case T_ID: case T_PRINT: 
		while (lookahead == T_ID || lookahead == T_PRINT ) 
		{ 
				TreeNode * n = Statement();
				if(first == NULL) /* stavi na po�etak liste */
					first=last=n;
				else {           /* dodaj na kraj liste */
					last->right = n;
					last = n;
				}				
		}
		break;
	default:
		SyntaxError(2);
	}
	return first;
} /* end of StatementList*/


TreeNode * Statement() 
{
	TreeNode *t=NULL,*n;    
	switch (lookahead) {
	case T_ID: {
		Symbol *psym = lookup(lexeme);
	    if(psym == NULL)
	        syn_error("variabla nije deklarirana");
		match(T_ID); 
		match('='); 
		n = Expression(); 
		match(';'); 
		t = makeStatement(NodeAssign, n, psym);	
		}
		break;

	case T_PRINT: 
		match(T_PRINT); 
		n = Expression(); 
		match(';'); 
		t = makeStatement(NodePrint, n, NULL);
		break;

	default:
		SyntaxError(6);
	}
	return t;
} /* end of Statement*/

TreeNode * Expression() 
{
	TreeNode *t;
	
	switch (lookahead) {
	case T_ID: case '(': case T_NUM_INT: case T_NUM_FLOAT: 
		t = Term(); 
		if (lookahead == '+' || lookahead == '-' ) { 			
			if (lookahead == '+' ) {
				match('+'); 
				t = makeExpression('+', t, Expression()); 				
			}
			else if (lookahead == '-' ) {
				match('-'); 
				t = makeExpression('-', t, Expression()); 								
			}
		}
		break;

	default:
		SyntaxError(7);
	}
	return t;
} /* end of Expression*/

TreeNode * Term() 
{
	TreeNode *t;
	switch (lookahead) {
	case T_ID: case '(': case T_NUM_INT: case T_NUM_FLOAT: 
		t = Factor(); 
		if (lookahead == '*' || lookahead == '/' ) { 			 
			if (lookahead == '*' ) {
				match('*'); 
				t = makeExpression('*', t, Term()); 				
			}
			else if (lookahead == '/' ) {
				match('/'); 
				t = makeExpression('/', t, Term()); 								
			}
		}
		break;

	default:
		SyntaxError(8);
	}
	return t;
} /* end of Term*/

TreeNode *  Factor() 
{
	TreeNode *t;
	int tok = lookahead;

	switch (lookahead) {
	case '(': 
		match('('); 
		t = Expression(); 
		match(')'); 
		break;

	case T_ID: {
		Symbol *psym = lookup(lexeme);
        if(NULL == psym)
            syn_error("varijabla nije deklarirana");
		t = makeNode(NodeId, psym->val, psym);   
		match(T_ID); 
		}
		break;

	case T_NUM_INT: 
		t = makeNode(NodeNumInt, tokenval, NULL);     
		match(T_NUM_INT); 
		break;

	case T_NUM_FLOAT: 
		t = makeNode(NodeNumFloat, tokenval, NULL);  
		match(T_NUM_FLOAT); 
		break;

	default:
		SyntaxError(9);
	}
	return t;
} /* end of Factor*/


void printNodeInfo(TreeNode *t)
{
    switch (t->nodekind) 
    {
         case NodeOp:       printf("%c ",t->val.op); break;            
         case NodeNumInt:   printf("%d ",t->val.i); break;
         case NodeNumFloat: printf("%f ",t->val.f); break;
         case NodeId:       printf("%s ",t->sym->name); break;
	     case NodeAssign:   printf("%c ",'='); break;
	     case NodePrint:    printf("%s ","print"); break;
	     case NodeItoF:     printf("%s ","CVF");
    }
}

void printAST(TreeNode *t ) /* prefix notacija s zagradama */
{   
      if (NULL == t) return;

	  switch(t->nodekind)
	  {
	  case NodePrint: 
		  printf("\n("); printNodeInfo(t); printAST(t->left); printf(")"); 
		  printAST(t->right); break; /* sljede�a naredba */
      case NodeAssign:
		  printf("\n("); printNodeInfo(t); 
		  printf(" %s ", t->sym->name); printAST(t->left); printf(")"); 
		  printAST(t->right); break;
      case NodeOp:
		  printf("("); printNodeInfo(t); 
		  printAST(t->left); printAST( t->right ); printf(")"); 
		  break;
	  case NodeNumInt: case NodeNumFloat: case  NodeId: /*leaf - without parenthesis */ 
         printNodeInfo(t);   
		 break;
	  case NodeItoF:
		  printf("("); printNodeInfo(t); printAST(t->left); printf(")"); 
		  break;
	  }
}     

void sem_error(char *str)	/* sematic error handling */
{
  printf("%s\n",str);
  exit(1);	
}

tType Generalize(tType t1, tType t2)
{
	if(FloatType == t1 || FloatType == t2) return FloatType;
	else return IntType;
}

TreeNode *InsertCnvNode(TreeNode *n, tNodeKind ntype,  tType type)
{
    TreeNode *prev = malloc(sizeof (TreeNode));
    if(prev != NULL)
	{  /* copy content of n u t */
       memcpy (prev, n, sizeof(TreeNode));
	   /* and refresh content with new meaning */
       n->nodekind = ntype;       
	   n->type = type;
	   n->sym = NULL;
       n->left = prev;       /* connect with previous node */
	   n-> right = NULL;
    }
    return prev;
}

void  Convert(TreeNode *n, tType t )
{
	if (FloatType == n->type && IntType == t) 
		sem_error( "Illegal type conversion");
	else if (IntType == n->type && FloatType == t) {
	   	/* short replace node n by convert-to-float of node n */
		InsertCnvNode(n, NodeItoF, FloatType);
	}
}

tType MakeConsistent(TreeNode *n1, TreeNode *n2)
{
	tType t = Generalize(n1->type, n2->type);
	if(n1->type != t ) Convert( n1,  t);
	else if ((n2->type) != t) Convert( n2,  t);
    return t;
}

tType CheckAssignment(TreeNode *n1, TreeNode *n2)
{
   tType t = n1->sym->type;
   if (n2->type != t) Convert( n2,  t);
   return t;
}

/* simple postorder treenode walk to assign type of expression */
/* inordef for statement list */

void TypeCheck(TreeNode *n) 
{
   if (NULL == n) return;

	switch (n->nodekind) {
	case NodeOp:		TypeCheck(n->left);
				TypeCheck(n->right);	   	   
				n->type = MakeConsistent( n->left, n->right ); 
				break;
	case NodeAssign: 	TypeCheck(n->left);
				n->type = CheckAssignment(n, n->left);
				TypeCheck(n->right);       
				break;
	case NodeId:		n->type = n->sym->type; break;
	case NodePrint:		TypeCheck(n->left);
				n->type = n->left->type; 
				TypeCheck(n->right);       
				break;
	case NodeNumInt:	n->type = IntType; break;
	case NodeNumFloat:  n->type = FloatType; break;
	case NodeItoF:      TypeCheck(n->left);
				n->type = FloatType; 
				break;
	}
}

/* Procedura GenerateCode je rekurzivna funkcija koja 
   prima argument � korijen AST.  
   Generiranje instrukcija stog stroja je "postorder" 
   Generiranje naredbi  je "inorder" */

void GenerateCode(TreeNode *n)
{
	if(NULL == n) return;
	switch (n->nodekind) {
	case NodeAssign: 	printf("PUSHA %s\n", n->sym->name);	
		                GenerateCode(n->left); 
						printf("STORE\n");
						GenerateCode(n->right); 
						break;
	case NodeId:		printf("PUSHA %s\n", n->sym->name);
						printf("LOAD\n");
						break;
	case NodePrint:		GenerateCode(n->left); 
						printf("PRINT%c\n", (FloatType==n->type)? 'F':' '); 
						printf("POP\n"); 
						GenerateCode(n->right); 
						break;
	case NodeNumInt:	printf("PUSHI %d\n", n->val.i); break;
	case NodeNumFloat:  printf("PUSHF %f\n", n->val.f); break;
	case NodeItoF:      GenerateCode(n->left); 
						printf("CONVF\n");
						break;
	case NodeOp:		GenerateCode(n->left);
						GenerateCode(n->right);
						switch(n->val.op) {						
						case '+': printf("ADD%c \n",(n->type==FloatType)? 'F':' ');break;
						case '-': printf("SUB%c \n",(n->type==FloatType)? 'F':' ');break;
						case '*': printf("MUL%c \n",(n->type==FloatType)? 'F':' ');break;
						case '/': printf("DIV%c \n",(n->type==FloatType)? 'F':' ');break;
						}
						break;
	}
}

/* izvr�ni stog  */
tValue stack[100];
int sp = 0;
void push(tValue v) {stack[sp++]=v;}
tValue pop () {return stack[--sp];}

void Execute(TreeNode *n)
{
	tValue op2, op1;

	if(NULL == n) return;
		
	switch (n->nodekind) {
	case NodeAssign: 	Execute(n->left); 
						n->sym->val = pop();						
						Execute(n->right); 
						break;
	case NodeId:		push(n->sym->val);						
						break;
	case NodePrint:		Execute(n->left); 
						if(FloatType==n->type) 
							printf("=%f\n",pop().f);
						else
							printf("=%d\n",pop().i);
						Execute(n->right); 
						break;
	case NodeNumInt:	push(n->val); break;
	case NodeNumFloat:  push(n->val);break;
	case NodeItoF:      Execute(n->left); 
						{
							tValue v = pop(); 
							v.f = (float)v.i;
							push(v);						
						}
						break;
	case NodeOp:		Execute(n->left);
						Execute(n->right);
						
						op2 = pop();
						op1 = pop();
						
						switch(n->val.op) 
						{												
						case '+': if(n->type==FloatType) op1.f += op2.f; else op1.i += op2.i;
								  push(op1);
								  break;
						case '-': if (n->type==FloatType) op1.f -= op2.f; else op1.i -= op2.i;
								  push(op1);
								  break;
						case '*': if (n->type==FloatType) op1.f *=op2.f; else op1.i *= op2.i;
								  push(op1);
								  break;
						case '/': if(op2.f == 0) 
								  { 
									  printf("\nDjeljenje s nulom?\n"); 
									  exit(1); 
								  }
								  else {
									if (n->type==FloatType) op1.f /=op2.f; else op1.i /= op2.i;
								    push(op1);
								  }
								  break;
						}
						break;
	}
}


int main(int argc, char **argv) 
{
	TreeNode *t;
	if(argc == 2) {
		yyin = fopen(argv[1], "rt");    
		if (yyin == NULL) { 
			printf ("Ne moze otvoriti datoteku: %s", argv[1]);
			exit(1);
		}
	}
	lookahead = getToken();
    t = ParseMikro();
	printf("\n\n");
	if(t != NULL)
	{
        printf("AST - prefiks notacija.......... ");
        printAST(t); 
		printf("\nAST s kontrolom tipova.........");
		TypeCheck(t);
		printAST(t); 
		printf("\nGenerirani kod ..............\n");
		GenerateCode(t);
		printf("\nIzvrsenje ...................\n");
		Execute(t);
	}
    return 0;
}