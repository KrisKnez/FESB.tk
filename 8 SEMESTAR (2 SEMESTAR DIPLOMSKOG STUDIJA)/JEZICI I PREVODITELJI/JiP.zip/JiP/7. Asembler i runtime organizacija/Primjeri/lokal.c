/*pristup lokalnoj varijabli */
#include"asmc.c"

PROC(MAIN)          
    PUSH(ebp)                   /* sa�uvaj vrijednost ebp */
    MOV(ebp,esp)                /* ebp pokazuje na stog */
    SUB(esp, 8)                 /*rezerviraj na stogu 8 bajta*/
    MOV(DWORD(M_[ebp-4]),2)     /* x = 2*/
    MOV(DWORD(M_[ebp-8]),4)     /* y = 4*/
    MOV(eax, DWORD(M_[ebp-4]))
    ADD(eax, DWORD(M_[ebp-8]))  /* eax = x+y */
    PUTI(eax)                   /* ispi�i vrijednost*/
    PUTC(10)
    ADD(esp,8)                  /* vrati pokaziva� stoga*/
    POP(ebp)                    /* vrati ebp */
    RET(0)                      /* kraj procedure */
ENDP
