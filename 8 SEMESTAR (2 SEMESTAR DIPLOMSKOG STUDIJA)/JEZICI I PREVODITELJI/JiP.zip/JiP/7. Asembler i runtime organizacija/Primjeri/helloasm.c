#include <stdio.h>

int  rez;

void sum(int *pa,int *pb)
{
    rez = *pa +*pb; 
}

void printsum()
{
   printf("%d", rez);	
}

int main()
{
   int a=5;	
   int b=4;
   sum(&a,&b);
   printsum();
   return 0;
} 
