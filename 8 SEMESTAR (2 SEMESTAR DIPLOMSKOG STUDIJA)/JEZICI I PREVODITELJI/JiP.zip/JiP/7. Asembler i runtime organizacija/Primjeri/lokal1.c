/*pristup lokalnoj varijabli */
#include"asmc.c"

#define x DWORD(M_[ebp-4])
#define y DWORD(M_[ebp-8])

PROC(MAIN)          
    PUSH(ebp)       /* sa�uvaj vrijednost ebp */
    MOV(ebp,esp)    /* ebp pokazuje na stog   */
    SUB(esp, 8)     /* rezerviraj 8 bajta     */
    MOV(x, 2)       /* x = 2                  */
    MOV(y, 4)       /* y = 4                  */
    MOV(eax, x)
    ADD(eax, y)     /* eax = x+y              */
    PUTI(eax)       /* ispi�i vrijednost      */
    PUTC(10)
    MOV(esp, ebp)   /* vrati pokaziva� stoga  */
    POP(ebp)        /* vrati ebp              */
    RET(0)          /* kraj procedure         */
ENDP
