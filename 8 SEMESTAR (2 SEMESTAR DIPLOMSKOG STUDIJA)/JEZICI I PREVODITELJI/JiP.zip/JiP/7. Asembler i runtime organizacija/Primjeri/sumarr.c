/* ra�una sumu niza*/

#include"asmc.c"

VAR dniz  DD(5) = {D_(100), D_(-100), D_(-100), D_(1), D_(1)};
VAR suma  DD(1);
VAR str   DB(15) ="Suma niza: ";

PROC(MAIN)          
    MOV(DWORD(suma),0)          /* postavi suma = 0      */	
    MOV(ecx, 0)                 /* broja� ecx = 0        */ 
petlja:   
    CMP(ecx,5)                  /* usporedi ecx s 5      */
    JGE(izlaz)                  /* prekini ako je ecx>=5 */
    MOV(eax, DWORD(suma))   
    ADD(eax,DWORD(dniz[ecx*4])) /* dodaj element niza    */
    MOV(DWORD(suma), eax)       /* postavi ukupnu sumu   */    
    INC(ecx)                    /* pove�aj broja� petlje */
    JMP(petlja)                 /* ponovi petlju         */
izlaz:    
	PUTS(str)
	PUTI(DWORD(suma))           /* ispi�i rezultat       */
    PUTC(10)                    /* nova linija           */   
    RET(0)                      /* kraj procedure        */
ENDP
