#include "asmc.c"

VAR str DB(6) = {'H', 'e', 'l', 'l', 'o', '\0'};

PROC(STRLEN)	
	MOV(eax,0)                 /* duljina stringa u eax */     
    MOV(edi, DWORD(M_[esp+4])) /* adresa stringa u edi */
loop:
    MOVZX(ebx, BYTE(M_[edi]))  /* dobavi bajt s adrese iz edi*/
	CMP(ebx,0)                 /* dok nije jednak nuli */
	JZ(endloop)
	INC(edi)                   /* inkrementiraj pokaziva� stringa */
	INC(eax)                   /* inkrementiraj duljinu stringa */ 
    JMP(loop)
endloop:		
    RET(0)                     /* rezultat je u registru eax */	
ENDP

PROC(MAIN)
   LEA(eax,str)                /* dobavi adresu stringa str */
   PUSH(eax)                   /* argument je adresa stringa */   
   CALL(STRLEN)                /* poziv procedure STRLEN */
   ADD(esp,4)                    
   PUTS("Duljina Hello je ")
   PUTI(eax)   
   PUTC(0xa)
   RET(0)
ENDP