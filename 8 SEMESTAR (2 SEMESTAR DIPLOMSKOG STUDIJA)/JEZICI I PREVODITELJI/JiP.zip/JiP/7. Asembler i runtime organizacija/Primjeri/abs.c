#include "asmc.c"

VAR  prompt DB(16) = "Otkucaj broj: ";
VAR  rez    DB(24) = "Apsolutna vrijednost: ";

PROC(ABS)	
   MOV(eax, DWORD(M_[esp+4])) /* argument funkcije u eax */     
   CMP(eax,0)                 /* usporedi s nulom */
   JGE(L1)                    /* zavr�i ako je pozitivan broj, ina�e*/  
   NEG(eax)                   /* vrati negativnu vrijednost*/	
L1:
   RET(0)                     /* rezultat je u registru eax */	
ENDP

PROC(MAIN)
   PUSH(ebp)
   MOV(ebp,esp)
   SUB(esp, 4)                /* mjesto za lokalnu varijablu x */
   PUTS(prompt)
   GETI(DWORD(M_[ebp-4]))     /* dobavi vrijednost x*/ 
   PUSH(DWORD(M_[ebp-4]))     /* argument funkcije ABS */   
   CALL(ABS)                  /* poziv procedure ABS */
   ADD(esp, 4)                /* vrati stog u po�etno stanje*/                  
   PUTS(rez)
   PUTI(eax)                  /* rezultat u registru eax*/  
   PUTC(10)
   MOV(esp, ebp)
   POP(ebp)
   RET(0)
ENDP
