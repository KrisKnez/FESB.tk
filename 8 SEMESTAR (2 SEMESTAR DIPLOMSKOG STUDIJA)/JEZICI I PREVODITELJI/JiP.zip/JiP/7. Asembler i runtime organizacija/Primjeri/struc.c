/*pristup nizu strukturalnih varijabli */
#include"asmc.c"

#define SIZE_STUD_STRUC  45
#define POMAK_IME 0
#define POMAK_BROJ  40

VAR num   DD(1);
VAR stds  DB(30*SIZE_STUD_STRUC);     /* niz od 30 elemenata */
VAR prompt_ime DB(15) ="Otkucaj ime: ";
VAR prompt_broj DB(15) ="Otkucaj broj: ";

PROC(MAIN)          
    MOV(DWORD(num) ,0)                 /*num - broj unesenih zapisa*/
unos:    
    PUTS(prompt_ime)
	MOV(ebx, DWORD(num))               /* indeks niza elemenata */
	MUL(ebx, SIZE_STUD_STRUC)          /* pomak elementa niza u bajtima*/
	LEA(eax,stds[ebx+POMAK_IME])
	GETS(eax)                          /* stds[num].ime */ 
	CMP(BYTE(stds[ebx+POMAK_IME]), 0)  /* ako je prazni string */
	JE(kraj_unosa)                     /* zavr�i unos */
	PUTS(prompt_broj)                  /* dobavi broj */ 
    GETI(DWORD(stds[ebx+POMAK_BROJ]))  /* stds[num].broj */
    INC(DWORD(num))	                   /* zabilje�i broj elemenata*/
	JMP(unos)                          /* ponovi unos */
kraj_unosa:	
    MOV(ecx,0)                         /* broja� petlje ispisa */
ispis: /*ispisi */    	
	PUTC(10)                           /* nova linija */   	
	CMP(ecx, DWORD(num))               /* ako je ecx = num */ 
	JE(izlaz)		                   /* prekini ispis */
	MOV(ebx, ecx)                      /* indeks elemenata niza  */
	MUL(ebx, SIZE_STUD_STRUC)          /* pomak u bajima   */
	LEA(eax, stds[ebx+POMAK_IME])
    PUTS(eax)                          /* stds[num].ime */ 
	PUTS(" ")
	PUTI(DWORD(stds[ebx+POMAK_BROJ]))  /* stds[num].broj */	    
	INC(ecx)                           /* pove�aj broja� petlje */ 
	JMP(ispis)                         /* ponovi ispis */
izlaz:
    RET(0)                             /* kraj procedure */
ENDP
