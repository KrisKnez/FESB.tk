/* ispisuje broj, kojeg unosi korisnik, u heksadecimalnoj notaciji*/

#include"asmc.c"

VAR num    DD(1);
VAR prompt DB(15) ="Otkucaj broj: ";
VAR heksa  DB(9) ="\nHeksa: ";

PROC(MAIN)          
    PUTS(prompt)           /* poruka korisniku */
    GETI(DWORD(num))       /* dobavi broj */
    MOV(ecx,0)             /* ecx - broja� znamenki */ 
    MOV(eax,DWORD(num))    /* eax - sadr�i broj */
petlja_znamenke:           /* ponavljaj za sve znamenke */    
    DIV(16)                /* podijeli eax s 16 */
    PUSH(edx)              /* ostatak dijeljena na stog */
    INC(ecx)               /* pove�aj broja� znamenki */
    CMP(eax,0)             /* zavr�i petlju ako je eax=0 */ 
    JNZ(petlja_znamenke)    
    PUTS(heksa)            /* ispis znamenki (vijednost na stogu)*/
petlja_ispis:
    POP(eax)               /* dobavi vrijednost znamenke */
    CMP(eax, 10)           /* usporedi s 10, i pretvori u ASCII */
    JGE(L2)
    ADD(eax, '0')          /* ako je <10, dodaj '0'*/
    JMP(L3)
L2: ADD(eax, 'A')          /* ako je >=10, dodaj 'A'-10*/
	SUB(eax,10)
L3: PUTC(eax)              /* ispi�i znamenku */
    DEC(ecx)               /* smanji broja� znakova */ 
    CMP(ecx,0)             /* ako je ve�i od nule */
    JNZ(petlja_ispis)      /* ponovi petlju -ispis */
    PUTC(10)               /* nova linija */   
    RET(0)                 /* kraj procedure */
ENDP
