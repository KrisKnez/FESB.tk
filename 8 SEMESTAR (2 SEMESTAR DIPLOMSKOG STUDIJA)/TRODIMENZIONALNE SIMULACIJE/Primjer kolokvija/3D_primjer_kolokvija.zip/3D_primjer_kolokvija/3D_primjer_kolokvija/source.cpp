#include "Shape.h"
#include "Box.h"
#include "Circle.h"
#include <iostream>
#include <vector>

int wmain (){

// prvi zadatak - ispisni dio
	std::wcout<<L"---------- prvi zad ---------------------------------"<<std::endl;
	Shape a = Shape(L"Green", L"Blue");
	std::wstring a_print = a.ToString();
	std::wcout<<L""<<a_print<<std::endl;

	Shape b;
	b.SetBorderColor(L"Green");
	b.SetFillColor(L"Blue");
	std::wcout<<L"Koristenje Get metode\n ispis sa ToString()"<<std::endl;
	std::wcout<<b.ToString()<<std::endl;
	std::wcout<<L"ispis s get metodama:\nBorderColor="<<b.GetBorderColor()<<L" FillColor="<<b.GetFillColor()<<std::endl;
	std::wcout<<std::endl;


// drugi zadatak
	std::wcout<<L"---------- drugi zad ---------------------------------"<<std::endl;
	Box c = Box (L"Red", L"Blue");
	std::wcout<<c.ToString()<<std::endl;

	Circle d = Circle (L"Red", L"Black");
	std::wcout<<d.ToString()<<std::endl;

// treci zadatak
	std::wcout<<L"---------- treci zad ---------------------------------"<<std::endl;
	std::vector <Shape *> shapes;
	
	Circle *circle_Objects[2];
	circle_Objects[0] = new Circle(L"Red", L"Black");
	circle_Objects[1] = new Circle(L"Green", L"Yellow");
	Box *box_Object = new Box(L"Red", L"Brown");

	for (int i = 0; i < 2; i++)
		shapes.push_back(circle_Objects[i]);
	shapes.push_back(box_Object);

	for (std::vector<Shape *>::iterator iter = shapes.begin(); iter != shapes.end(); iter++)
		std::wcout<<(*iter)->ToString()<<std::endl;

	delete circle_Objects[0];
	delete circle_Objects[1];
	delete box_Object;



	return 0;
}