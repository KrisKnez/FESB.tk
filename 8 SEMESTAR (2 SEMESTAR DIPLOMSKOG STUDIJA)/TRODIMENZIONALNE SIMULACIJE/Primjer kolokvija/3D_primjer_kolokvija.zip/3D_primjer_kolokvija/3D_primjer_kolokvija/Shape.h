/* Shape.h */

#ifndef _SHAPE_H_
#define _SHAPE_H_

#include <iostream>
#include <string>
#include <sstream>

class Shape {
protected:
	std::wstring m_BorderColor;
	std::wstring m_FillColor;

public:
	Shape (){}
	Shape (std::wstring bc, std::wstring fc) : m_BorderColor(bc), m_FillColor(fc){}

	void SetBorderColor (std::wstring bc) {this->m_BorderColor = bc;}
	void SetFillColor (std::wstring fc) {this->m_FillColor = fc;}
	std::wstring GetBorderColor () {return this->m_BorderColor;}
	std::wstring GetFillColor () {return this->m_FillColor;}

	virtual std::wstring ToString(){
		return L"---SHAPE INFO---\nBorderColor=" + this->m_BorderColor + L"\nFillColor=" + this->m_FillColor + L"\n---------------";
	}
};

#endif _SHAPE_H_