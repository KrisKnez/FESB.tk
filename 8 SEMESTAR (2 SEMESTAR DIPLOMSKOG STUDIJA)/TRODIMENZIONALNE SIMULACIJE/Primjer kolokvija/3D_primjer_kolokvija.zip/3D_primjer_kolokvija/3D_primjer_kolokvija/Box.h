/* Box.h - isto ka i circle*/

#ifndef _BOX_H_
#define _BOX_H_

#include <iostream>
#include <string>
#include <sstream>
#include "Shape.h"

class Box : public Shape{
public:
	Box() : Shape(){}
	Box (std::wstring bc, std::wstring fc) : Shape(bc, fc){}

	std::wstring ToString(){
		return L"---BOX INFO---\nBorderColor=" + Shape::GetBorderColor() + L"\nFillColor=" + Shape::GetFillColor() + L"\n---------------";
	}
};

#endif _BOX_H_