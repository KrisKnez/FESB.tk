/* Circle.h
Naslijeduje Shape, konstruktori pomoci :Shape() inicijaliziraju varijable klase Shape
U metodi ToString() prikazana su dva nacina dohvacanja protected varijabli iz klase Shape
*/

#ifndef _CIRCLE_H_
#define _CIRCLE_H_

#include <iostream>
#include <string>
#include <sstream>
#include "Shape.h"

class Circle : public Shape{
public:
	Circle() : Shape(){}
	Circle (std::wstring bc, std::wstring fc) : Shape(bc, fc){}

	std::wstring ToString(){
		return L"---CIRCLE INFO---\nBorderColor=" + this->m_BorderColor + L"\nFillColor=" + Shape::GetFillColor() + L"\n---------------";
	}
};

#endif _CIRCLE_H_