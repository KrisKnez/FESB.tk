﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace optimizacije
{
    public partial class Window1 : Window
    {
        #region Varijable

        FlowDocument flowDoc = new FlowDocument();

        Table tablica = new Table();
        Table tablicaU = new Table();

        int varijable = new int();
        int ogranicenja = new int();
        int stupci = new int();
        int redci = new int();
        decimal[,] matrica;
        int lista = new int();
        int[] ishodisne;
        decimal[] u;

        bool pocetak = new bool();
        bool optimiziranje = new bool();
        bool greska = new bool();
        
        void InicijalizacijaVarijabli()
        {         
            varijable = 3;
            ogranicenja = 3;
            stupci = 4 + varijable + ogranicenja;
            redci = 2 + ogranicenja;
            textBox1.Text = varijable.ToString();
            textBox2.Text = ogranicenja.ToString();
            pocetak = false;
            optimiziranje = false;
            greska = false;
            lista =  -1;
        }

        #endregion

        public Window1()
        {
            InitializeComponent();
            InicijalizacijaVarijabli();
            CrtanjeTablice();
            scrollBar1.Value = 100;
            scrollBar2.Value = 100;
            pocetak = true;
        }

        #region Tablica

        void CrtanjeTablice()
        {
            flowDoc.Blocks.Add(tablica);

            tablica.CellSpacing = 0;
            tablica.FontSize = 15;
            tablica.TextAlignment = TextAlignment.Center;

            tablica.RowGroups.Add(new TableRowGroup());
            TableRow currentRow;
            for (int i = 0; i < redci; i++)
            {
                tablica.RowGroups[0].Rows.Add(new TableRow());
                currentRow = tablica.RowGroups[0].Rows[i];
                for (int j = 0; j < stupci-1; j++)
                {
                    #region PunjenjeTablice

                    if (i == 0)
                    {
                        if (j > 0 && j < 5)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("X" + (j - 1).ToString()))));

                        else if (j > 4 && j < 8)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("S" + (j - 4).ToString()))));

                        else if (j == 8)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("R"))));

                        else
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));
                    }

                    else if (j == 1)
                    {
                        if (i == 1)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("1"))));

                        else
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("0"))));
                    }

                    else if (i != 1 && j == 0)
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("S" + (i - 1).ToString()))));

                    else if (j > 4 && j < 8)
                    {
                        if ((j - i) == 3)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("1"))));

                        else
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("0"))));
                    }
                    else if (i == 1 && j == 8)
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("0"))));

                    else
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));

                    #endregion

                    currentRow.Cells[j].BorderBrush = Brushes.Black;
                    currentRow.Cells[j].BorderThickness = new Thickness(1);
                }
            }

            richTextBox1.Document = flowDoc;
        }
        void CrtanjeTabliceIteracije(int redak,int stupac, ref int iter)
        {
            #region PostavkeVarijabli

            TabItem tab = new TabItem();
            TextBlock naslov = new TextBlock();
            naslov.Text = iter.ToString() + ". ITERACIJA";
            tab.Header = naslov;
            tab.Name = "tab" + (iter + 1).ToString();
            
            tab.IsSelected = true;

            iter++;

            FlowDocument flowdoc1 = new FlowDocument();
            RichTextBox tekst = new RichTextBox();
            Table tablica1 = new Table();

            tekst.Padding = new Thickness(1);
            tekst.BorderBrush = Brushes.White;
            tekst.Focusable = true;
            tekst.Opacity = 1;
            tekst.BorderThickness = new Thickness(0);
            tekst.Margin = new Thickness(0, 13, 0, 0);

            tablica1.CellSpacing = 0;
            tablica1.FontSize = 15;
            tablica1.TextAlignment = TextAlignment.Center;

            #endregion

            tablica1.RowGroups.Add(new TableRowGroup());
            TableRow currentRow;
            for (int i = 0; i < redci; i++)
            {
                tablica1.RowGroups[0].Rows.Add(new TableRow());
                currentRow = tablica1.RowGroups[0].Rows[i];
                for (int j = 0; j < stupci; j++)
                {
                    #region PunjenjeTablice

                    if (i == 0)
                    {
                        if (j > 0 && j < varijable + 2)
                        {
                            if (lista == 2)
                            {
                                if (j == 1)
                                    currentRow.Cells.Add(new TableCell(new Paragraph(new Run("G0"))));
                                else
                                    currentRow.Cells.Add(new TableCell(new Paragraph(new Run("Y" + (j - 1).ToString()))));
                            }
                            else
                                currentRow.Cells.Add(new TableCell(new Paragraph(new Run("X" + (j - 1).ToString()))));
                        }

                        else if (j > varijable + 1 && j < varijable + ogranicenja + 2)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("S" + (j - (varijable + 1)).ToString()))));

                        else if (j == varijable + ogranicenja + 2)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("R"))));

                        else
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));
                    }

                    else if (j == 1)
                    {
                        if (i == 1)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("1"))));

                        else
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("0"))));
                    }

                    else if (i != 1 && j == 0)
                    {
                        if (ishodisne[i - 2] <= varijable)
                        {
                            if (lista == 2)
                                currentRow.Cells.Add(new TableCell(new Paragraph(new Run("Y" + ishodisne[i - 2].ToString()))));
                            else
                                currentRow.Cells.Add(new TableCell(new Paragraph(new Run("X" + ishodisne[i - 2].ToString()))));
                        }
                        else
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("S" + (ishodisne[i - 2] - varijable).ToString()))));
                    }

                    else if (j == ogranicenja + varijable + 3)
                    {
                        if (i == redak + 1)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("/" + matrica[i - 1, ogranicenja + varijable + 1].ToString()))));
                        else
                        {
                            if (matrica[i - 1, ogranicenja + varijable + 1] > 0)
                                currentRow.Cells.Add(new TableCell(new Paragraph(new Run("+" + matrica[i - 1, ogranicenja + varijable + 1].ToString() + "*X" + (stupac + 1).ToString()))));
                            else
                                currentRow.Cells.Add(new TableCell(new Paragraph(new Run(matrica[i - 1, ogranicenja + varijable + 1].ToString() + "*X" + (stupac + 1).ToString()))));
                        }
                    }
                    else if (j > 1)
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run(matrica[i - 1, j - 2].ToString()))));

                    else
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));


                    #endregion

                    currentRow.Cells[j].BorderBrush = Brushes.Black;
                    currentRow.Cells[j].BorderThickness = new Thickness(1);
                }
            }

            flowdoc1.Blocks.Add(tablica1);
            tekst.Document = flowdoc1;
            tab.Content = tekst;
            tabControl1.Items.Add(tab);
        }
        void DodajVarijable()
        {
            varijable++;
            stupci++;
            
            for (int i = 0; i < redci; i++)
            {
                if (i == 0)
                    tablica.RowGroups[0].Rows[i].Cells.Insert(varijable + 1, new TableCell(new Paragraph(new Run("X"+varijable.ToString()))));

                else
                    tablica.RowGroups[0].Rows[i].Cells.Insert(varijable + 1, new TableCell(new Paragraph(new Run(""))));

                tablica.RowGroups[0].Rows[i].Cells[varijable + 1].BorderBrush = Brushes.Black;
                tablica.RowGroups[0].Rows[i].Cells[varijable + 1].BorderThickness = new Thickness(1);
            }
        }
        void MakniVarijable()
        {
            if (varijable > 0)
            {
                for (int i = 0; i < redci; i++)
                {
                    tablica.RowGroups[0].Rows[i].Cells.RemoveAt(varijable + 1);
                }
                varijable--;
                stupci--;
            }
        }
        void DodajOgranicenja()
        {
            ogranicenja++;
            redci++;

            tablica.RowGroups[0].Rows.Add(new TableRow());

            for (int j = 0; j < stupci-1; j++)
            {
                if (j == 0)
                    tablica.RowGroups[0].Rows[ogranicenja + 1].Cells.Add(new TableCell(new Paragraph(new Run("S"+ogranicenja.ToString()))));

                else if (j == 1 || (j > varijable+1 && j < ogranicenja+varijable+1))
                    tablica.RowGroups[0].Rows[ogranicenja + 1].Cells.Add(new TableCell(new Paragraph(new Run("0"))));

                else
                    tablica.RowGroups[0].Rows[ogranicenja + 1].Cells.Add(new TableCell(new Paragraph(new Run(""))));

                tablica.RowGroups[0].Rows[ogranicenja + 1].Cells[j].BorderBrush = Brushes.Black;
                tablica.RowGroups[0].Rows[ogranicenja + 1].Cells[j].BorderThickness = new Thickness(1);
            }

            stupci++;

            for (int i = 0; i < redci; i++)
            {
                if (i == 0)
                    tablica.RowGroups[0].Rows[i].Cells.Insert(ogranicenja + varijable + 1, new TableCell(new Paragraph(new Run("S"+ogranicenja.ToString()))));

                else if (i == ogranicenja+1)
                    tablica.RowGroups[0].Rows[i].Cells.Insert(ogranicenja + varijable + 1, new TableCell(new Paragraph(new Run("1"))));

                else
                    tablica.RowGroups[0].Rows[i].Cells.Insert(ogranicenja + varijable + 1, new TableCell(new Paragraph(new Run("0"))));
                
                tablica.RowGroups[0].Rows[i].Cells[ogranicenja + varijable + 1].BorderBrush = Brushes.Black;
                tablica.RowGroups[0].Rows[i].Cells[ogranicenja + varijable + 1].BorderThickness = new Thickness(1);
            }
        }
        void MakniOgranicenja()
        {
            if (ogranicenja > 0)
            {
                tablica.RowGroups[0].Rows.RemoveAt(ogranicenja + 1);
                redci--;

                for (int i = 0; i < redci; i++)
                {
                    tablica.RowGroups[0].Rows[i].Cells.RemoveAt(ogranicenja + varijable + 1);
                }
                ogranicenja--;
                stupci--;
            }
        }
        
        #endregion

        #region Racunanje

        void PohranaUMatricu()
        {
            TextRange tekst;
            matrica = new decimal [redci-1,stupci-2];
            greska = false;
            decimal one = new decimal();
            decimal two = new decimal();

            for (int i = 0; i < redci - 1; i++)
            {
                for (int j = 0; j < stupci - 3; j++)
                {
                    tekst = new TextRange(tablica.RowGroups[0].Rows[i + 1].Cells[j + 2].ContentStart,
                        tablica.RowGroups[0].Rows[i + 1].Cells[j + 2].ContentEnd);

                    try
                    {
                        one = Math.Round(Convert.ToDecimal(tekst.Text, System.Globalization.CultureInfo.InvariantCulture), 4);
                        two = Math.Round(Convert.ToDecimal(tekst.Text), 4);
                        if(Math.Abs(one) > Math.Abs(two))
                        {
                            matrica[i, j] = two;
                        }
                        else
                        {
                            matrica[i, j] = one;
                        }
 
                    }
                    catch
                    {

                        MessageBox.Show("greska!!!\nUnjeli ste neki drugi znak umjesto broja!!!\nRedak: " + (i + 2).ToString() + "\tStupac: " + (j + 3).ToString());
                        greska = true;  
                    }
                }
            }

            if (greska == false)
                optimiziranje = true;
        }
        void PohranaIshodisnih()
        {
            ishodisne = new int[ogranicenja];
            for (int i = 0; i < ogranicenja; i++)
            {
                ishodisne[i] = varijable + i + 1;
            }
        }

        void IzracunMaksimuma()
        {
            decimal MinS, test, koeficijent;
            decimal MinR = 0;
            int jMin, iMin, iter = 1;

            while (true)
            {
                MinS = matrica[0, 0];
                jMin = 0;

                for (int j = 1; j < varijable; j++)
                {
                    if (matrica[0, j] < MinS)
                    {
                        MinS = matrica[0, j];
                        jMin = j;
                    }
                }
                if (MinS < 0)
                {
                    iMin = 0;

                    for (int i = 1; i <= ogranicenja; i++)
                    {
                        if (matrica[i, jMin] > 0)
                        {
                            iMin = i;
                            MinR = matrica[i, varijable + ogranicenja] / matrica[i, jMin];
                            break;
                        }
                    }

                    if (iMin > 0)
                    {
                        for (int i = iMin+1; i <= ogranicenja; i++)
                        {
                            if (matrica[i, jMin] > 0)
                            {
                                test = matrica[i, varijable + ogranicenja] / matrica[i, jMin];
                                if (test < MinR)
                                {
                                    MinR = test;
                                    iMin = i;
                                }
                            }
                        }

                        koeficijent = matrica[iMin, jMin];
                        for (int j = 0; j <= (ogranicenja + varijable); j++)
                        {
                            matrica[iMin, j] = Math.Round(matrica[iMin, j] / koeficijent, 4);
                        }

                        matrica[iMin, varijable + ogranicenja + 1] = koeficijent;

                        for (int i = 0; i <= ogranicenja; i++)
                        {
                            if (i != iMin)
                            {
                                koeficijent = matrica[i, jMin];
                                for (int j = 0; j <= (ogranicenja + varijable); j++)
                                {
                                    matrica[i, j] = matrica[i, j] - Math.Round(koeficijent * matrica[iMin, j],4);
                                }
                                matrica[i, varijable + ogranicenja + 1] = - koeficijent;
                            }
                        }

                        ishodisne[iMin - 1] = jMin + 1;
                        CrtanjeTabliceIteracije(iMin, jMin, ref iter);
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    break;
                }
            }
        }
        void IzracunMinimuma()
        {
            decimal MaxS, test, koeficijent;
            decimal MinR = 0;
            int jMax, iMin, iter = 1;

            while (true)
            {
                MaxS = matrica[0, 0];
                jMax = 0;

                for (int j = 1; j < varijable; j++)
                {
                    if (matrica[0, j] > MaxS)
                    {
                        MaxS = matrica[0, j];
                        jMax = j;
                    }
                }
                if (MaxS > 0)
                {
                    iMin = 0;

                    for (int i = 1; i <= ogranicenja; i++)
                    {
                        if (matrica[i, jMax] > 0)
                        {
                            iMin = i;
                            MinR = matrica[i, varijable + ogranicenja] / matrica[i, jMax];
                            break;
                        }
                    }

                    if (iMin > 0)
                    {
                        for (int i = iMin + 1; i <= ogranicenja; i++)
                        {
                            if (matrica[i, jMax] > 0)
                            {
                                test = matrica[i, varijable + ogranicenja] / matrica[i, jMax];
                                if (test < MinR)
                                {
                                    MinR = test;
                                    iMin = i;
                                }
                            }
                        }

                        koeficijent = matrica[iMin, jMax];
                        for (int j = 0; j <= (ogranicenja + varijable); j++)
                        {
                            matrica[iMin, j] = Math.Round(matrica[iMin, j] / koeficijent, 4);
                        }

                        matrica[iMin, varijable + ogranicenja + 1] = koeficijent;

                        for (int i = 0; i <= ogranicenja; i++)
                        {
                            if (i != iMin)
                            {
                                koeficijent = matrica[i, jMax];
                                for (int j = 0; j <= (ogranicenja + varijable); j++)
                                {
                                    matrica[i, j] = matrica[i, j] - Math.Round(koeficijent * matrica[iMin, j], 4);
                                }
                                matrica[i, varijable + ogranicenja + 1] = -koeficijent;
                            }
                        }

                        ishodisne[iMin - 1] = jMax + 1;
                        CrtanjeTabliceIteracije(iMin, jMax, ref iter);
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    break;
                }
            }
        }
        void KrajMaxMin()
        {
            TabItem tab = new TabItem();
            TextBlock naslov = new TextBlock();
            naslov.Text = "   KRAJ   ";
            tab.Header = naslov;
            tab.IsSelected = true;

            FlowDocument flowdoc1 = new FlowDocument();
            RichTextBox tekst = new RichTextBox();
            Table tablica1 = new Table();
            tekst.Padding = new Thickness(1);
            tekst.BorderBrush = Brushes.White;
            tekst.Focusable = true;
            tekst.Opacity = 1;
            tekst.BorderThickness = new Thickness(0);
            tekst.Margin = new Thickness(0, 13, 0, 0);

            tablica1.FontSize = 15;
            tablica1.TextAlignment = TextAlignment.Center;


            tablica1.RowGroups.Add(new TableRowGroup());
            TableRow currentRow;

            tablica1.RowGroups[0].Rows.Add(new TableRow());
            currentRow = tablica1.RowGroups[0].Rows[0];
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("OPTIMALNE VRIJEDNOSTI DECIZIJSKIH VARIJABLI"))));
            currentRow.Cells[0].ColumnSpan = 2;

            tablica1.RowGroups[0].Rows.Add(new TableRow());
            currentRow = tablica1.RowGroups[0].Rows[1];
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("NEISHODIŠNE:"))));
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("ISHODIŠNE:"))));

            for (int i = 2; i <= varijable + 1; i++)
            {
                tablica1.RowGroups[0].Rows.Add(new TableRow());
                currentRow = tablica1.RowGroups[0].Rows[i];
                currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));
                currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));
            }

            int isho = 2;
            int neisho = 2;

            for (int j = 0; j < varijable; j++)
            {
                if (matrica[0, j] != 0)
                {
                    tablica1.RowGroups[0].Rows[isho++].Cells[1] = new TableCell(new Paragraph(new Run("X" + (j + 1).ToString() + " = 0")));
                }
                else
                {
                    for (int i = 1; i <= ogranicenja; i++)
                    {
                        if (matrica[i, j] == 1)
                        {
                            tablica1.RowGroups[0].Rows[neisho++].Cells[0] = new TableCell(new Paragraph(new Run("X" + (j + 1).ToString() + " = " + matrica[i, varijable + ogranicenja].ToString())));
                            break;
                        }
                    }
                }
            }

            tablica1.RowGroups[0].Rows.Add(new TableRow());
            tablica1.RowGroups[0].Rows.Add(new TableRow());
            currentRow = tablica1.RowGroups[0].Rows[varijable + 3];
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("FUNKCIJA CILJA:"))));
            currentRow.Cells[0].ColumnSpan = 2;

            tablica1.RowGroups[0].Rows.Add(new TableRow());
            currentRow = tablica1.RowGroups[0].Rows[varijable + 4];
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("X0 = " + matrica[0, varijable + ogranicenja].ToString()))));
            currentRow.Cells[0].ColumnSpan = 2;

            flowdoc1.Blocks.Add(tablica1);
            tekst.Document = flowdoc1;
            tab.Content = tekst;
            tabControl1.Items.Add(tab);
        }

        void IzracunDualnogSimpleksa()
        {
            ObrtanjeMatrice();
           
            int t = ogranicenja;
            ogranicenja = varijable;
            varijable = t;

            PohranaIshodisnih();

            IspisObrnuteMatrice();
            IzracunMaksimuma();
            KrajDualnogSimpleksa();

            redci = varijable + 2;
            t = ogranicenja;
            ogranicenja = varijable;
            varijable = t;
        }
        void ObrtanjeMatrice()
        {
            redci = varijable + 2;
            decimal[,] t = new decimal[redci - 1, stupci - 2];

            for (int i = 0; i < redci - 1; i++)
            {
                for (int j = 0; j < stupci - 3; j++)
                {
                    if (i == 0)
                    {
                        if (j >= 0 && j < ogranicenja)
                        {
                            t[i, j] = -matrica[j + 1, ogranicenja + varijable];
                        }
                        else
                            t[i, j] = 0;
                    }
                    else if (i == j + 1 && i < ogranicenja)
                    {
                        t[i, j] = matrica[i, j];
                    }
                    else if (j < ogranicenja)
                    {
                        t[i, j] = matrica[j + 1, i-1];
                    }
                    else if (j - ogranicenja == i-1)
                    {
                        t[i, j] = 1;
                    }
                    else if (j == ogranicenja + varijable)
                    {
                        t[i, j] = - matrica[0, i - 1];
                    }
                    else
                        t[i, j] = 0;
                }
            }
            matrica = new decimal[redci - 1, stupci - 2];
            matrica = t;
        }
        void IspisObrnuteMatrice()
        {

            TabItem tab = new TabItem();
            TextBlock naslov = new TextBlock();
            naslov.Text = "NOVA TABLICA";
            tab.Header = naslov;
            tab.IsSelected = true;

            FlowDocument flowdoc1 = new FlowDocument();
            RichTextBox tekst = new RichTextBox();
            Table tablica1 = new Table();
            tekst.Padding = new Thickness(1);
            tekst.BorderBrush = Brushes.White;
            tekst.Focusable = true;
            tekst.Opacity = 1;
            tekst.BorderThickness = new Thickness(0);
            tekst.Margin = new Thickness(0, 13, 0, 0);

            tablica1.CellSpacing = 0;
            tablica1.FontSize = 15;
            tablica1.TextAlignment = TextAlignment.Center;

            tablica1.RowGroups.Add(new TableRowGroup());
            TableRow currentRow;
            for (int i = 0; i < redci; i++)
            {
                tablica1.RowGroups[0].Rows.Add(new TableRow());
                currentRow = tablica1.RowGroups[0].Rows[i];
                for (int j = 0; j < stupci - 1; j++)
                {
                    #region PunjenjeTablice

                    if (i == 0)
                    {
                        if (j > 0 && j < varijable + 2)
                        {
                            if (j == 1)
                                currentRow.Cells.Add(new TableCell(new Paragraph(new Run("G0"))));
                            else
                                currentRow.Cells.Add(new TableCell(new Paragraph(new Run("Y" + (j - 1).ToString()))));
                        }

                        else if (j > varijable + 1 && j < varijable + ogranicenja + 2)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("S" + (j - (varijable + 1)).ToString()))));

                        else if (j == varijable + ogranicenja + 2)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("R"))));

                        else
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));
                    }

                    else if (j == 1)
                    {
                        if (i == 1)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("1"))));

                        else
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("0"))));
                    }

                    else if (i != 1 && j == 0)
                    {
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("S" + (i - 1).ToString()))));
                    }

                    else if (j > 1)
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run(matrica[i - 1, j - 2].ToString()))));

                    else
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));


                    #endregion

                    currentRow.Cells[j].BorderBrush = Brushes.Black;
                    currentRow.Cells[j].BorderThickness = new Thickness(1);
                }
            }

            flowdoc1.Blocks.Add(tablica1);
            tekst.Document = flowdoc1;
            tab.Content = tekst;
            tabControl1.Items.Add(tab);
        }
        void KrajDualnogSimpleksa()
        {
            TabItem tab = new TabItem();
            TextBlock naslov = new TextBlock();
            naslov.Text = "   KRAJ   ";
            tab.Header = naslov;
            tab.IsSelected = true;

            FlowDocument flowdoc1 = new FlowDocument();
            RichTextBox tekst = new RichTextBox();
            Table tablica1 = new Table();
            tekst.Padding = new Thickness(1);
            tekst.BorderBrush = Brushes.White;
            tekst.Focusable = true;
            tekst.Opacity = 1;
            tekst.BorderThickness = new Thickness(0);
            tekst.Margin = new Thickness(0, 13, 0, 0);

            tablica1.FontSize = 15;
            tablica1.TextAlignment = TextAlignment.Center;

            tablica1.RowGroups.Add(new TableRowGroup());
            TableRow currentRow;

            tablica1.RowGroups[0].Rows.Add(new TableRow());
            currentRow = tablica1.RowGroups[0].Rows[0];
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("OPTIMALNE VRIJEDNOSTI DECIZIJSKIH VARIJABLI"))));
            currentRow.Cells[0].ColumnSpan = 2;

            for (int i = 1; i <= ogranicenja; i++)
            {
                tablica1.RowGroups[0].Rows.Add(new TableRow());
                currentRow = tablica1.RowGroups[0].Rows[i];
                currentRow.Cells.Add(new TableCell(new Paragraph(new Run("X" + i.ToString() + " = " + matrica[0, varijable + i - 1].ToString())))); ;
                currentRow.Cells[0].ColumnSpan = 2;
            }

            flowdoc1.Blocks.Add(tablica1);
            tekst.Document = flowdoc1;
            tab.Content = tekst;
            tabControl1.Items.Add(tab);
        }

        void IzracunPromjenaFCOgranicenja()
        {
                IzracunMaksimuma();
                KrajPromjeneFCOgranicenja();
        }
        void KrajPromjeneFCOgranicenja()
        {
            TabItem tab = new TabItem();
            TextBlock naslov = new TextBlock();
            naslov.Text = "   KRAJ   ";
            tab.Header = naslov;
            tab.IsSelected = true;

            FlowDocument flowdoc1 = new FlowDocument();
            RichTextBox tekst = new RichTextBox();
            Table tablica1 = new Table();
            tekst.Padding = new Thickness(1);
            tekst.BorderBrush = Brushes.White;
            tekst.Focusable = true;
            tekst.Opacity = 1;
            tekst.BorderThickness = new Thickness(0);
            tekst.Margin = new Thickness(0, 13, 0, 0);

            tablica1.FontSize = 15;
            tablica1.TextAlignment = TextAlignment.Center;

            tablica1.RowGroups.Add(new TableRowGroup());
            TableRow currentRow;

            int redak = 0;

            tablica1.RowGroups[0].Rows.Add(new TableRow());
            currentRow = tablica1.RowGroups[0].Rows[redak++];
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("OGRANIČENJA KOEFICIJENATA FUNKCIJE CILJA"))));

            bool isho = false;
            bool Max = false;
            bool Min = false;
            int red = 0;
            int SMax = 0;
            int SMin = 0;
            string DGS = "ΔC";
            string GGS = "ΔC";
            decimal DG = 0;
            decimal GG = 0;
            decimal test = 0;


            for (int j = 0; j < varijable; j++)
            {
                for (int i = 0; i < ishodisne.Length; i++)
                {
                    if ((j + 1) == ishodisne[i])
                    {
                        isho = true;
                        red = i + 1;
                        DGS += ishodisne[i].ToString() + "donji = max { ";
                        GGS += ishodisne[i].ToString() + "gornji = min { ";
                        break;
                    }
                }
                if (isho)
                {
                    for (int i = 0; i < varijable + ogranicenja; i++)
                    {
                        if (matrica[0, i] > 0)
                        {
                            if (matrica[red, i] > 0)
                            {
                                test = -Math.Round(matrica[0, i] / matrica[red, i], 4);

                                if (Max == false)
                                {
                                    Max = true;
                                    DG = test;
                                    SMax = i;
                                    DGS += "-" + matrica[0, i].ToString() + "/" + matrica[red, i].ToString();
                                }
                                else if (test > DG)
                                {
                                    DG = test;
                                    SMax = i;
                                    DGS += " , " + "-" + matrica[0, i].ToString() + "/" + matrica[red, i].ToString();
                                }
                                else
                                    DGS += " , " + "-" + matrica[0, i].ToString() + "/" + matrica[red, i].ToString();
                            }
                            else if (matrica[red, i] < 0)
                            {
                                test = -Math.Round(matrica[0, i] / matrica[red, i], 4);

                                if (Min == false)
                                {
                                    Min = true;
                                    GG = test;
                                    SMin = i;
                                    GGS += matrica[0, i].ToString() + "/" + matrica[red, i].ToString();
                                }
                                else if (test < GG)
                                {
                                    GG = test;
                                    SMin = i;
                                    GGS += " , " + matrica[0, i].ToString() + "/" + matrica[red, i].ToString();
                                }
                                else
                                    GGS += " , " + matrica[0, i].ToString() + "/" + matrica[red, i].ToString();
                            }
                        }
                    }

                    DGS += " } = ";
                    GGS += " } = ";

                    if (Max)
                        DGS += (-matrica[0, SMax]).ToString() + "/" + matrica[red, SMax].ToString();
                    else
                        DGS += "-∞";

                    if (Min)
                        GGS += matrica[0, SMin].ToString() + "/" + (-matrica[red, SMin]).ToString();
                    else
                        GGS += "∞";

                    tablica1.RowGroups[0].Rows.Add(new TableRow());
                    currentRow = tablica1.RowGroups[0].Rows[redak++];
                    currentRow.Cells.Add(new TableCell(new Paragraph(new Run("X" + (j + 1).ToString() + ":"))));

                    tablica1.RowGroups[0].Rows.Add(new TableRow());
                    currentRow = tablica1.RowGroups[0].Rows[redak++];
                    currentRow.Cells.Add(new TableCell(new Paragraph(new Run(DGS))));

                    tablica1.RowGroups[0].Rows.Add(new TableRow());
                    currentRow = tablica1.RowGroups[0].Rows[redak++];
                    currentRow.Cells.Add(new TableCell(new Paragraph(new Run(GGS))));

                    tablica1.RowGroups[0].Rows.Add(new TableRow());
                    currentRow = tablica1.RowGroups[0].Rows[redak++];
                    if (Max && Min)
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run(DG.ToString() + " ≤ " + "ΔC" + (j + 1).ToString() + " ≤ " + GG.ToString()))));
                    else if (Min)
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("-∞" + " ≤ " + "ΔC" + (j + 1).ToString() + " ≤ " + GG.ToString()))));
                    else if (Max)
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run(DG.ToString() + " ≤ " + "ΔC" + (j + 1).ToString() + " ≤ " + "∞"))));
                    else
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("-∞" + " ≤ " + "ΔC" + (j + 1).ToString() + " ≤ " + "∞"))));

                    tablica1.RowGroups[0].Rows.Add(new TableRow());
                    currentRow = tablica1.RowGroups[0].Rows[redak++];
                    currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));


                    Max = false;
                    Min = false;
                    DGS = "ΔC";
                    GGS = "ΔC";
                    isho = false;
                }
                else
                {
                    tablica1.RowGroups[0].Rows.Add(new TableRow());
                    currentRow = tablica1.RowGroups[0].Rows[redak++];
                    currentRow.Cells.Add(new TableCell(new Paragraph(new Run("X" + (j + 1).ToString() + ":"))));

                    tablica1.RowGroups[0].Rows.Add(new TableRow());
                    currentRow = tablica1.RowGroups[0].Rows[redak++];
                    currentRow.Cells.Add(new TableCell(new Paragraph(new Run("ΔC" + (j + 1).ToString() + " ≤ " + matrica[0, j].ToString()))));

                    tablica1.RowGroups[0].Rows.Add(new TableRow());
                    currentRow = tablica1.RowGroups[0].Rows[redak++];
                    currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));
                }
            }

            flowdoc1.Blocks.Add(tablica1);
            tekst.Document = flowdoc1;
            tab.Content = tekst;
            tabControl1.Items.Add(tab);
        }

        void IzracunPromjeneDSOgranicenja()
        {
            IzracunMaksimuma();
            OdabirU();
        }
        void OdabirU()
        {
            #region PostavkeVarijabli

            TabItem tab = new TabItem();
            TextBlock naslov = new TextBlock();
            naslov.Text = "ODABIR u-a";
            tab.Header = naslov;
            tab.Name = "tab";

            tab.IsSelected = true;

            FlowDocument flowdoc1 = new FlowDocument();
            RichTextBox tekst = new RichTextBox();
            Table tablica1 = new Table();
            Grid grid1 = new Grid();
            Button botun = new Button();

            botun.Content = "Izračunaj";
            botun.Width = 82;
            botun.Height = 25;
            botun.Click += new RoutedEventHandler(BotunKliknut);

            grid1.RowDefinitions.Add(new RowDefinition());
            grid1.RowDefinitions.Add(new RowDefinition());

            grid1.RowDefinitions[1].Height = new GridLength(100);

            Grid.SetRow(tekst, 0);
            Grid.SetRow(botun, 1);

            grid1.Children.Add(tekst);
            grid1.Children.Add(botun);

            tekst.Padding = new Thickness(1);
            tekst.BorderBrush = Brushes.White;
            tekst.Focusable = true;
            tekst.Opacity = 1;
            tekst.BorderThickness = new Thickness(0);
            tekst.Margin = new Thickness(0, 13, 0, 0);

            tablica1.CellSpacing = 0;
            tablica1.FontSize = 15;
            tablica1.TextAlignment = TextAlignment.Center;

            #endregion

            tablica1.RowGroups.Add(new TableRowGroup());
            TableRow currentRow;
            for (int i = 0; i < redci; i++)
            {
                tablica1.RowGroups[0].Rows.Add(new TableRow());
                currentRow = tablica1.RowGroups[0].Rows[i];
                for (int j = 0; j < stupci; j++)
                {
                    #region PunjenjeTablice

                    if (i == 0)
                    {
                        if (j > 0 && j < varijable + 2)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("X" + (j - 1).ToString()))));

                        else if (j > varijable + 1 && j < varijable + ogranicenja + 2)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("S" + (j - (varijable + 1)).ToString()))));

                        else if (j == varijable + ogranicenja + 2)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("R"))));
                        else if (j + 1 == stupci)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("U"))));
                        else
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));
                    }

                    else if (j == 1)
                    {
                        if (i == 1)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("1"))));

                        else
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("0"))));
                    }

                    else if (i != 1 && j == 0)
                    {
                        if (ishodisne[i - 2] <= varijable)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("X" + ishodisne[i - 2].ToString()))));

                        else
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("S" + (ishodisne[i - 2] - varijable).ToString()))));
                    }
                    else if (j + 1 == stupci)
                    {
                        if (i != 1)
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("0"))));
                        else
                            currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));
                    }

                    else if (j > 1)
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run(matrica[i - 1, j - 2].ToString()))));

                    else
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));


                    #endregion

                    currentRow.Cells[j].BorderBrush = Brushes.Black;
                    currentRow.Cells[j].BorderThickness = new Thickness(1);
                }
            }
            tablica1.RowGroups[0].Rows.Add(new TableRow());
            currentRow = tablica1.RowGroups[0].Rows[redci];
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));
            tablica1.RowGroups[0].Rows.Add(new TableRow());
            currentRow = tablica1.RowGroups[0].Rows[redci+1];
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("B^-1 - sivo"))));
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("Xopt - zeleno"))));
            currentRow.Cells[0].ColumnSpan = 2;
            currentRow.Cells[1].ColumnSpan = 2;

            for (int i = 0; i < ogranicenja; i++)
            {
                for (int j = 0; j <= ogranicenja; j++)
                {
                    if (j == ogranicenja)
                    {
                        tablica1.RowGroups[0].Rows[2+i].Cells[varijable+2+j].Background = Brushes.Green;

                    }
                    else
                    {
                        tablica1.RowGroups[0].Rows[2 + i].Cells[varijable + 2 + j].Background = Brushes.Gray;
                    }
                }
            }

                flowdoc1.Blocks.Add(tablica1);
            tekst.Document = flowdoc1;
            tab.Content = grid1;
            tabControl1.Items.Add(tab);

            tablicaU = tablica1;
        }
        void BotunKliknut(object sender, RoutedEventArgs e)
        {   
            PohranaUVektorU();
        }
        void PohranaUVektorU()
        {
            u = new decimal[ogranicenja];
            greska = false;
            TextRange sadržaj;

            for (int i = 0; i < ogranicenja; i++)
            {
                sadržaj = new TextRange(tablicaU.RowGroups[0].Rows[i + 2].Cells[stupci - 1].ContentStart,
                        tablicaU.RowGroups[0].Rows[i + 2].Cells[stupci - 1].ContentEnd);

                try
                {
                    u[i] = Convert.ToDecimal(sadržaj.Text);
                }
                catch
                {
                    MessageBox.Show("greska!!!\nUnjeli ste neki drugi znak umjesto broja!!!");
                    greska = true;
                }

                if (u[i] != 0 && u[i] != 1 && u[i] != -1)
                {
                    MessageBox.Show("greska!!!\nUnjeli ste neki broj koji nije 0, 1 ili -1!!!" + u[i].ToString());
                    greska = true;
                }

            }
            if (greska == false)
                KrajPromjeneDSOgranicenja();
        }
        void KrajPromjeneDSOgranicenja()
        {
            #region PostavkeVarijabli

            TabItem tab = new TabItem();
            TextBlock naslov = new TextBlock();
            naslov.Text = "   KRAJ   ";
            tab.Header = naslov;
            tab.IsSelected = true;

            FlowDocument flowdoc1 = new FlowDocument();
            RichTextBox tekst = new RichTextBox();
            Table tablica1 = new Table();
            tekst.Padding = new Thickness(1);
            tekst.BorderBrush = Brushes.White;
            tekst.Focusable = true;
            tekst.Opacity = 1;
            tekst.BorderThickness = new Thickness(0);
            tekst.Margin = new Thickness(0, 13, 0, 0);

            tablica1.FontSize = 15;
            tablica1.TextAlignment = TextAlignment.Center;

            #endregion

            tablica1.RowGroups.Add(new TableRowGroup());
            TableRow currentRow;

            tablica1.RowGroups[0].Rows.Add(new TableRow());
            currentRow = tablica1.RowGroups[0].Rows[0];
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("OGRANIČENJA KONSTANTI DESNE STRANE OGRANIČENJA"))));
            currentRow.Cells[0].ColumnSpan = 2;

            decimal[] temp = new decimal[ogranicenja];
            decimal[] alfa = new decimal [ogranicenja];

            for (int i = 0; i < ogranicenja; i++)
            {
                temp[i] = 0;
                for (int j = 0; j < ogranicenja; j++)
                {
                    temp[i] += matrica[1 + i, varijable + j] * u[j];
                }
                if (temp[i] != 0)
                    alfa[i] = Math.Round(-matrica[1 + i, varijable + ogranicenja] / temp[i],4);

                tablica1.RowGroups[0].Rows.Add(new TableRow());
                currentRow = tablica1.RowGroups[0].Rows[i+1];

                if (ishodisne[i] <= varijable)
                {
                    
                    if (temp[i] < 0)
                    {
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("X*" + ishodisne[i].ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString() + " " + temp[i].ToString() + "*α" + " ≥ 0 "))));
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("α" + " ≤ " + alfa[i].ToString()))));
                    }

                    else if (temp[i] > 0)
                    {
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("X*" + ishodisne[i].ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString() + " + " + temp[i].ToString() + "*α" + " ≥ 0 "))));
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("α" + " ≥ " + alfa[i].ToString()))));
                    }

                    else
                    {
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("X*" + ishodisne[i].ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString() + " + " + temp[i].ToString() + "*α" + " ≥ 0 "))));
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("X*" + ishodisne[i].ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString()))));
                    }

                }
                else
                {

                    if (temp[i] < 0)
                    {
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("S*" + (ishodisne[i] - varijable).ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString() + " " + temp[i].ToString() + "*α" + " ≥ 0 "))));
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("α" + " ≤ " + alfa[i].ToString()))));
                    }

                    else if (temp[i] > 0)
                    {
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("S*" + (ishodisne[i] - varijable).ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString() + " + " + temp[i].ToString() + "*α" + " ≥ 0 "))));
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("α" + " ≥ " + alfa[i].ToString()))));
                    }

                    else
                    {
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("S*" + (ishodisne[i] - varijable).ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString() + " + " + temp[i].ToString() + "*α" + " ≥ 0 "))));
                        currentRow.Cells.Add(new TableCell(new Paragraph(new Run("S*" + (ishodisne[i] - varijable).ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString()))));
                    }
                }
            }

            tablica1.RowGroups[0].Rows.Add(new TableRow());
            currentRow = tablica1.RowGroups[0].Rows[ogranicenja + 1];
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run(""))));
            currentRow.Cells[0].ColumnSpan = 2;
            tablica1.RowGroups[0].Rows.Add(new TableRow());
            currentRow = tablica1.RowGroups[0].Rows[ogranicenja + 2];
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("α mora bit ≥ 0.\r\nα možete naći sami ☺."))));
            currentRow.Cells[0].ColumnSpan = 2;

            flowdoc1.Blocks.Add(tablica1);
            tekst.Document = flowdoc1;
            tab.Content = tekst;
            tabControl1.Items.Add(tab);
        }

        #endregion

        #region Postavke

        private void VarijableTextBox(object sender, TextChangedEventArgs e)
        {
            if (textBox1.Text != "")
            {
                int novo = varijable;

                try
                {
                    novo = Convert.ToInt32(textBox1.Text);
                }
                catch
                {
                    MessageBox.Show("greska!!!\nUnjeli ste neki drugi znak umjesto broja!!!");
                    textBox1.Text = varijable.ToString();
                }

                while (novo != varijable)
                {
                    if (novo > varijable)
                    {
                        DodajVarijable();
                    }
                    else if (novo < varijable)
                    {
                        MakniVarijable();
                    }
                }
            }
        }
        private void VarijableScrollBar(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (pocetak)
            {
                if (e.NewValue < e.OldValue)
                    DodajVarijable();
                else if (e.NewValue > e.OldValue)
                    MakniVarijable();
                textBox1.Text = varijable.ToString();
            }
        }

        private void OgranicenjaTextBox(object sender, TextChangedEventArgs e)
        {
            if (textBox1.Text != "")
            {
                int novo = ogranicenja;

                try
                {
                    novo = Convert.ToInt32(textBox2.Text);
                }
                catch
                {
                    MessageBox.Show("greska!!!\nUnjeli ste neki drugi znak umjesto broja!!!");
                    textBox2.Text = ogranicenja.ToString();
                }
                while (novo != ogranicenja)
                {
                    if (novo > ogranicenja)
                    {
                        DodajOgranicenja();
                    }
                    else if (novo < ogranicenja)
                    {
                        MakniOgranicenja();
                    }
                }
            }
        }
        private void OgranicenjaScrollBar(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (pocetak)
            {
                if (e.NewValue < e.OldValue)
                    DodajOgranicenja();
                else if (e.NewValue > e.OldValue)
                    MakniOgranicenja();
                textBox2.Text = ogranicenja.ToString();
            }
        }

        private void Kreiranje(object sender, RoutedEventArgs e)
        {
            PohranaUMatricu();
            if (optimiziranje)
            {
                PohranaIshodisnih();
                switch (lista)
                {
                    case 0:
                        IzracunMaksimuma();
                        KrajMaxMin();
                        break;
                    case 1:
                        IzracunMinimuma();
                        KrajMaxMin();
                        break;
                    case 2:
                        IzracunDualnogSimpleksa();
                        break;
                    case 3:
                        IzracunPromjenaFCOgranicenja();
                        break;
                    case 4:
                        IzracunPromjeneDSOgranicenja();
                        break;
                    default:
                        MessageBox.Show("Nije izabrana metoda!!!");
                        break;
                }
                optimiziranje = false;
            }
        }
        private void IzborMetode(object sender, SelectionChangedEventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    lista = 0;
                    break;
                case 1:
                    lista = 1;
                    break;
                case 2:
                    lista = 2;
                    break;
                case 3:
                    lista = 3;
                    break;
                case 4:
                    lista = 4;
                    break;
                case -1:
                    break;
                default:
                    MessageBox.Show("Greska!!!");
                    break;
            }
        }

        private void NoviProzor(object sender, RoutedEventArgs e)
        {
            Window1 prozor = new Window1();
            prozor.Show();
        }
        private void Reset(object sender, RoutedEventArgs e)
        {
            InicijalizacijaVarijabli();
            tablica = new Table();
            flowDoc.Blocks.Clear();
            richTextBox1.Document.Blocks.Clear();
            TabItem tab = tab1;
            tabControl1.Items.Clear();
            tabControl1.Items.Add(tab);
            CrtanjeTablice();
            scrollBar1.Value = 100;
            scrollBar2.Value = 100;
            pocetak = true;
            comboBox1.SelectedIndex = -1;
        }
        private void Help(object sender, RoutedEventArgs e)
        {
            string pomoc = "";
            pomoc += "\t\t\tKAKO KORISTITI:\n\nNa vrhu prozora se nalazi izbornik preko kojeg mozete otvoriti novi prozor ili resetirati već otvoreni.";
            pomoc += "\nU sredini prozora se nalazi tablica koju punite sa brojevima danima u zadatku.";
            pomoc += "\n Na dnu izabirete broj varijabli i ogranicenja, metodu te pokrećete program.";
            pomoc += "\n\nKod dualnog simpleksa unesite koeficijente kako su zadani u zadatku.";
            pomoc += "\nKod osjetljivosti desne strane u tab-u \"ODABIR u-a\" zadnji stupac tablice predstavlja \"u\" i u njega se unose njegove vrijednosti.";
            pomoc += "";
            pomoc += "";
            MessageBox.Show(pomoc);
        }

        #endregion

        void IspisMatrice()
        {
            string testiranje = "";
            for (int i = 0; i <= ogranicenja; i++)
            {
                for (int j = 0; j <= (varijable + ogranicenja + 1); j++)
                {
                    testiranje += matrica[i, j].ToString() + "\t";
                }
                testiranje += "\n";
            }
            MessageBox.Show(testiranje);
            
        } // test
    }
}
