﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace optimizacije_dotnet_2
{
    public partial class Form1 : Form
    {
        #region Varijable

        private DataGridView Tablica = new DataGridView();
        private DataGridView TablicaU = new DataGridView();

        private int varijable = new int();
        private int ogranicenja = new int();
        private int stupci = new int();
        private int redci = new int();
        private decimal[,] matrica;
        private int lista = new int();
        private int[] ishodisne;
        private decimal[] u;

        private bool optimiziranje = new bool();
        private bool greska = new bool();

        private void InicijalizacijaVarijabli()
        {
            varijable = 3;
            ogranicenja = 3;
            stupci = 4 + varijable + ogranicenja;
            redci = 1 + ogranicenja;
            lista = -1;
            optimiziranje = false;
            greska = false;
        }

        #endregion

        public Form1()
        {
            InitializeComponent();

            button1.Click += new EventHandler(Kreiranje);
            numericUpDown1.ValueChanged += new EventHandler(PromjenaVarijable);
            numericUpDown2.ValueChanged += new EventHandler(PromjenaOgranicenja);
            comboBox1.SelectedIndexChanged += new EventHandler(IzborMetode);
            noviProzorToolStripMenuItem.Click += new EventHandler(NoviProzor);
            resetProzoraToolStripMenuItem.Click += new EventHandler(Reset);
            helpToolStripMenuItem.Click += new EventHandler(Help);

            InicijalizacijaVarijabli();
            CrtanjeTablice();          
        }

        #region Tablica

        private void CrtanjeTablice()
        {
            tableLayoutPanel1.Controls.Add(Tablica);
            Tablica.ColumnCount = stupci - 1;

            tableLayoutPanel1.SetColumn(Tablica, 0);
            tableLayoutPanel1.SetRow(Tablica, 0);
            tableLayoutPanel1.SetColumnSpan(Tablica, 3);

            Tablica.Font = new Font("Times New Roman", 13);

            Tablica.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            Tablica.ColumnHeadersDefaultCellStyle.Font = new Font(Tablica.Font, FontStyle.Bold);
            Tablica.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Tablica.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tablica.Name = "Tablica";
            Tablica.Location = new Point(0, 0);
            Tablica.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            Tablica.RowHeadersVisible = false;
            Tablica.BackgroundColor = Color.White;
            Tablica.BorderStyle = BorderStyle.None;

            Tablica.AllowUserToAddRows = false;

            Tablica.Columns[0].Name = "";
            Tablica.Columns[1].Name = "X0";
            Tablica.Columns[2].Name = "X1";
            Tablica.Columns[3].Name = "X2";
            Tablica.Columns[4].Name = "X3";
            Tablica.Columns[5].Name = "S1";
            Tablica.Columns[6].Name = "S2";
            Tablica.Columns[7].Name = "S3";
            Tablica.Columns[8].Name = "R";

            Tablica.SelectionMode = DataGridViewSelectionMode.CellSelect;
            Tablica.MultiSelect = false;
            Tablica.Dock = DockStyle.Fill;

            string[] row0 = { "", "1", "", "", "", "0", "0", "0", "0" };
            string[] row1 = { "S1", "0", "", "", "", "1", "0", "0", "" };
            string[] row2 = { "S2", "0", "", "", "", "0", "1", "0", "" };
            string[] row3 = { "S3", "0", "", "", "", "0", "0", "1", "" };

            Tablica.Rows.Add(row0);
            Tablica.Rows.Add(row1);
            Tablica.Rows.Add(row2);
            Tablica.Rows.Add(row3);

            DataGridViewColumn column;

            for (int i = 0; i < Tablica.ColumnCount; i++)
            {
                column = Tablica.Columns[i];
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
        }
        private void CrtanjeTabliceIteracije(int redak, int stupac, ref int iter)
        {
            TabPage tab = new TabPage();
            tab.Text = iter.ToString() + ". ITERACIJA";
            tab.Name = "tab" + (iter + 1).ToString();

            iter++;

            DataGridView Tablica1 = new DataGridView();
            tab.Controls.Add(Tablica1);

            Tablica1.ColumnCount = stupci;
            Tablica1.Font = new Font("Times New Roman", 13);

            Tablica1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            Tablica1.ColumnHeadersDefaultCellStyle.Font = new Font(Tablica.Font, FontStyle.Bold);
            Tablica1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Tablica1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tablica1.Name = "Tablica1";
            Tablica1.Location = new Point(0, 0);
            Tablica1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            Tablica1.RowHeadersVisible = false;
            Tablica1.BackgroundColor = Color.White;
            Tablica1.BorderStyle = BorderStyle.None;

            Tablica1.AllowUserToAddRows = false;

            Tablica1.SelectionMode = DataGridViewSelectionMode.CellSelect;
            Tablica1.MultiSelect = false;
            Tablica1.Dock = DockStyle.Fill;

            Tablica1.Columns[0].Name = "";

            for (int j = 1; j < stupci; j++)
            {
                if (j > 0 && j < varijable + 2)
                {
                    if (lista == 2)
                    {
                        if (j == 1)
                            Tablica1.Columns[j].Name = "G0";
                        else
                            Tablica1.Columns[j].Name = "Y" + (j - 1).ToString();
                    }
                    else
                        Tablica1.Columns[j].Name = "X" + (j - 1).ToString();
                }
                else if (j > varijable + 1 && j < varijable + ogranicenja + 2)
                    Tablica1.Columns[j].Name = "S" + (j - (varijable + 1)).ToString();
                else if (j == varijable + ogranicenja + 2)
                    Tablica1.Columns[j].Name = "R";
                else
                    Tablica1.Columns[j].Name = "";
            }

            Tablica1.Rows.Add(redci);

            for (int i = 0; i < redci; i++)
            {
                for (int j = 0; j < stupci; j++)
                {
                    if (j == 1)
                    {
                        if (i == 1)
                            Tablica1.Rows[i].Cells[j].Value = "1";
                        else
                            Tablica1.Rows[i].Cells[j].Value = "0";
                    }

                    else if (i != 0 && j == 0)
                    {
                        if (ishodisne[i - 1] <= varijable)
                        {
                            if (lista == 2)
                                Tablica1.Rows[i].Cells[j].Value = "Y" + ishodisne[i - 1].ToString();
                            else
                                Tablica1.Rows[i].Cells[j].Value = "X" + ishodisne[i - 1].ToString();
                        }
                        else
                            Tablica1.Rows[i].Cells[j].Value = "S" + (ishodisne[i - 1] - varijable).ToString();
                    }

                    else if (j == ogranicenja + varijable + 3)
                    {
                        if (i == redak)
                            Tablica1.Rows[i].Cells[j].Value = "/" + matrica[i, ogranicenja + varijable + 1].ToString();
                        else
                        {
                            if (matrica[i, ogranicenja + varijable + 1] > 0)
                                Tablica1.Rows[i].Cells[j].Value = "+" + matrica[i, ogranicenja + varijable + 1].ToString() + "*X" + (stupac + 1).ToString();
                            else
                                Tablica1.Rows[i].Cells[j].Value = matrica[i, ogranicenja + varijable + 1].ToString() + "*X" + (stupac + 1).ToString();
                        }
                    }
                    else if (j > 1)
                        Tablica1.Rows[i].Cells[j].Value = matrica[i, j - 2].ToString();

                    else
                        Tablica1.Rows[i].Cells[j].Value = "";
                }
            }

            DataGridViewColumn column;

            for (int i = 0; i < Tablica1.ColumnCount; i++)
            {
                column = Tablica1.Columns[i];
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }

            tabControl1.Controls.Add(tab);
            tabControl1.SelectedTab = tab;
        }
        private void DodajVarijable()
        {
            while (numericUpDown1.Value > varijable)
            {
                varijable++;
                stupci++;
                DataGridViewColumn column = new DataGridViewColumn();
                column.Name = "X" + varijable.ToString();
                column.CellTemplate = new DataGridViewTextBoxCell();
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tablica.Columns.Insert(varijable + 1, column);
            }
        }
        private void MakniVarijable()
        {
            while (numericUpDown1.Value < varijable)
            {
                if (varijable > 0)
                {
                    Tablica.Columns.RemoveAt(varijable + 1);
                    varijable--;
                    stupci--;
                }
            }
        }
        private void DodajOgranicenja()
        {
            DataGridViewColumn column;
            while (numericUpDown2.Value > ogranicenja)
            {
                ogranicenja++;
                redci++;

                Tablica.Rows.Add();
                Tablica.Rows[ogranicenja].Cells[0].Value = "S" + ogranicenja.ToString();

                for (int j = 1; j < stupci - 1; j++)
                {
                    if (j == 1 || (j > varijable + 1 && j < ogranicenja + varijable + 1))
                        Tablica.Rows[ogranicenja].Cells[j].Value = "0";

                    else
                        Tablica.Rows[ogranicenja].Cells[j].Value = "";
                }

                stupci++;

                column = new DataGridViewColumn();
                column.Name = "S" + ogranicenja.ToString();
                column.CellTemplate = new DataGridViewTextBoxCell();
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Tablica.Columns.Insert(ogranicenja + varijable + 1, column);

                for (int i = 0; i < redci; i++)
                {
                    if (i == redci - 1)
                        Tablica.Rows[i].Cells[ogranicenja + varijable + 1].Value = "1";
                    else
                        Tablica.Rows[i].Cells[ogranicenja + varijable + 1].Value = "0";
                }
            }
        }
        private void MakniOgranicenja()
        {
            while (numericUpDown2.Value < ogranicenja)
            {
                if (ogranicenja > 0)
                {
                    Tablica.Rows.RemoveAt(redci - 1);
                    redci--;
                    Tablica.Columns.RemoveAt(ogranicenja + varijable + 1);
                    ogranicenja--;
                    stupci--;
                }
            }
        }

        #endregion

        #region Racunanje

        private void PohranaUMatricu()
        {
            matrica = new decimal[redci, stupci - 2];
            greska = false;
            decimal one = new decimal();
            decimal two = new decimal();

            for (int i = 0; i < redci; i++)
            {
                for (int j = 0; j < stupci - 3; j++)
                {
                    try
                    {
                        one = Math.Round(Convert.ToDecimal(Tablica.Rows[i].Cells[j + 2].Value, System.Globalization.CultureInfo.InvariantCulture), 4);
                        two = Math.Round(Convert.ToDecimal(Tablica.Rows[i].Cells[j + 2].Value), 4);
                        if (Math.Abs(one) > Math.Abs(two))
                        {
                            matrica[i, j] = two;
                        }
                        else
                        {
                            matrica[i, j] = one;
                        }

                    }
                    catch
                    {
                        MessageBox.Show("greska!!!\nUnjeli ste neki drugi znak umjesto broja!!!\nRedak: " + (i + 2).ToString() + "\tStupac: " + (j + 3).ToString());
                        greska = true;
                    }
                }
            }

            if (greska == false)
                optimiziranje = true;
        }
        private void PohranaIshodisnih()
        {
            ishodisne = new int[ogranicenja];
            for (int i = 0; i < ogranicenja; i++)
            {
                ishodisne[i] = varijable + i + 1;
            }
        }

        private void IzracunMaksimuma()
        {
            decimal MinS, test, koeficijent;
            decimal MinR = 0;
            int jMin, iMin, iter = 1;

            while (true)
            {
                MinS = matrica[0, 0];
                jMin = 0;

                for (int j = 1; j < varijable; j++)
                {
                    if (matrica[0, j] < MinS)
                    {
                        MinS = matrica[0, j];
                        jMin = j;
                    }
                }
                if (MinS < 0)
                {
                    iMin = 0;

                    for (int i = 1; i <= ogranicenja; i++)
                    {
                        if (matrica[i, jMin] > 0)
                        {
                            iMin = i;
                            MinR = matrica[i, varijable + ogranicenja] / matrica[i, jMin];
                            break;
                        }
                    }

                    if (iMin > 0)
                    {
                        for (int i = iMin + 1; i <= ogranicenja; i++)
                        {
                            if (matrica[i, jMin] > 0)
                            {
                                test = matrica[i, varijable + ogranicenja] / matrica[i, jMin];
                                if (test < MinR)
                                {
                                    MinR = test;
                                    iMin = i;
                                }
                            }
                        }

                        koeficijent = matrica[iMin, jMin];
                        for (int j = 0; j <= (ogranicenja + varijable); j++)
                        {
                            matrica[iMin, j] = Math.Round(matrica[iMin, j] / koeficijent, 4);
                        }

                        matrica[iMin, varijable + ogranicenja + 1] = koeficijent;

                        for (int i = 0; i <= ogranicenja; i++)
                        {
                            if (i != iMin)
                            {
                                koeficijent = matrica[i, jMin];
                                for (int j = 0; j <= (ogranicenja + varijable); j++)
                                {
                                    matrica[i, j] = matrica[i, j] - Math.Round(koeficijent * matrica[iMin, j], 4);
                                }
                                matrica[i, varijable + ogranicenja + 1] = -koeficijent;
                            }
                        }

                        ishodisne[iMin - 1] = jMin + 1;
                        CrtanjeTabliceIteracije(iMin, jMin, ref iter);
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    break;
                }
            }
        }
        private void IzracunMinimuma()
        {
            decimal MaxS, test, koeficijent;
            decimal MinR = 0;
            int jMax, iMin, iter = 1;

            while (true)
            {
                MaxS = matrica[0, 0];
                jMax = 0;

                for (int j = 1; j < varijable; j++)
                {
                    if (matrica[0, j] > MaxS)
                    {
                        MaxS = matrica[0, j];
                        jMax = j;
                    }
                }
                if (MaxS > 0)
                {
                    iMin = 0;

                    for (int i = 1; i <= ogranicenja; i++)
                    {
                        if (matrica[i, jMax] > 0)
                        {
                            iMin = i;
                            MinR = matrica[i, varijable + ogranicenja] / matrica[i, jMax];
                            break;
                        }
                    }

                    if (iMin > 0)
                    {
                        for (int i = iMin + 1; i <= ogranicenja; i++)
                        {
                            if (matrica[i, jMax] > 0)
                            {
                                test = matrica[i, varijable + ogranicenja] / matrica[i, jMax];
                                if (test < MinR)
                                {
                                    MinR = test;
                                    iMin = i;
                                }
                            }
                        }

                        koeficijent = matrica[iMin, jMax];
                        for (int j = 0; j <= (ogranicenja + varijable); j++)
                        {
                            matrica[iMin, j] = Math.Round(matrica[iMin, j] / koeficijent, 4);
                        }

                        matrica[iMin, varijable + ogranicenja + 1] = koeficijent;

                        for (int i = 0; i <= ogranicenja; i++)
                        {
                            if (i != iMin)
                            {
                                koeficijent = matrica[i, jMax];
                                for (int j = 0; j <= (ogranicenja + varijable); j++)
                                {
                                    matrica[i, j] = matrica[i, j] - Math.Round(koeficijent * matrica[iMin, j], 4);
                                }
                                matrica[i, varijable + ogranicenja + 1] = -koeficijent;
                            }
                        }

                        ishodisne[iMin - 1] = jMax + 1;
                        CrtanjeTabliceIteracije(iMin, jMax, ref iter);
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    break;
                }
            }
        }
        private void KrajMaxMin()
        {
            TabPage tab = new TabPage();
            tab.Text = "   KRAJ   ";
            tab.BackColor = Color.White;

            TextBox tekst = new TextBox();

            tekst.TabStop = false;
            tekst.Dock = DockStyle.Fill;
            tekst.BorderStyle = BorderStyle.None;
            tekst.TextAlign = HorizontalAlignment.Center;
            tekst.Multiline = true;
            tekst.Font = new Font("Times New Roman", 13);
            tekst.Text = "OPTIMALNE VRIJEDNOSTI DECIZIJSKIH VARIJABLI\r\n";
            tekst.Text += "ISHODIŠNE:\r\n";
            for (int j = 0; j < varijable; j++)
            {
                if (matrica[0, j] != 0)
                {
                    tekst.Text += "X" + (j + 1).ToString() + " = 0" + "\r\n";
                }
            }

            tekst.Text += "\r\nNEISHODIŠNE:\r\n";

            for (int j = 0; j < varijable; j++)
            {
                for (int i = 1; i <= ogranicenja; i++)
                {
                    if (matrica[i, j] == 1 && matrica[0, j] == 0)
                    {
                        tekst.Text += "X" + (j + 1).ToString() + " = " + matrica[i, varijable + ogranicenja].ToString() + "\r\n";
                        break;
                    }
                }
            }

            tekst.Text += "\r\nFUNKCIJA CILJA:\r\n";
            tekst.Text += "X0 = " + matrica[0, varijable + ogranicenja].ToString();

            tab.Controls.Add(tekst);
            tabControl1.Controls.Add(tab);
            tabControl1.SelectedTab = tab;
        }

        private void IzracunDualnogSimpleksa()
        {
            ObrtanjeMatrice();

            int t = ogranicenja;
            ogranicenja = varijable;
            varijable = t;

            PohranaIshodisnih();

            IspisObrnuteMatrice();
            IzracunMaksimuma();
            KrajDualnogSimpleksa();

            redci = varijable + 1;
            t = ogranicenja;
            ogranicenja = varijable;
            varijable = t;
        }
        private void ObrtanjeMatrice()
        {
            redci = varijable + 1;
            decimal[,] t = new decimal[redci, stupci - 2];

            for (int i = 0; i < redci; i++)
            {
                for (int j = 0; j < stupci - 3; j++)
                {
                    if (i == 0)
                    {
                        if (j >= 0 && j < ogranicenja)
                        {
                            t[i, j] = -matrica[j + 1, ogranicenja + varijable];
                        }
                        else
                            t[i, j] = 0;
                    }
                    else if (i == j + 1 && i < ogranicenja)
                    {
                        t[i, j] = matrica[i, j];
                    }
                    else if (j < ogranicenja)
                    {
                        t[i, j] = matrica[j + 1, i - 1];
                    }
                    else if (j - ogranicenja == i - 1)
                    {
                        t[i, j] = 1;
                    }
                    else if (j == ogranicenja + varijable)
                    {
                        t[i, j] = -matrica[0, i - 1];
                    }
                    else
                        t[i, j] = 0;
                }
            }
            matrica = new decimal[redci, stupci - 2];
            matrica = t;
        }
        private void IspisObrnuteMatrice()
        {
            TabPage tab = new TabPage();
            tab.Text = "NOVA TABLICA";
            tab.Name = "tab";

            DataGridView Tablica1 = new DataGridView();
            tab.Controls.Add(Tablica1);

            Tablica1.ColumnCount = stupci - 1;
            Tablica1.Font = new Font("Times New Roman", 13);

            Tablica1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            Tablica1.ColumnHeadersDefaultCellStyle.Font = new Font(Tablica.Font, FontStyle.Bold);
            Tablica1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Tablica1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tablica1.Name = "Tablica1";
            Tablica1.Location = new Point(0, 0);
            Tablica1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            Tablica1.RowHeadersVisible = false;
            Tablica1.BackgroundColor = Color.White;
            Tablica1.BorderStyle = BorderStyle.None;

            Tablica1.AllowUserToAddRows = false;

            Tablica1.SelectionMode = DataGridViewSelectionMode.CellSelect;
            Tablica1.MultiSelect = false;
            Tablica1.Dock = DockStyle.Fill;

            Tablica1.Columns[0].Name = "";

            for (int j = 1; j < stupci - 1; j++)
            {
                if (j > 0 && j < varijable + 2)
                {
                    if (j == 1)
                        Tablica1.Columns[j].Name = "G0";
                    else
                        Tablica1.Columns[j].Name = "Y" + (j - 1).ToString();
                }
                else if (j > varijable + 1 && j < varijable + ogranicenja + 2)
                    Tablica1.Columns[j].Name = "S" + (j - (varijable + 1)).ToString();
                else if (j == varijable + ogranicenja + 2)
                    Tablica1.Columns[j].Name = "R";
                else
                    Tablica1.Columns[j].Name = "";
            }

            Tablica1.Rows.Add(redci);

            for (int i = 0; i < redci; i++)
            {
                for (int j = 0; j < stupci - 1; j++)
                {
                    if (j == 1)
                    {
                        if (i == 1)
                            Tablica1.Rows[i].Cells[j].Value = "1";
                        else
                            Tablica1.Rows[i].Cells[j].Value = "0";
                    }

                    else if (i != 0 && j == 0)
                    {
                        Tablica1.Rows[i].Cells[j].Value = "S" + i.ToString();
                    }

                    else if (j > 1)
                        Tablica1.Rows[i].Cells[j].Value = matrica[i, j - 2].ToString();

                    else
                        Tablica1.Rows[i].Cells[j].Value = "";
                }
            }

            DataGridViewColumn column;

            for (int i = 0; i < Tablica1.ColumnCount; i++)
            {
                column = Tablica1.Columns[i];
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }

            tabControl1.Controls.Add(tab);
            tabControl1.SelectedTab = tab;
        }
        private void KrajDualnogSimpleksa()
        {
            TabPage tab = new TabPage();
            tab.Text = "   KRAJ   ";
            tab.BackColor = Color.White;

            TextBox tekst = new TextBox();

            tekst.TabStop = false;
            tekst.Dock = DockStyle.Fill;
            tekst.BorderStyle = BorderStyle.None;
            tekst.TextAlign = HorizontalAlignment.Center;
            tekst.Multiline = true;
            tekst.Font = new Font("Times New Roman", 13);

            tekst.Text = "OPTIMALNE VRIJEDNOSTI DECIZIJSKIH VARIJABLI\r\n";
            for (int i = 1; i <= ogranicenja; i++)
            {
                tekst.Text += "X" + i.ToString() + "(S" + i.ToString() + ") = " + matrica[0, varijable + i - 1].ToString() + "\r\n";
            }

            tab.Controls.Add(tekst);
            tabControl1.Controls.Add(tab);
            tabControl1.SelectedTab = tab;
        }

        private void IzracunPromjenaFCOgranicenja()
        {
            IzracunMaksimuma();
            KrajPromjeneFCOgranicenja();
        }
        private void KrajPromjeneFCOgranicenja()
        {
            TabPage tab = new TabPage();
            tab.Text = "   KRAJ   ";
            tab.BackColor = Color.White;

            TextBox tekst = new TextBox();

            tekst.TabStop = false;
            tekst.Dock = DockStyle.Fill;
            tekst.BorderStyle = BorderStyle.None;
            tekst.TextAlign = HorizontalAlignment.Center;
            tekst.Multiline = true;
            tekst.Font = new Font("Times New Roman", 13);
            tekst.Text = "OGRANIČENJA KOEFICIJENATA FUNKCIJE CILJA\r\n";

            bool isho = false;
            bool Max = false;
            bool Min = false;
            int red = 0;
            int SMax = 0;
            int SMin = 0;
            string DGS = "ΔC";
            string GGS = "ΔC";
            decimal DG = 0;
            decimal GG = 0;
            decimal test = 0;


            for (int j = 0; j < varijable; j++)
            {
                for (int i = 0; i < ishodisne.Length; i++)
                {
                    if ((j + 1) == ishodisne[i])
                    {
                        isho = true;
                        red = i + 1;
                        DGS += ishodisne[i].ToString() + "donji = max { ";
                        GGS += ishodisne[i].ToString() + "gornji = min { ";
                        break;
                    }
                }
                if (isho)
                {
                    for (int i = 0; i < varijable + ogranicenja; i++)
                    {
                        if (matrica[0, i] > 0)
                        {
                            if (matrica[red, i] > 0)
                            {
                                test = -Math.Round(matrica[0, i] / matrica[red, i], 4);

                                if (Max == false)
                                {
                                    Max = true;
                                    DG = test;
                                    SMax = i;
                                    DGS += "-" + matrica[0, i].ToString() + "/" + matrica[red, i].ToString();
                                }
                                else if (test > DG)
                                {
                                    DG = test;
                                    SMax = i;
                                    DGS += " , " + "-" + matrica[0, i].ToString() + "/" + matrica[red, i].ToString();
                                }
                                else
                                    DGS += " , " + "-" + matrica[0, i].ToString() + "/" + matrica[red, i].ToString();
                            }
                            else if (matrica[red, i] < 0)
                            {
                                test = -Math.Round(matrica[0, i] / matrica[red, i], 4);

                                if (Min == false)
                                {
                                    Min = true;
                                    GG = test;
                                    SMin = i;
                                    GGS += matrica[0, i].ToString() + "/" + matrica[red, i].ToString();
                                }
                                else if (test < GG)
                                {
                                    GG = test;
                                    SMin = i;
                                    GGS += " , " + matrica[0, i].ToString() + "/" + matrica[red, i].ToString();
                                }
                                else
                                    GGS += " , " + matrica[0, i].ToString() + "/" + matrica[red, i].ToString();
                            }
                        }
                    }

                    DGS += " } = ";
                    GGS += " } = ";

                    if (Max)
                        DGS += (-matrica[0, SMax]).ToString() + "/" + matrica[red, SMax].ToString();
                    else
                        DGS += "-∞";

                    if (Min)
                        GGS += matrica[0, SMin].ToString() + "/" + (-matrica[red, SMin]).ToString();
                    else
                        GGS += "∞";

                    tekst.Text += "X" + (j + 1).ToString() + ":\r\n";

                    tekst.Text += DGS + "\r\n";

                    tekst.Text += GGS + "\r\n";

                    if (Max && Min)
                        tekst.Text += DG.ToString() + " ≤ " + "ΔC" + (j + 1).ToString() + " ≤ " + GG.ToString() + "\r\n\r\n";
                    else if (Min)
                        tekst.Text += "-∞" + " ≤ " + "ΔC" + (j + 1).ToString() + " ≤ " + GG.ToString() + "\r\n\r\n";
                    else if (Max)
                        tekst.Text += DG.ToString() + " ≤ " + "ΔC" + (j + 1).ToString() + " ≤ " + "∞\r\n\r\n";
                    else
                        tekst.Text += "-∞" + " ≤ " + "ΔC" + (j + 1).ToString() + " ≤ " + "∞\r\n\r\n";

                    Max = false;
                    Min = false;
                    DGS = "ΔC";
                    GGS = "ΔC";
                    isho = false;
                }
                else
                {
                    tekst.Text += "X" + (j + 1).ToString() + ":\r\n";

                    tekst.Text += "ΔC" + (j + 1).ToString() + " ≤ " + matrica[0, j].ToString() + "\r\n\r\n";
                }
            }
            tab.Controls.Add(tekst);
            tabControl1.Controls.Add(tab);
            tabControl1.SelectedTab = tab;
        }

        private void IzracunPromjeneDSOgranicenja()
        {
            IzracunMaksimuma();
            OdabirU();
        }
        private void OdabirU()
        {
            TabPage tab = new TabPage();
            tab.Text = "ODABIR U-a";
            tab.BackColor = Color.White;

            TableLayoutPanel grid = new TableLayoutPanel();
            grid.RowStyles.Add(new System.Windows.Forms.RowStyle(SizeType.Percent, 70));
            grid.RowStyles.Add(new System.Windows.Forms.RowStyle(SizeType.Absolute, 50));
            grid.Dock = DockStyle.Fill;

            DataGridView Tablica1 = new DataGridView();
            tab.Controls.Add(grid);
            grid.Controls.Add(Tablica1);
            grid.SetRow(Tablica1, 0);
            grid.SetColumn(Tablica1, 0);

            Tablica1.ColumnCount = stupci;
            Tablica1.Font = new Font("Times New Roman", 13);

            Tablica1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            Tablica1.ColumnHeadersDefaultCellStyle.Font = new Font(Tablica.Font, FontStyle.Bold);
            Tablica1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Tablica1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Tablica1.Name = "Tablica1";
            Tablica1.Location = new Point(0, 0);
            Tablica1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            Tablica1.RowHeadersVisible = false;
            Tablica1.BackgroundColor = Color.White;
            Tablica1.BorderStyle = BorderStyle.None;

            Tablica1.AllowUserToAddRows = false;

            Tablica1.SelectionMode = DataGridViewSelectionMode.CellSelect;
            Tablica1.MultiSelect = false;
            Tablica1.Dock = DockStyle.Fill;

            Tablica1.Columns[0].Name = "";

            for (int j = 1; j < stupci; j++)
            {
                if (j > 0 && j < varijable + 2)
                    Tablica1.Columns[j].Name = "X" + (j - 1).ToString();
                else if (j > varijable + 1 && j < varijable + ogranicenja + 2)
                    Tablica1.Columns[j].Name = "S" + (j - (varijable + 1)).ToString();
                else if (j == varijable + ogranicenja + 2)
                    Tablica1.Columns[j].Name = "R";
                else if (j + 1 == stupci)
                    Tablica1.Columns[j].Name = "U";
                else
                    Tablica1.Columns[j].Name = "";
            }

            Tablica1.Rows.Add(redci);

            for (int i = 0; i < redci; i++)
            {
                for (int j = 0; j < stupci; j++)
                {
                    if (j == 1)
                    {
                        if (i == 1)
                            Tablica1.Rows[i].Cells[j].Value = "1";
                        else
                            Tablica1.Rows[i].Cells[j].Value = "0";
                    }

                    else if (i != 0 && j == 0)
                    {
                        if (ishodisne[i - 1] <= varijable)
                        {
                            Tablica1.Rows[i].Cells[j].Value = "X" + ishodisne[i - 1].ToString();
                        }
                        else
                            Tablica1.Rows[i].Cells[j].Value = "S" + (ishodisne[i - 1] - varijable).ToString();
                    }

                    else if (j + 1 == stupci)
                    {
                        if (i != 0)
                            Tablica1.Rows[i].Cells[j].Value = "0";
                        else
                            Tablica1.Rows[i].Cells[j].Value = "";
                    }

                    else if (j > 1)
                        Tablica1.Rows[i].Cells[j].Value = matrica[i, j - 2].ToString();

                    else
                        Tablica1.Rows[i].Cells[j].Value = "";
                }
            }

            DataGridViewColumn column;

            for (int i = 0; i < Tablica1.ColumnCount; i++)
            {
                column = Tablica1.Columns[i];
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }

            Button botun = new Button();
            botun.Text = "Izračunaj";
            grid.Controls.Add(botun);
            grid.SetColumn(botun, 0);
            grid.SetRow(botun, 1);
            botun.Height = 28;
            botun.Width = 82;
            botun.Anchor = AnchorStyles.Bottom;
            botun.Click += new EventHandler(BotunKliknut);

            TextBox tekst = new TextBox();
            tekst.Width = 300;
            tekst.Height = 20;
            tekst.TabStop = false;
            tekst.BorderStyle = BorderStyle.None;
            tekst.Multiline = true;
            tekst.Font = new Font("Times New Roman", 13);
            tekst.Text = "B^-1 - sivo   Xopt - zeleno";
            grid.Controls.Add(tekst);
            grid.SetColumn(tekst, 0);
            grid.SetRow(tekst, 1);
            tekst.Anchor = AnchorStyles.Left;

            for (int i = 0; i < ogranicenja; i++)
            {
                for (int j = 0; j <= ogranicenja; j++)
                {
                    if (j == ogranicenja)
                    {
                        Tablica1.Rows[1 + i].Cells[varijable + 2 + j].Style.BackColor = Color.Green;

                    }
                    else
                    {
                        Tablica1.Rows[1 + i].Cells[varijable + 2 + j].Style.BackColor = Color.Gray;
                    }
                }
            }

            tabControl1.Controls.Add(tab);
            tabControl1.SelectedTab = tab;

            TablicaU = Tablica1;
        }
        private void BotunKliknut(object sender, EventArgs e)
        {
            PohranaUVektorU();
        }
        private void PohranaUVektorU()
        {
            u = new decimal[ogranicenja];
            greska = false;

            for (int i = 0; i < ogranicenja; i++)
            {
                try
                {
                    u[i] = Convert.ToDecimal(TablicaU.Rows[i + 1].Cells[stupci - 1].Value);
                }
                catch
                {
                    MessageBox.Show("greska!!!\nUnjeli ste neki drugi znak umjesto broja!!!");
                    greska = true;
                }

                if (u[i] != 0 && u[i] != 1 && u[i] != -1)
                {
                    MessageBox.Show("greska!!!\nUnjeli ste neki broj koji nije 0, 1 ili -1!!!" + u[i].ToString());
                    greska = true;
                }
            }

            if (greska == false)
                KrajPromjeneDSOgranicenja();
        }
        private void KrajPromjeneDSOgranicenja()
        {
            TabPage tab = new TabPage();
            tab.Text = "   KRAJ   ";
            tab.BackColor = Color.White;

            TextBox tekst = new TextBox();

            tekst.TabStop = false;
            tekst.Dock = DockStyle.Fill;
            tekst.BorderStyle = BorderStyle.None;
            tekst.TextAlign = HorizontalAlignment.Center;
            tekst.Multiline = true;
            tekst.Font = new Font("Times New Roman", 13);
            tekst.Text = "OGRANIČENJA KONSTANTI DESNE STRANE OGRANIČENJA\r\n";

            decimal[] temp = new decimal[ogranicenja];
            decimal[] alfa = new decimal[ogranicenja];

            for (int i = 0; i < ogranicenja; i++)
            {
                temp[i] = 0;
                for (int j = 0; j < ogranicenja; j++)
                {
                    temp[i] += matrica[1 + i, varijable + j] * u[j];
                }
                if (temp[i] != 0)
                    alfa[i] = Math.Round(-matrica[1 + i, varijable + ogranicenja] / temp[i], 4);

                if (ishodisne[i] <= varijable)
                {

                    if (temp[i] < 0)
                    {
                        tekst.Text += "X*" + ishodisne[i].ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString() + " " + temp[i].ToString() + "*α" + " ≥ 0 \t\t";
                        tekst.Text += "α" + " ≤ " + alfa[i].ToString() + "\r\n";
                    }

                    else if (temp[i] > 0)
                    {
                        tekst.Text += "X*" + ishodisne[i].ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString() + " + " + temp[i].ToString() + "*α" + " ≥ 0 \t\t";
                        tekst.Text += "α" + " ≥ " + alfa[i].ToString() + "\r\n";
                    }

                    else
                    {
                        tekst.Text += "X*" + ishodisne[i].ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString() + " + " + temp[i].ToString() + "*α" + " ≥ 0 \t\t";
                        tekst.Text += "X*" + ishodisne[i].ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString() + "\r\n";
                    }

                }
                else
                {

                    if (temp[i] < 0)
                    {
                        tekst.Text += "S*" + (ishodisne[i] - varijable).ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString() + " " + temp[i].ToString() + "*α" + " ≥ 0 \t\t";
                        tekst.Text += "α" + " ≤ " + alfa[i].ToString() + "\r\n";
                    }

                    else if (temp[i] > 0)
                    {
                        tekst.Text += "S*" + (ishodisne[i] - varijable).ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString() + " + " + temp[i].ToString() + "*α" + " ≥ 0 \t\t";
                        tekst.Text += "α" + " ≥ " + alfa[i].ToString() + "\r\n";
                    }

                    else
                    {
                        tekst.Text += "S*" + (ishodisne[i] - varijable).ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString() + " + " + temp[i].ToString() + "*α" + " ≥ 0 \t\t";
                        tekst.Text += "S*" + (ishodisne[i] - varijable).ToString() + "opt = " + matrica[1 + i, varijable + ogranicenja].ToString() + "\r\n";
                    }
                }
            }

            tekst.Text += "\r\nα mora bit ≥ 0.\r\nα možete naći sami ☺.";
            tab.Controls.Add(tekst);
            tabControl1.Controls.Add(tab);
            tabControl1.SelectedTab = tab;
        }

        #endregion

        #region Postavke

        private void Kreiranje(object sender, EventArgs e)
        {
            PohranaUMatricu();
            if (optimiziranje)
            {
                PohranaIshodisnih();
                switch (lista)
                {
                    case 0:
                        IzracunMaksimuma();
                        KrajMaxMin();
                        break;
                    case 1:
                        IzracunMinimuma();
                        KrajMaxMin();
                        break;
                    case 2:
                        IzracunDualnogSimpleksa();
                        break;
                    case 3:
                        IzracunPromjenaFCOgranicenja();
                        break;
                    case 4:
                        IzracunPromjeneDSOgranicenja();
                        break;
                    default:
                        MessageBox.Show("Nije izabrana metoda!!!");
                        break;
                }
                optimiziranje = false;
            }
        }
        private void IzborMetode(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    lista = 0;
                    break;
                case 1:
                    lista = 1;
                    break;
                case 2:
                    lista = 2;
                    break;
                case 3:
                    lista = 3;
                    break;
                case 4:
                    lista = 4;
                    break;
                case -1:
                    break;
                default:
                    MessageBox.Show("Greska!!!");
                    break;
            }
        }
        private void PromjenaOgranicenja(object sender, EventArgs e)
        {
            if (numericUpDown2.Value < ogranicenja)
                MakniOgranicenja();
            else if (numericUpDown2.Value > ogranicenja)
                DodajOgranicenja();
        }
        private void PromjenaVarijable(object sender, EventArgs e)
        {
            if (numericUpDown1.Value < varijable)
                MakniVarijable();
            else if (numericUpDown1.Value > varijable)
                DodajVarijable();
        }

        private void Help(object sender, EventArgs e)
        {
            string pomoc = "";
            pomoc += "\t\t\tKAKO KORISTITI:\n\nNa vrhu prozora se nalazi izbornik preko kojeg mozete otvoriti novi prozor ili resetirati već otvoreni.";
            pomoc += "\nU sredini prozora se nalazi tablica koju punite sa brojevima danima u zadatku.";
            pomoc += "\n Na dnu izabirete broj varijabli i ogranicenja, metodu te pokrećete program.";
            pomoc += "\n\nKod dualnog simpleksa unesite koeficijente kako su zadani u zadatku.";
            pomoc += "\nKod osjetljivosti desne strane u tab-u \"ODABIR u-a\" zadnji stupac tablice predstavlja \"u\" i u njega se unose njegove vrijednosti.";
            pomoc += "";
            pomoc += "";
            MessageBox.Show(pomoc);
        }
        private void Reset(object sender, EventArgs e)
        {
            InicijalizacijaVarijabli();
            tableLayoutPanel1.Controls.Remove(Tablica);
            Tablica = new DataGridView();
            TabPage tab1 = tab;
            tabControl1.Controls.Clear(); ;
            tabControl1.Controls.Add(tab1);
            CrtanjeTablice();
            comboBox1.SelectedIndex = -1;
        }
        private void NoviProzor(object sender, EventArgs e)
        {
            Form1 prozor = new Form1();
            prozor.Show();
        }

        #endregion

        private void IspisMatrice()
        {
            string testiranje = "";
            for (int i = 0; i <= ogranicenja; i++)
            {
                for (int j = 0; j <= (varijable + ogranicenja + 1); j++)
                {
                    testiranje += matrica[i, j].ToString() + "\t";
                }
                testiranje += "\n";
            }
            MessageBox.Show(testiranje);
        }  //test
    }
}
