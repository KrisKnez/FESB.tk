// PoljeJePokazivac.c
#include <stdio.h>

void f(int *x) {								// ili   void f(int x[]) {
  printf ("%d %d\n", *x, x[0]);
  ++x;													// drugi clan postaje prvi
  printf ("%d %d %d\n", *x, x[0], *(x-1));
}

void main (void) {
  int x[4] = {1,2,3,4};

  printf ("%d %d\n", *x, *(x+1));
  f(x);

	exit(0);
}

