// PrimjerZaMalloc.c
#include <stdlib.h>
#include <malloc.h>

void main (void) {
  short *i;

  i = (short *) malloc (sizeof (short));
  *i = 7;

  exit(0);
}	
