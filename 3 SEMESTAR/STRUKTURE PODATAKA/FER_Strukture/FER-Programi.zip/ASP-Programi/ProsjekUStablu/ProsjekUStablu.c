// ProsjekUStablu.c
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>

typedef struct {
  char artikl[15+1];
  float cijena;
} el;

typedef struct cv {
  el element;
  struct cv *lijevo;
  struct cv *desno;
} cvor;

typedef struct {
  float suma;
  int broj;
} pros;

// upisuje u stablo podatke: lijevo manji, desno veci
cvor *upis (cvor *glava, el element) { 
  int smjer;
  if (glava == NULL) {
    glava = (cvor *) malloc (sizeof (cvor));
		if (glava) {
			glava->element = element;
      //strcpy (glava->element.artikl, element.artikl);
      //glava->element.cijena = element.cijena;
      glava->lijevo = glava->desno = NULL;
		} else {
			printf ("Nema dovoljno memorije!\n");
		}
  } else if ((smjer = strcmp (element.artikl, glava->element.artikl)) < 0) {
    glava->lijevo = upis (glava->lijevo, element);
  } else if (smjer > 0) {
    glava->desno  = upis (glava->desno, element);
  } else {
    printf ("Podatak '%s' vec postoji!\n", element.artikl);
  }
  return glava;
}

// ispis inorder
void ispisin (cvor *glava) {
  if (glava != NULL) {
    ispisin (glava->lijevo);
    printf ("%-15s %6.2f\n", glava->element.artikl, glava->element.cijena);
    ispisin (glava->desno);
  }        
}

// sumiranje cijena i brojanje elemenata element po element
void prosjek (cvor *glava, pros *prs) {
  if (glava != NULL) {
		prs->suma += glava->element.cijena;
		prs->broj++;
    prosjek (glava->lijevo, prs);
    prosjek (glava->desno, prs);
  }
}

// brojanje elemenata stabla
int prebroji (cvor *glava) {
  if (glava != NULL) {
    return prebroji (glava->lijevo) + 1 + prebroji (glava->desno);
  } else {
    return 0;
  }
}

// sumiranje cijena i brojanje elemenata po podstablima
pros prosjek1 (cvor *glava) {
  pros prs, prslijevo, prsdesno;
  if (glava != NULL) {
    prslijevo = prosjek1 (glava->lijevo);
    prsdesno = prosjek1 (glava->desno);
    prs.broj = prslijevo.broj + 1 + prsdesno.broj; 
    prs.suma = prslijevo.suma + glava->element.cijena + prsdesno.suma;
  } else {
    prs.broj = 0; prs.suma = 0;
  }
  return prs;
}

void main(void) {
  FILE *fi;				// ulazna datoteka
  int j;					// brojac elemenata
  cvor *glava;		// pokazivac na korijen
  el element;			// sadrzaj cvora
	pros prs, prs1;	// broj elemenata i suma cijena

	// inicijalizacija
	prs.suma = 0.; prs.broj = 0;
  fi = fopen ("UlazZaProsjekUStablu.txt", "r");
  if (!fi) {
    printf ("Nema ulaznih podataka\n");
		exit (1);
  }

	// citanje i upis
  j = 1;
  glava = NULL;
  while (fscanf (fi, "%s %f", element.artikl, &element.cijena) != EOF) {
    printf ("%2d. ulazni podatak je %-15s %6.2f\n", j++, element.artikl, element.cijena);
    glava = upis (glava, element);
  }
  fclose (fi);

	// ispis, racun sume cijena i broja elemenata
	getchar ();
  ispisin (glava);
	getchar ();
	prosjek (glava, &prs);

	if (prs.broj) {
    printf ("Suma=%f, Broj cvorova=%d, Prosjek=%f\n",
			prs.suma, prs.broj, prs.suma / prs.broj);

		printf ("Broj cvorova (bez argumenta funkcije) = %d\n", prebroji (glava));
		
		printf ("Izracunato na drugi nacin:\n");
		prs1 = prosjek1(glava);
		printf ("Suma=%f, Broj cvorova=%d, Prosjek=%f\n",
			prs1.suma, prs1.broj, prs1.suma / prs1.broj);
		
		// varijante:
		printf ("Prosjek varijanta a) = %f\n",
			prs1.suma / prebroji (glava));
		printf ("Prosjek varijanta b) = %f\n",
			(prosjek1 (glava)).suma / (prosjek1 (glava)).broj);
		getchar ();
  }

	exit (0);
}