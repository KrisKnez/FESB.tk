// IndirektnaZamjenaVrijednosti.c
#include <stdlib.h>

void main (void) {
	short a, b;
	short *p;
	
	p = &a;
	*p = 7;
	b = a;

	exit(0);
}


