// RedPoljem.c
#include <stdlib.h>
#include <stdio.h>
#define MAXRED 10
typedef int tip;

// dodaje element u polje red od max n clanova
// vraca 1 ako ima mjesta u redu, inace 0
// mijenja ulaz, tj straznji kraj
int DodajURed (tip element, tip red[], int n, int izlaz, int *ulaz) {
  if (((*ulaz+1) % n) == izlaz) return 0;
  (*ulaz)++; 
  *ulaz %= n;
  red [*ulaz] = element;
  return 1;
}

// logicki uklanja element iz polja red od max n clanova
// vraca 1 ako ima clanova u redu, inace 0
// mijenja izlaz, tj prednji kraj
int SkiniIzReda (tip *element, tip red[], int n, int *izlaz, int ulaz) {
  if (ulaz == *izlaz) return 0;
  (*izlaz) ++; 
  *izlaz %= n;
  *element = red[*izlaz];
  return 1;
}

// vraca broj elemenata u redu
int prebroji (int n, int izlaz, int ulaz) {
  if (ulaz >= izlaz) {		
		return (ulaz - izlaz);		// standardno
	} else {
	  return (ulaz - izlaz + n);// cirkularnost
	}
}

void main (void) {
  int red[MAXRED];					// polje za red
  int element, ulaz, izlaz;	// element, krajevi reda
  FILE *fi;									// ulazna datoteka
	
	// inicijalizacija
  ulaz = 0; izlaz = 0;
	fi = fopen ("UlazZaRed.txt", "r");
	if (fi) {
		while (fscanf (fi, "%d", &element) != EOF) {
  		// stavljanje u red
      if ((DodajURed (element, red, MAXRED, izlaz, &ulaz))) {
				printf ("U red dodan element %d\n", element);
				printf ("Broj elemenata u redu je %d\n", 
									prebroji (MAXRED, izlaz, ulaz));

			} else {	
				printf ("Nema vise mjesta u redu\n");
				// break;
		
				// uklanjanje iz reda
				while (SkiniIzReda (&element, red, MAXRED, &izlaz, ulaz)) {
					printf ("Iz reda skinut element %d\n", element);
					printf ("Broj elemenata u redu je %d\n", 
										prebroji (MAXRED, izlaz, ulaz));
				}
      }
    }
    fclose (fi);
		
		// uklanjanje preostalih elemenata
		while (SkiniIzReda (&element, red, MAXRED, &izlaz, ulaz)) {
			printf ("Iz reda skinut element %d\n", element);
			printf ("Broj elemenata u redu je %d\n", 
								prebroji (MAXRED, izlaz, ulaz));
		}



  } else {
    printf ("Nema ulazne datoteke\n");
		exit (1);
  }
	exit (0);
}
