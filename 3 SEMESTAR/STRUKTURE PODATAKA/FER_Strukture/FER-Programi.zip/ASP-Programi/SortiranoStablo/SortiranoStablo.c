// SortiranoStablo.c
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>

struct cv {
  char element[15];
  struct cv *lijevo;
  struct cv *desno;
};
typedef struct cv cvor;

// upisuje u stablo podatke: lijevo manji, desno veci
cvor *upis (cvor *glava, char element[]) { 
  int smjer; // odluka o podstablu

  if (glava == NULL) { // prazno (pod)stablo
		glava = (cvor *) malloc (sizeof (cvor));
		if (glava) {
		  strcpy (glava->element, element);
		  glava->lijevo = glava->desno = NULL;
		} else {
			printf ("U memoriji mena mjesta za upisati '%s'\n", element);
		}
	} else if ((smjer = strcmp (element, glava->element)) < 0) { 
	  glava->lijevo = upis (glava->lijevo, element);
	} else if (smjer > 0) {
		glava->desno  = upis (glava->desno, element);
	} else {
		printf ("Podatak '%s' vec postoji!\n", element);
	}
  return glava; // pokazivac na zadnji element
}

// obilazak inorder lijevo-desno
void ispisinld (cvor *glava) {
  if (glava != NULL) {
		ispisinld (glava->lijevo);
    printf ("%s \n", glava->element);
    ispisinld (glava->desno);
  }        
}

// obilazak inorder desno-lijevo
void ispisindl (cvor *glava) {
  if (glava != NULL) {
		ispisindl (glava->desno);
    printf ("%s \n", glava->element);
    ispisindl (glava->lijevo);
  }        
}  

// obilazak preorder
void ispispre (cvor *glava) {
  if (glava != NULL) {
    printf ("%s \n", glava->element);
    ispispre (glava->lijevo);
    ispispre (glava->desno);
  }        
} 

// obilazak postorder
void ispispost (cvor *glava) {
  if (glava != NULL) {
    ispispost (glava->lijevo);
    ispispost (glava->desno);
    printf ("%s \n", glava->element);
  }        
}

// ispis stabla
void ispissta (cvor *glava, int nivo) {
  int i;
  if (glava != NULL) {
    ispissta (glava->desno, nivo+1);
    for (i = 0; i < nivo; i++) printf("    ");
    printf ("%s \n", glava->element);
    ispissta (glava->lijevo, nivo+1);
  }
}

// trazenje cvora u binarnom stablu
cvor *trazi (cvor *glava, char element[]) {
	int smjer;
	if (glava) {
		if ((smjer = strcmp (element, glava->element)) < 0) {
			return trazi (glava->lijevo, element);
		} else if (smjer > 0) {
			return trazi (glava->desno, element);
		}
	}
	return glava; // ili je pronadjen ili NULL;
}

void main(void) {
  FILE *fi;					// ulazna datoteka
  int j;						// brojac podataka
  cvor *glava, *p;	// pokazivac na korijen, pomocni pokazivac
  char ime[15];			//

  fi = fopen ("UlazZaSortiranoStablo.txt", "r");
  if (fi) {
		// inicijalizacija i citanje podataka
    j = 1;
    glava = NULL;
    while (fscanf (fi, "%s", &ime) != EOF) {
      printf ("%d. ulazni podatak je %s \n", j++, ime);
      glava = upis (glava, ime);
    }
    fclose (fi);

		// obilazak i ispis stabla

		getchar ();
    printf ("Ispis inorder lijevo-desno\n");
    ispisinld (glava);
		
		getchar ();
    printf ("Ispis inorder desno-lijevo\n");
    ispisindl (glava);
		
		getchar ();
    printf ("Ispis preorder\n");
    ispispre (glava);
		
		getchar ();
    printf ("Ispis postorder\n");
    ispispost (glava);
		
		getchar ();
    printf ("Ispis stabla\n");
    ispissta (glava, 0);

		// trazenje elementa
		while (1) {
			printf ("Unesite element koji trazite, ili KRAJ >");
			scanf ("%s", ime);
			if (stricmp (ime, "KRAJ") == 0) break;
			p = trazi (glava, ime);
			if (p) {
				printf ("Pronadjen je element: %s\n", p->element);
			} else {
				printf ("Nije pronadjen element: %s\n", ime);
			}
		}
  } else {
    printf ("Nema ulaznih podataka\n");
		exit (1);
  }
	exit (0);
}
