// StogPoljem.c
#include <stdio.h>
#include <stdlib.h> 
#include <time.h>

#define MAXSTOG 5 // maksimalna velicina stoga

int dodaj (int stavka, int stog[], int n, int *vrh) {
  if (*vrh >= n-1) return 0; // dosegnut kapacitet stoga n
  (*vrh)++;									 // ne pisati  *vrh++;
  stog[*vrh] = stavka;
  return 1;
}

int skini (int *stavka, int Stog[], int *vrh) {
	if (*vrh < 0) return 0; // stog je prazan
	*stavka = Stog[*vrh];
	(*vrh)--;
	return 1;
}

void main (void) {
  int novi, stari, stog [MAXSTOG];
  int vrh, i;

  vrh = -1; // prazan stog

	printf ("Slucajno se generiraju nenegativni cijeli brojevi.\n");
	printf ("Neparni brojevi upisuju se na stog\n");
	printf ("Parni broj simulira skidanje sa stoga\n");
	printf ("Za obavljanje jednog koraka pritisnuti ENTER, za kraj CTRL-C\n\n");

	// Inicijalizacija generatora pseudoslucajnih brojeva
	// na temelju sistemskog vremena
	srand ((unsigned) time (NULL));

	while (1) {				// "beskonacna" petlja
		if (vrh == -1) {
			printf ("(prazan stog)");
		} else {
			printf ("Stog:");
			for (i=0; i <= vrh; ++i) printf (" %d", stog[i]);
		}
		putchar ('\n');	
		getchar ();
		
		novi = rand ();

		if (novi%2) {		// Neparni se upisuju na stog
			printf ("Dodaj %d\n", novi);
			if (!dodaj (novi, stog, MAXSTOG, &vrh)) printf("Stog je pun!\n");
    
		} else {				// Parni broj simulira skidanje sa stoga
			
			printf ("Skini...");
			if (skini (&stari, stog, &vrh))	{
				printf ("Skinut %d\n", stari);
			} else {
				printf("Stog je prazan!\n");
			}
    }
  }

	exit(0);
}
