// Lista.c
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

typedef int tip;

struct cv {
  tip element;
  struct cv *sljed; 
};
typedef struct cv cvor;

// Dodavanje u listu 
// sortiranu po rastucoj vrijednosti elementa
// vraca 1 ako uspije, inace 0
int dodaj (cvor **glavap, tip element) {
  cvor *novi, *p;

  if ((novi = (cvor *) malloc(sizeof(cvor))) == NULL) 
		return 0;

  novi->element = element;
  if (*glavap == NULL || (*glavap)->element >= element) {
    // Dodavanje na pocetak liste
    novi->sljed = *glavap;
    *glavap = novi;
  
	} else {
    // Dodavanje iza postojeceg elementa kad:
		// a) postoje�i cvor nema sljede�eg
		// b) element u sljede�em cvoru je ve�i ili jednak novome
		for (p = *glavap; p->sljed && (p->sljed)->element < element; p = p->sljed)
			;
		novi->sljed = p->sljed;
		p->sljed = novi;
  }
  return 1;
}

// ispis elemenata liste
void ispisi (cvor *glava) {
  cvor *p;

  for (p = glava; p != NULL; p = p->sljed) {
    printf ("Na adresi %p je %d koji gleda na %p\n", 
			p, p->element, p->sljed);
  }
}

// trazenje elementa liste
// vraca pokazivac na trazeni element ili NULL ako ga ne nadje
cvor *trazi1 (cvor *glava, tip element) {
  cvor *p;

  for (p = glava; p != NULL; p = p->sljed) {
		if (p ->element == element) 
			return p;
  }
	return NULL;
}

// trazenje elementa liste - inacica 2
cvor *trazi2 (cvor *glava, tip element) {
  cvor* p;
  for (p = glava; p && p->element != element; p = p->sljed)
		;
  return p;
}

// trazenje elementa liste - inacica 3
cvor *trazi3 (cvor *glava, tip element) {
  for (; glava && glava->element != element; glava = glava->sljed)
		;
  return glava;
}

// brisanje elementa liste po kljucu
// koristenjem funkcije trazi
int brisi (cvor **glavap, tip element) {
  cvor *p, *pp;

  if ((p = trazi1 (*glavap, element)) == NULL) //ili trazi2 ili trazi3
		return 0; 

	if (p == *glavap) {	// Brisanje s pocetka liste
		
		pp = (*glavap)->sljed;
		free (*glavap);
		*glavap = pp;

	} else {						// Brisanje iza clana liste
		// pronadji prethodni cvor
		for (pp = *glavap; pp->sljed != p; pp = pp->sljed)
			;
		// Povezi prethodni cvor sa sljedbenikom izbrisanog cvora
		pp->sljed = p->sljed;
		// oslobodi memoriju zauzetu elementom koji se brise
		free (p);
	}
	return 1;
}

// Brisanje elementa liste po kljucu
// Objedinjuje tra�enje i brisanje
int brisi1 (cvor **glavap, tip element) {
	cvor *p;

  for (; *glavap && (*glavap)->element != element; glavap = &((*glavap)->sljed))
		;

  if (*glavap) {
		p = *glavap;
		*glavap = (*glavap)->sljed;
		free (p);
		return 1;
	} else {
		return 0;
	}
}


void main (void) {
  int element, j; // element i brojac elemenata
  cvor *glava;		// glava liste
  FILE *fi;				// ulazna datoteka

	// inicijalizacija
  fi = fopen ("UlazZaListu.txt", "r");
  if (!fi) exit (1);
  glava = NULL;
  j = 0;

	// citanje i dodavanje elemenata
  while (fscanf (fi, "%d", &element) != EOF) {
    printf  ("%d. ulazni podatak je %d \n", ++j, element);
    if ((dodaj (&glava, element))) {
      ispisi (glava);
		}	else {
      printf ("Nema vise mjesta\n");
	    break;
    }
  }
  fclose (fi);
  printf ("\n");
	// trazenje i brisanje elemenata
  do {
		ispisi (glava);
    printf ("Upisite element koji se brise >");
    scanf ("%d", &element);
  } while (brisi (&glava, element));
  //} while (brisi1 (&glava, element));

  printf  ("Nema trazenog elementa!\n");

	exit (0);
}
