// StogListom.c
#include <stdio.h>
#include <malloc.h>

typedef int tip;
struct cv {
  tip element;
  struct cv *sljed; 
};
typedef struct cv cvor;

// dodaje element na vrh stoga
cvor *dodaj (cvor *vrh, tip element) { 
  cvor *novi; // pokazivac na novi cvor

  if ((novi = (cvor *) malloc(sizeof(cvor))) != NULL) { 
    novi->element = element; 
    novi->sljed = vrh;
    printf("Na adresu %p dodao sam %d, a sljedeci je %p\n",
											novi, element, vrh);
  }

  return novi;	// vrati pokazivac na novi cvor
}

// skida element s vrha stoga
cvor *skini (cvor *vrh, int *element) {
	cvor *pom;				// pomocni pokazivac

  *element = vrh->element; 
	printf ("S adrese %p ", vrh);
	pom = vrh->sljed;	// sacuvaj novi vrh
  free (vrh);				// oslobodi vrh
  return pom;				// vrati novi vrh
}

void main (void) {
  FILE *fi;			// ulazna datoteka
  int j;				// brojac ulaznih podataka
  int element;	// element stoga
  cvor *vrh, *p;// pokazivac na vrh i pomocni pokazivac 	

	// Upis podataka na stog
  fi = fopen ("UlazZaStogListom.txt", "r");
  if (fi) {
		// inicijalizacija
		vrh = NULL;
		j = 0;
		// citanje podataka i stavljanje na stog
    while (fscanf (fi, "%d", &element) != EOF) {
			j++;
      if ((p = dodaj (vrh, element)) != NULL) {
        vrh = p;
				printf ("%d. ulazni podatak je %d\n", j, vrh->element);
      } else {
        printf("Nema vise mjesta za stog\n");
	      break;
      }
    }
    fclose (fi);
    p = vrh;
		// Skidanje elemenata sa stoga
    while (vrh) {
      vrh = skini (vrh, &element);
      printf ("skinuo sam element %d\n", element);
    }

  } else {
    printf ("Nema ulazne datoteke\n");
		exit (1);
  }

	exit (0);
}
