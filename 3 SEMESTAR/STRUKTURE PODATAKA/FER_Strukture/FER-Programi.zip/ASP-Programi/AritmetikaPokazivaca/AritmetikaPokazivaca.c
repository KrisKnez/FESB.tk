// AritmetikaPokazivaca.c
#include <stdlib.h>

void main (void) {
	long dugi; double dupli;		
	long *pdugi; double *pdupli;
	short veldugi, veldupli;

	veldugi = sizeof (dugi);
	pdugi = &dugi;				
	++pdugi;

	veldupli = sizeof (dupli);
	pdupli = &dupli;					
	pdupli = pdupli + 2;

	exit(0);
}
