// ElementarnaRekurzija.c
#include <stdlib.h>
#include <malloc.h>

void f (int i) {
	int p[40000];
	f (i+1);
	return;
}

void main (void) {
	f(1);
	exit(0);
}
