// datoteka: copyf1.cpp
// kopiranje datoteka
#include <iostream>
#include <fstream>
using namespace std;

void error(char*str)
{
	cout << str << endl;
	exit(1);
}

int main()
{
 
    ifstream ulaz ;
	ofstream izlaz;
	
	ulaz.open("copyf1.cpp") ;
	if (!ulaz.good() || !ulaz.is_open()) 
		 error("Ne moze se otvoriti ulazna datoteka") ;
	
	 izlaz.open("copyf1.bak") ;
	if (!izlaz.good() || !izlaz.is_open()) 
		 error("Ne moze se otvoriti izlazna datoteka") ;
    // kopiraj znak po znak iz ulaza na izlaz
    char c ;
    while (ulaz.get(c)) 
		izlaz.put(c) ;
	//zatvori datoteku
	ulaz.close();
	izlaz.close();
    return 0;
}

