/* Program fseek.cpp */
#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;

#define MAX 50

int main()
{
    int data, i, niz[MAX];
    long indeks;

    /* Inicijaliziraj niz od 50 elemenata po slucajnom uzorku */
    for (i = 0; i < MAX; i++)
        niz[i] = rand();

    /* Otvori binarnu datoteku RANDOM.DAT za �itanje i pisanje. */
	fstream file("RANDOM.DAT", ios::binary|ios::in| ios::out);
    if (!file)
    {
        cerr << "\nGreska pri otvaranje datoteke";
        exit(1);
	}
	/* upi�i niz */
    file.write((char *) niz, sizeof(niz));
	   
    /* Pitaj korisnika koji element zeli ucitati, */
    /* zavrsi ako se unese negativna vrijednost */
    while (1)
    {
        cout << "\nIzaberi element datoteke: 0 - " <<MAX-1 << " ili -1 za kraj: ";
        cin >> indeks;
        if (indeks < 0)
            break;
        else if (indeks > MAX-1)
            continue;
        /* Postavi pozicijski indikator datoteke */
        file.seekg(indeks*sizeof(int), ios::beg);
		/* Zatim u�itaj element i prikazi njegovu vrijednost. */
        file.read((char*)&data, sizeof(int));
        cout <<"\nElement " << indeks 
		      <<" ima vrijednost " << data;
    }
	cout << "Kraj" << endl;
    return(0);
}

