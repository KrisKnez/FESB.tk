// datoteka: binfile.cpp
#include <iostream>
#include <fstream>
using namespace std;

class Tocka
{
	int m_x, m_y;
    public:
       Tocka(int x=0, int y=0):m_x(x), m_y(y){}
       int x() const { return m_x; }
       void x(int x) { m_x =x; }
	   int y() const { return m_y; }
       void y(int y) { m_y =y; }       
};

int main() 
    {
       char imedatoteke[80];
       char buffer[255];

       cout << "Upisite ime datoteke: ";
       cin >> imedatoteke;
       ofstream fout(imedatoteke, ios::binary);
       if (!fout)  {
		cout << "Ne moze se otvoriti " << imedatoteke << " za pisanje.\n";
        return(1);
       }

       Tocka T1(50,100);
       fout.write((char*) &T1,sizeof (Tocka));

       fout.close();

       ifstream fin(imedatoteke,ios::binary);
       if (!fin)
       {
		   cout << "Ne moze se otvoriti " << imedatoteke << " za citanje.\n";          
          return(1);
       }
       
	   Tocka T2;
       fin.read((char*) &T2, sizeof(Tocka));
       cout << "Tocka x=" << T2.x() << " y=" << T2.y() << endl;
       	   
       return 0;
}



