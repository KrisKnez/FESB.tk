// Datoteka: get.cpp 
// Upotreba get() s parametrom tipa char&
#include <iostream>
using namespace std;
int main()
{
    char a, b, c;
    cout << "Otipkaj tri slova: ";
    cin.get(a).get(b).get(c);
    cout << "a: " << a << "\nb: " << b << "\nc: " << c << endl;
    return 0;
}

