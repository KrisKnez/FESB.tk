//// datoteka: fill.cpp
#include <iostream>
using namespace std;

int main()
{
	cout << "123456789012345678901234567890\n";
    cout.width(25);
    cout << 123 << "| End\n";

    cout.width(25);
    cout.fill('*');
    cout << 123 << "| End\n";
    return 0;
}

