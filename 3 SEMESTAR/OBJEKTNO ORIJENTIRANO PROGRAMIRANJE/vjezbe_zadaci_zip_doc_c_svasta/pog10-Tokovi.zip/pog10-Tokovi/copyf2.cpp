// datoteka: copyf2.cpp
// kopiranje datoteka
#include <iostream>
#include <fstream>
using namespace std;

void error(char*str)
{
	cout << str << endl;
	exit(1);
}

int main()
{
 
    ifstream ulaz("copyf2.cpp") ;
	if (!ulaz) 
		 error("Ne moze se otvoriti ulazna datoteka") ;
	
	ofstream izlaz("copyf2.bak") ;
	if (!izlaz) 
		 error("Ne moze se otvoriti izlazna datoteka") ;
    while (ulaz.get(c)) 
	izlaz.put(c) ;
    return 0;
}

