// datoteka: append.cpp
#include <iostream>
#include <fstream>
using namespace std;

     
int main()  
{
	char imedatoteke[80];
    char buffer[255];
    cout << "Otipkaj ime datoteke: ";
    cin >> imedatoteke;

    ifstream fin(imedatoteke);
    if (fin)                // datoteka postoji
    {
        cout << "Trenutni sadrzaj datoteke:\n";
        char ch;
        while (fin.get(ch))
            cout << ch;
        cout << "\n*** Kraj***\n";
    }

	fin.close();

    cout << "\nOtvara " << imedatoteke << " u append modu...\n";

	ofstream fout(imedatoteke,ios::app);
    if (!fout)
    {
        cout << "Ne moze otvoriti " << imedatoteke << endl;
         return(1);
	}

    cout << "\nTekst koji spremas u datoteku: ";
    cin.ignore(1,'\n');
    cin.getline(buffer,255);
    fout << buffer << "\n";
    fout.close();

	fin.open(imedatoteke);  // reassign existing fin object!
    if (!fin)
    {
		cout << "Ne moze otvoriti " << imedatoteke << endl;  
		return(1);
    }
	cout << "\nSadrzaj datoteke je:\n";
	char ch;
    while (fin.get(ch))
          cout << ch;
    cout << "\n***Kraj***\n";
	fin.close();
    return 0;
 }

