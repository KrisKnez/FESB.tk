// Datoteka: format1.cpp 
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

// formatiranje pomo�u manipulatora
int main()
{
    const double PI = acos( - 1); // arccos(-1) = PI
    const int MAX = 10;
    const int TAB = 15;
    int k;
	cout << "predodredjeni format " << PI 
	     << ", sa setprecision(4), " << setprecision(4) << PI 
	     << endl;
    cout << "\nfixed/scientific realni brojevi, promjenljive preciznosti ispisa"  << endl;
	
    for(k=0; k < MAX; k++)
    {
		cout << left << "pre. " << k << "\t" << setprecision(k) << setw(TAB)
           << fixed << PI << scientific << "\t" << PI << endl;
    }

    return 0;
} 
