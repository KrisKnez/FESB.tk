// datoteka: setf.cpp
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    const int number = 185;
    cout << "Broj je " << number << endl;

    cout << "Broj je  " << hex <<  number << endl;

    cout.setf(ios::showbase);
    cout << "Broj je " << hex <<  number << endl;

    cout << "Broj je " ;
    cout.width(10);
    cout << hex << number << endl;

    cout << "Broj je " ;
    cout.width(10);
    cout.setf(ios::left);
    cout << hex << number << endl;

    cout << "Broj je " ;
    cout.width(10);
    cout.setf(ios::internal);
    cout << hex << number << endl;

    cout << "Broj je " << setw(10) << hex << number << endl;
     return 0;
}