
// datoteka getch.cpp
#include <iostream>
#include <conio.h>
using std::cout;
int main()
{
    char ch;
    cout << "Va� izbor je: " << endl;
    cout << "1. ponedjeljak" << endl;
    cout << "2. utorak" << endl;
    cout << "3. srijeda" << endl;
    cout << "pritisni  tipku 1, 2  ili 3" << endl;
    do {
       ch = getch();
    }
    while (ch != '1' && ch != '2' &&  ch != '3');

    switch (ch) {
      case '1': cout <<"ponedjeljak"<< endl; break;
	  case '2': cout <<"utorak"<< endl; break;
	  case '3': cout <<"srijeda"<< endl; break;
	}
	return 0;
}

