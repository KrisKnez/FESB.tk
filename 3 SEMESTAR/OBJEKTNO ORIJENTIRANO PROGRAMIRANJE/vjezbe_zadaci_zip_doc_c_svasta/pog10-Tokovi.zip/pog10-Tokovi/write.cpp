// datoteka: write.cpp
#include <iostream>

using namespace std;

int main()
{
     char str[] = "Vidi ovo!";

     int fullLength = strlen(str);
     int shortLength = fullLength - 4;
 
     cout.write(str,fullLength) << "\n";
     cout.write(str, shortLength) << "\n";
     return 0;
}
