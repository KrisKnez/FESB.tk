// Datoteka: get.cpp 
// Upotreba get() s parametrom tipa char&
#include <iostream>
using namespace std;

class Tocka {
public:
	int x;
    int y;
} ;

ostream& operator<<(ostream& out, const Tocka& t) 
{
    return out << t.x << " " << t.y ;
}

 istream& operator>>(istream& in, Tocka& t)
 {
	in >> t.x >> t.y ;
	if (!in)  // lo� unos, primjerice otipkano slovo
		return in;
    // ili ako �elimo unos pozitivnih vrijednosti
	if (t.x < 0 || t.y < 0) 
	{
         in.setstate(ios::badbit | in.rdstate()) ;
    }
  return in ;
}

int main()
{
    Tocka a;
    cout << "Unesi koordinate tocke: ";
    cin >> a;
	if(cin.good()) // nema gre�ke
		cout << "Unijeli ste: " << a << endl;
	else
		cout << "Krivi unos! " << endl;
    return 0;
}

