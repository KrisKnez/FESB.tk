// Datoteka: format2.cpp 
#include <iostream>
#include <cmath>
using namespace std;

// formatiranje pomo�u �lanskih funkcija
int main()
{
    const double PI = acos( - 1); 
    int k;
    // postavi poravnanje s desna i fixed floating format
    cout.setf(ios::right, ios::adjustfield);
    cout.setf(ios::fixed, ios::floatfield);
    cout << "desno poravnani format, sirine 10" << endl;
	cout << "promjenljiva preciznost 0-10 \n" << endl;
 
    for(k=0; k <= 10; k++)
    {   cout.precision(k);
        cout << k << "\t|";
        cout.width(12);
        cout << PI << "|" << endl;
    }
    
    return 0;
} 
