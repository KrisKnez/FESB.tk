// datoteka: fileio.cpp
#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    char imedatoteke[80];
    char buffer[255];   
    cout << "Ime datoteka: ";
    cin >> imedatoteke;
	cin.ignore(1,'\n'); 
	
    ofstream izlaz(imedatoteke);  // formiraj izlaznu datoteku 
    
    cout << "Otkucajte liniju teksta: ";
    cin.getline(buffer,255);  // dobavi tekst s tipkovnice
    // Upisi taj tekst u datoteku 
	izlaz << buffer << "\n";   
    izlaz.close();             // zatvori datoteku 

    ifstream ulaz(imedatoteke);    // otvori datoteku za �itanje sadr�aja
    cout << "\nU datoteci je upisan tekst: \n";
	// Dobavi i ispi�i sadr�aj datoteke
    char ch;
    while (ulaz.get(ch))
        cout << ch;
    cout << "\n***Kraj***\n";
    return 0;
}
