// Datoteka: peek.cpp
#include <iostream>
#include <ctype.h>
using namespace std;

int main()
{
    char ch;
    cout << "Unesi frazu: ";
    while (cin.get(ch) )
    {
       if (islower(ch))
          cin.putback(toupper(ch));
       else
          cout << ch;
       while (cin.peek() == ' ')
          cin.ignore(1,' ');
	   if(cin.peek() == '\n') break;
   }
   return 0;
}



