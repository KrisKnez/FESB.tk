/* Datoteka fact2.cpp 
 * Prora�un n!. Vrijednost od n unosi korisnik. 
 * Vrijednost od n mora biti unutar intervala [0,13]
 */

#include <iostream> 
using namespace std;

int main()
{
   int n, k, nfact;

   cout << "Unesite broj unutar intervala [0,13]\n";
   cin >> n;                               

   if((n < 0) || (n > 13))
   {
      cout << "Otipkali ste nedozvoljenu vrijednost";
      return 1;         // forsirani izlaz iz funkcije main 
   }

   nfact = 1; 
   k = 1;

   while ( k < n)
   {
         k = k + 1;             
         nfact = k * nfact;
   } 

   cout << "Vrijednost" << n << "! " 
          << "iznosi: " << nfact << endl;

   return 0;
}
