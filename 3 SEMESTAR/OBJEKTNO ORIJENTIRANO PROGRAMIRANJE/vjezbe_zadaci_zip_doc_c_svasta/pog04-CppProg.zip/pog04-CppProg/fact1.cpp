/* Datoteka: fact1.cpp 
 * Prora�un n!. Vrijednost od n unosi korisnik. 
 ***********************************************/

#include <iostream> 
using namespace std;

int main()
{
   int n, k, nfact;       // deklaracija potrebnih varijabli
                           
   cin >> n;               // korak 1
                           // korak 2 
   nfact = 1;                   // korak 2.1   
   k = 1;                       // korak 2.2   
   while ( k < n)               // korak 2.3   
   {
       k = k + 1; 
       nfact = k * nfact;    
   }                            
						   // korak 3 
   cout << "Vrijednost" << n << "! " 
        << "iznosi: " << nfact << endl;
   return 0;
}
