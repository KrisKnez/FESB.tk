/* Datoteka fact4.cpp 
 * Prora�un n! pomo�u funkcije factorial(n) 
 * Vrijednost od n mora biti unutar intervala [0,13]
 ****************************************************/

#include <iostream> 
using namespace std;

// definicija funkcije za prora�un n faktorijela 

int factorial(int n)
{
   int k = 1, nfact = 1; 

   while (k < n)
   { 
      k = k + 1;
      nfact = k * nfact;
   } 
   return nfact;
}

int main()
{
   int n;

   cout << "Unesite broj unutar intervala [0,13]\n";
   cin >> n; 

   if((n < 0) || (n > 13))
         cout << "Otipkali ste nedozvoljenu vrijednost";
   else
    	cout << "Vrijednost " << n << "! "
            << "iznosi: " << factorial(n) << endl;

   return 0;
}
