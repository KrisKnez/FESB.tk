/*Datoteka: ex-pre.cpp*/

#include <iostream> 
#include <math.h>

using namespace std;

double my_exp(double x, double epsilon=0.000001); 

int main( void) 
{
    double eps, x, ex;
    cout << " Unesi vrijednost x:\n";
    cin >> x;

    ex = my_exp(x);

    cout << " e^" << x << "=" << ex
         << " (tocno: " << exp(x) << ")" << endl;
    return 0;
}

double my_exp(double x, double epsilon) 
{
   int i = 1;
   double pribroj = 1.0;
   double ex = 1.0, preth_ex = 0.0;
 
   while (fabs( ex - preth_ex) > epsilon) 
   {
  		preth_ex = ex;
	 	pribroj = pribroj * x / i;
  		ex = ex + pribroj;
  		i = i + 1;
   }
   return ex;
}
