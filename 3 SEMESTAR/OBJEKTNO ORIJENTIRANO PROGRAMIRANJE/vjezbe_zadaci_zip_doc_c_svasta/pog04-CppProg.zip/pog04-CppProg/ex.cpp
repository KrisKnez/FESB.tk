/*Datoteka: ex.cpp*/

#include <iostream> 
#include <math.h>

using namespace std;

double my_exp(double x, double epsilon) 
{
   int i = 1;
   double pribroj = 1.0;
   double ex = 1.0, preth_ex = 0.0;
 
   while (fabs( ex - preth_ex) > epsilon) 
   {
  		preth_ex = ex;
	 	pribroj = pribroj * x / i;
  		ex = ex + pribroj;
  		i = i + 1;
   }
   return ex;
}


int main( void) 
{
    double eps, x, ex;
    cout << " Unesi x i preciznost eps:\n";
    cin >> x >> eps;

    ex = my_exp(x, eps);

    cout << " e^" << x << "=" << ex
         << " (tocno: " << exp(x) << ")" << endl;
    return 0;
}
