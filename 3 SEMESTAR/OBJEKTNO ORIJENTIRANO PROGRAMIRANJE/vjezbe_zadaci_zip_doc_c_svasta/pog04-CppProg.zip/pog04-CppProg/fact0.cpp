/* Datoteka fact0.cpp - Prora�un 5! */

#include <iostream> 
using namespace std;

int main()
{
  int nfact;
  nfact = 1 * 2 * 3 * 4 * 5; 
  cout << "Vrijednost 5! iznosi:" << nfact << endl;
  return 0;
}
