// datoteka: strtok2.cpp
#include <iostream>
#include <string>
#include <sstream>
using namespace std;
    
int main()
{
    istringstream  istr("123 345");  
    int x;

    istr.seekg(2);         // preskoci "12"
    istr >> x;             // dobavi int
    cout << x << endl;     // ispisi vrijednost x
    istr.seekg(0);         // ponovi od pocetka toka
    istr >> x;             // dobavi int
    cout << x << endl;     // ispisi vrijednost x
    istr.str("666");       // spremi neki drugi tekst
    istr >> x;             // dobavi int
    cout << x << endl;     // ispisi vrijednost x
	return 0;
}
    /*
    Dobije se ispis:
    3
    123
    666
    */
