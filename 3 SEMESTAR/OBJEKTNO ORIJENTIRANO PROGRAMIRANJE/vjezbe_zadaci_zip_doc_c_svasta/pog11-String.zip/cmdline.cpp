// Datoteka: cmdline.cpp 
#include <iostream>
using namespace std;

int main( int argc, char *argv[]) 
{
int i;
    cout << "Ime programa je:"  
         << argv[0] << endl;
    if (argc > 1)
    for (i = 1; i < argc; i++)
        cout << i << ". argument: "
             << argv[i] << endl;
    return 0;
}
