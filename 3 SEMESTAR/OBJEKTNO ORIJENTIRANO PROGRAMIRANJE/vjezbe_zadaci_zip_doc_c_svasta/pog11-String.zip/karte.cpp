// Datoteka: karte.cpp - dijeljenje karata

#include <iostream>
#include <cstdlib> // deklaracija rand()
using namespace std;


char *str_boja[] = {"Srce", "Tref", "Karo", "Pik "};

char *str_lik[]  = {"As", "2", "3", "4", "5", 
                "6",  "7", "8", "9", "10",
                "Jack", "Dama", "Kralj" };

/* alternativni oblik deklaracije
   char str_boja[4][5] = {"Srce", "Tref", "Karo", "Pik "};
 
   char str_lik[13][6]  = {"As", "2", "3", "4", "5", 
                "6",  "7", "8", "9", "10",
                "Jack", "Dama", "Kralj" };
*/
							
#define BROJ_KARATA 52
				
int main( void) 
{
int i, karte[BROJ_KARATA];  
   // poredaj po redu
   for (i = 0; i < BROJ_KARATA; i++) 
	   karte[i] = i;
   // slucajno izmijesaj
   for (i = 0; i < BROJ_KARATA; i++) 
   {
      int k = rand() % BROJ_KARATA; 
      int tmp = karte[i];  // zamijeni karte po slu�ajnom uzorku
	  karte[i] = karte[k];
      karte[k] = tmp;
   }
   // ispisi oznaku karte
   for (i = 0; i < 52; i++)
   cout << str_boja[karte[i]/13] << " -  " 
        << str_lik[karte[i]%13] << endl;
   return 0;
}
