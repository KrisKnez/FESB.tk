#include <iostream>
#include "TString.h"
#include "TString.cpp"

using namespace std;

int main()
{ 
    TString s = "Hello";
	// dodaj znak ','
	s += ',';   
	// ispi�i
	cout << s << endl;
	//dodaj literalni string;
	s = s + " World";
	// dodaj uskli�nik
	char ch= '!';
	s += ch;   
	cout << s << endl;
	//konstruktor iz stringa i kopirni konstruktor 
    TString s2(s);
	// pronadji substring na indeksu 7 duljine 5
    TString s3 = s2.substr(7,5);
    cout << s3 << endl;
    // trazenje znakova i stringova
	int idx = s.find('!');
    cout << "indeks od !: " << idx  << endl;
	if(idx != TString::npos) // ako je indeks > -1 
	    s[idx] = '?';
    idx = s.find("World");
	cout << "indeks od World: " << s.find("World")  << endl;
	//zamijeni veliko u malo slovo
	if(idx != TString::npos) // ako je indeks > -1 
	      s[idx] = tolower(s[idx]);
	cout << s << endl;
	// mozemo koristiti i c-funkcije
	cout << "duljina stringa je:" << strlen(s.c_str()) <<endl;
	// ili koristimo svojstvo automatske pretvorbe tipa string u char *
	cout << "duljina stringa je:" << strlen(s) <<endl;
    return 0;
}
