// Datoteka: calc.cpp 
#include <iostream>
#include <sstream>
#include <string>
#include <cmath>

using namespace std;
// ocekuje se da korisnik na komandnoj liniji otkuca
// calc  ime_funkcije argument  
// (primjerice: c:> calc sin 0.56)
// program ra�una vrijednoost funkcija: sin,cos, tan ili atan, za dati argument

#define NUMFUN 4
typedef double (* tpfun)(double);

string stable[NUMFUN] = {"sin", "cos", "tan", "atan"};
tpfun ftable[NUMFUN] =  {sin, cos, tan, atan};	

int main( int argc, char *argv[]) 
{
	int i, idx= -1;
	double x;
	
	if(argc != 3) {
		cout << "Otkucaj: calc ime_trig_funkcije argument" << endl;
		exit(1);
	}
	
	for(i = 0; i<NUMFUN; i++) {
	    if(stable[i] == argv[1]) {
				idx = i;
			    break;
		}
	}
    
	if(idx < 0) {
		cout << "Otkucli ste krivo ime za funkciju" << endl;
		exit(1);
	}
	
	istringstream istr(argv[2]);
	istr >> x;
    if(istr) {
		cout << "Krivo otkucan argument funkcije" << endl;
		exit(1);
	}
   
	cout << stable[idx] << "(" << x <<") = " <<ftable[idx](x)<< endl;
	return 0;
}
