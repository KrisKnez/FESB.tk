// Datoteka: karte1.cpp - dijeljenje karata

#include <iostream>
#include <cstdlib> // deklaracija rand()
using namespace std;

char *boja[] = {"Srce", "Tref", "Karo", "Pik "};

char *lik[]  = {"As", "2", "3", "4", "5", 
                "6",  "7", "8", "9", "10",
                "Jack", "Dama", "Kralj" };

#define BROJ_KARATA 52
				
int main( void) 
{
int i, karte[BROJ_KARATA];  
   // poredaj po redu
   for (i = 0; i < BROJ_KARATA; i++) 
	   karte[i] = i;
   // slucajno izmijesaj
   for (i = 0; i < BROJ_KARATA; i++) 
   {
      int k = rand() % BROJ_KARATA; 
      int tmp = karte[i];  // zamijeni karte po slu�ajnom uzorku
	  karte[i] = karte[k];
      karte[k] = tmp;
   }
   // ispisi oznaku karte
   for (i = 0; i < 52; i++)
   cout << boja[karte[i]/13] << " -  " 
        << lik[karte[i]%13] << endl;
   return 0;
}
