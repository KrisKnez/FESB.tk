// datoteka: tokstr1.cpp
#include <iostream>
#include <string>
#include <sstream>
    
using namespace std;
    
int main()
{
    int n = 2345;
	ostringstream ostr;
    ostr << "Broj iznosi: ";
    ostr <<hex <<n <<" Hex ili ";
    ostr << dec << n << " Dec ";
    
    cout << ostr.str() << endl;
	return 1;
}
    