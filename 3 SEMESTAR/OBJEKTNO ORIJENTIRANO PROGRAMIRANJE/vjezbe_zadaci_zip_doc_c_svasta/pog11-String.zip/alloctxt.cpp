// Datoteka: alloctxt.cpp 

#include	<iostream>
#include	<cstdlib> 
#include	<new> 

using namespace std;

void no_memory()
{
    cout << "Greska pri alociranju memorije";
    exit(1);    
}                  

int main( void )
{
	char **txt;           // pokaziva� na pokaziva�a na char 
	int maxsize = 5;      // po�etna maksimalna veli�ina niza pok.
	int numstrings = 0;   // po�etno je u nizu 0 stringova 
	char str[256]={"\0"}; // radni string

	set_new_handler(no_memory);

// Po�etno alociraj memoriju za maxsize=5 pokaziva�a na char, 
    txt = new char *[maxsize];
		                                              
// U�itaj proizvoljan broj stringova, �iji pokaziva� je u nizu txt[]:
// Prethodno alociraj memoriju sa svaki uneseni string
// Ako broj stringova prema�i maxsize: 
// pove�aj allocirani niz za 5 elemenata 
// Kraj unosa je ako se unese prazna linija. 

	while(true)	
	{    		
         cin.getline(str,255);      // dobavi string u str i odstrani \n
         int len=strlen(str);         // odredi duljinu str
         if(len==0)                   // ako je prazan string
			 break;             // prekini unos teksta 
                                      // ako je unos ispravan
         char *s = new char[len+1];   // formiraj novi stringhkjhkjh
		 
         strcpy(s, str);              // kopiraj radni string u njega
         txt[numstrings] = s;         // i pridjeli ga nizu stringova
         numstrings++;                // inkremantiraj broja� stringova
		 
	   if(numstrings >= maxsize)    
         {  // ako je numstrings ve�i od broja alociranih pok.           
 		char ** p= new char*[maxsize+5];   //allociraj novi niz pok.
		memcpy(p,txt, maxsize*sizeof(char *));  //kopiraj stari u novi
		delete [] txt;                     // dealociraj stari niz pok.
            txt = p;                           // novi pridijeli starome
		maxsize += 5;                       
         }
      }

     cout << "Unos zavrsen -------------------------------" << endl;    

// Ispi�i podatke iz dinami�ki alociranog niza 
// i vrati memoriju na heap koriste�i delete  
// za svaki pojedina�ni string  

     for(int j = 0; j < numstrings; j++ )
     {
         cout << txt[j] <<endl ;
         delete [] txt[j];	
     }

// kona�no oslobodi memoriju koju zauzima niz pokaziva�a txt     

     delete [] txt;	    
     return 0 ;
}
