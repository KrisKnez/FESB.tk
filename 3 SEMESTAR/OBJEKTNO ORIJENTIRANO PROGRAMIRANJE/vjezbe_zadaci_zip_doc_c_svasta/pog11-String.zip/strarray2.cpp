#include <iostream>
#include <cassert>
#include <string>

using namespace std;

const int sizeincr=5;

class CStrArray
{
private :
    string *str_arr ;
    int numstrings;
    int maxsize; 
public: 
    CStrArray () : numstrings(0), maxsize(sizeincr)
    {str_arr  = new string[sizeincr]; }

    ~CStrArray ();
	// sami dopi�ite kopirni konstruktor i operator =
    int Numstrings () const {return numstrings;}
    void AddString(string s) ;
    //...
    string&  operator [] (int index) { return str_arr [index];}
    const string&  operator [] (int index) const { return str_arr [index];}
};

void CStrArray::AddString(string s) 
{	
	if(numstrings >= maxsize)    
    {  // ako je numstrings ve�i od broja alociranih pok.           
 		string * p= new string[maxsize+sizeincr];   //allociraj novi niz pok.
		for(int i=0; i<maxsize; i++)
			p[i] = str_arr[i];
		delete [] str_arr ;                  // dealociraj stari niz pok.
		str_arr = p;                           // novi pridijeli starome
		maxsize += sizeincr;                       
    }
	str_arr[numstrings]=s; 
	numstrings++;
}

CStrArray::~CStrArray ()
{
     delete [] str_arr;	    
}


int main( void )
{
	CStrArray txt;           
	string str; // radni string

	// Kraj unosa je ako se unese prazna linija ili ako EOF. 
	while( getline(cin, str))	
	{    		
      
		if(str.length()==0)                   // ako je prazan string
			 break;             // prekini unos teksta 
                                     // ako je unos ispravan
        txt.AddString(str);         // i pridjeli ga nizu stringova         
    }
	
     cout << "Unos zavrsen -------------------------------" << endl;    

// Ispi�i podatke iz dinami�ki alociranog niza 

     for(int j = 0; j < txt.Numstrings(); j++ )
     {
         cout << txt[j] <<endl ;         
     }

     return 0 ;
}


