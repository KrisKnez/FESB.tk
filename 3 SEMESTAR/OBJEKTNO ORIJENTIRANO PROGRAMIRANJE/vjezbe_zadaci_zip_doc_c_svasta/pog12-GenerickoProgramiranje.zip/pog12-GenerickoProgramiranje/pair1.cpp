// pair1.cpp
#include <iostream.h>

template <class T1, class T2>
class pair {
    T1 value1;
	T2 value2;
  public:
    pair (T1 first, T2 second)
    {value1=first; value2=second;}
    T1 first () {return value1;}
	void first (T1 val) {value1 = val;}
	T2 second () {return value2;}
	void second (T2 val) {value2 = val;}	  
};

int main () {
  pair<int, float> mypair (100, 75.7);
  cout << mypair.first()<<":"<<mypair.second()<<endl;
  return 0;
}

