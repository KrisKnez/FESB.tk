//datoteka arrtemp2.cpp
#include <iostream.h>

template <class T, int N>
class array 
{
    T m_buff[N];
	int m_size;
public:
	array() : m_size(N) {}
	int size() {return m_size;}
    T & operator [] (int i) {return m_buff[i];}
	const T & operator [] (int i) const {return m_buff[i];}
};



int main () {
  array <int,5> myints;
  array <float,5> myfloats;
  myints[0]= 100;
  myfloats[3]= 3.1416;
  cout << "myints ima: "<< myints.size() <<" elemenata"<< '\n';
  cout << myints[0] << '\n';
  cout << myfloats[3] << '\n';
  return 0;
}
