//datoteka: getmax2.cpp
#include <iostream.h>

template <class T>
T GetMax (T a, T b) 
{
  return (a > b)? a : b;
}

int main () 
{
  int i=5, j=6, k;
  float l=10.9, m=5, n;
  k=GetMax(i,j);
  n=GetMax(l,m);
  cout << k << endl;
  cout << n << endl;
  return 0;
}
