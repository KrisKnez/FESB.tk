//Datoteka: params1.cpp
//Program racuna minimum do dvije vrijednosti
#include <iostream>
#include <vector>
using namespace std;

vector<int> S;              // simulator izvrsnog stoga
int Reg;                    // registar u kojeg se upisuje rezultat funkcija

void push(int n)   {S.push_back(n);} 
int & top(int n=0) {return S[S.size()-1+n];}
void pop()         {S.pop_back();}

//void minimum(int x, int y);
void minimum();

int main()
{
   int x = 5, y = 7, rezultat;
   push(x);                // argument stavljamo na stog
   push(y);                // argument stavljamo na stog
   minimum();              // pozivamo funkciju minimum
   rezultat = Reg;         // rezultat je u registru Reg
   pop();                  // ocistimo stog, koji sadrzi argument y
   pop();                  // ocistimo stog, koji sadrzi argument x
   cout << "minimum od "<< x <<" i "<<y
	    <<" je " << rezultat << endl;	
	return 0;
}

void minimum()             // funkcija definirana bez parametara
{ //ocekuje se da pozivna funkcija postavi argumente na vrh stoga 
  int &y = top();          // y argument je na vrhu stoga    
  int &x = top(-1);	       // x argument je na stogu ispod y,    
                           // jer je prvi gurnut na stog
  if(x > y)           
	Reg = y;	           // rezultat vracamo u Reg
  else
	Reg = x;
}
	