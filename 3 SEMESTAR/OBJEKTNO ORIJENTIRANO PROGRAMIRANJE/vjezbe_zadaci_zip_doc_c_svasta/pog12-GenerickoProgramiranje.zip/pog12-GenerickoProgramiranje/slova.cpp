#include <iostream>
#include <fstream>        // ifstream
#include <cstdlib>        // exit()
#include <cctype>         // tolower()
#include <string>
#include <iomanip>        // za formatirani ispis
using namespace std;
#include "tvector.h"

void Print(const tvector<int> & counts, int broj_slova);
void Count(istream & input, tvector<int> & counts, int & broj_slova);

int main()
{
    int broj_slova = 0; 
    string filename;
    cout << "Ime datoteke: ";
    cin >> filename;
	// otvori datoteku
	ifstream input(filename.c_str());
    if (input.fail() )
    {   cout << "Ne moze se otvoriti: " << filename << endl;
        exit(1);
    }
    // inicijaliziraj broja� znakova na 0
	tvector<int> charCounts(256,0);    
    // napravi histogram
    Count(input,charCounts,broj_slova);
	// ispi�i statistiku pojave slova
    Print(charCounts,broj_slova);
    
    return 0;
}

void Count(istream & input, tvector<int> & counts, int & broj_slova)
// PRED: input datoteka otvorana za �itanje
//               counts[k] == 0, 0 <= k < CHAR_MAX
// POST: counts[k] = broj pojave znaka k
//                broj_slova = broj slova     
{
    unsigned char ch;
    while (input.get(ch))               // �itaj znak
    {   if (isalpha(ch))                // ako je slovo (a-z)?
            broj_slova++;                       
        ch = tolower(ch);               // pretvori u mala slova
        counts[ch]++;                   // pove�aj izbroj
	}    
}

void Print(const tvector<int> & counts, int broj_slova)
// PRED: broj_slova u counts['a']..counts['z']
// POST: ispisuje se vrijednost counts od 'a' do 'z' 
//       u dvije kolone i daje postotak pojave slova
{ 
    const int MIDALPH = 13;   // polovina od 26 slova
    cout.setf(ios::fixed);    
    cout.precision(1);        // ispis na 1 decimalno mjesto 
    for(char k = 'a'; k <= 'm'; k++)
    {   cout << k << setw(7) << counts[k] << " ";
        cout << setw(4) << 100 * double(counts[k])/broj_slova 
		     << "% \t\t";
        cout << char(k+MIDALPH) << setw(7) << counts[k+MIDALPH] << " ";
        cout << setw(4) << 100 * double(counts[k+MIDALPH])/broj_slova 
		     << "%" << endl;
    }
}
