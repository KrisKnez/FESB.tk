//datoteka: kvadrat3.cpp
#include <iostream.h>

template <class T>
T Kvadrat(T x) 
{
  return x*x;
}

int main () 
{
  int i=5, k;
  float a=10.9, b;
  k=Kvadrat<int>(a);     // kompajler vr�i pretvorbu float u int
  b=Kvadrat<float>(i);   // kompajler vr�i pretvorbu int u float
  cout << k << endl;
  cout << b << endl;
  return 0;
}
