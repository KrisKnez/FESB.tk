//datoteka: kvadrat1.cpp
#include <iostream.h>

template <class T>
T Kvadrat(T x) 
{
  T result = x*x;	
  return result;
}

int main () 
{
  int i=5, k;
  float a=10.9, b;
  k=Kvadrat<int>(i);
  b=Kvadrat<float>(a);
  cout << k << endl;
  cout << b << endl;
  return 0;
}
