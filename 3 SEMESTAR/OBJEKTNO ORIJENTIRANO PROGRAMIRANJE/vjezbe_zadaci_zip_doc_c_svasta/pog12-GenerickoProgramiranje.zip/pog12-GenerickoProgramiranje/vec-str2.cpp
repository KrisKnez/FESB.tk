#include <iostream>
#include <fstream>        // ifstream
#include <cstdlib>        // exit()
#include <string>
using namespace std;
#include "tvector.h"

enum State{TEXT, FIRST_SLASH, COMMENT, LIT_STRING};

void Decomment(string& input, string& output)
{	    
	State state = TEXT;
    output = "";
	for(int i=0; i<input.length(); i++) 
    {  
		char ch = input[i]; 
		switch(state)
        {
        case TEXT:
            if (ch == '/') // potencijalno je po�etak komentara
               state = FIRST_SLASH;   
			else {
			   if (ch == '\"') //literalni string
				 state = LIT_STRING;
               output+=ch;             
			}
            break;
		case LIT_STRING:
			if (ch == '\"') //literalni string zavr�ava
				state = TEXT;
			output+=ch;             
			break;
        case FIRST_SLASH:
             if (ch == '/')         // dvostruki slash
               state = COMMENT; // zapo�ima komentar
             else                   // samo jedan SLASH
             {  output += '/'; // ispi�i  slash od pro�log stanja
                output += ch; // i trenutni znak
                if (ch == '\"') 
                    state = LIT_STRING;
                else 
                   state = TEXT;      // stanje po�etno
             }
             break;
        case COMMENT: // zavr�no stanje
             break;  
        }
    }
}

int main()
{
    string infilename, outfilename;
    cout << "Ime ulazne .cpp datoteke: ";
    cin >> infilename;
	cout << "Ime izlazne datoteke: ";
	cin >> outfilename;
	if(infilename == outfilename)
	{  cout << "Imena datoteka se moraju razlikovati" << endl;
        exit(1);
    }	
	ifstream input(infilename.c_str()); // otvori ulaznu datoteku
    if (input.fail() )
    {   cout << "Ne moze se otvoriti: " << infilename << endl;
        exit(1);
    }
    
	string str;             // radni string
	// inicijaliziraj vektor za kolekciju stringova
	tvector<string> txt;
	// rezerviraj memoriju za 1000 stringova. Time se smanjuje broj alokacija
	// rezerviranjem se ne mijenja trenutna veli�ina vetora -> size==0
    txt.reserve(1000);    
    
	while (getline(input, str))     // �itaj iz datoteke liniju teksta u str
	{
		string out;
		Decomment(str, out);
		txt.push_back(out);			
	}
	input.close();
	
	ofstream output(outfilename.c_str());
    if (output.fail() )
    {   cout << "Ne moze kreirati: " << outfilename << endl;
        exit(1);
    }
    
	for(int i=0; i<txt.size(); i++)
	{
        output << txt[i] << endl;
	}
	output.close();
    return 0;
}
