#include <iostream>
#include <fstream>        // ifstream
#include <cstdlib>        // exit()
#include <string>
using namespace std;
#include "tvector.h"

void Decomment(const string& in, string& out)
{
  out = ""; 
  int idx = in.find("//");  //da li po�ima komentar
       if(idx==0)
            return;  // komentar po�inje u prvom stupcu
        else if(idx>0)   // dobavi dio stringa do znaka komentara
            out = in.substr(0, idx);	
	  else //linija bez komentara
            out = in;			
}

int main()
{
    string infilename, outfilename;
    cout << "Ime ulazne .cpp datoteke: ";
    cin >> infilename;
    cout << "Ime izlazne datoteke: ";
    cin >> outfilename;
    if(infilename == outfilename)
    {  cout << "Imena datoteka se moraju razlikovati" << endl;
       exit(1);
    }	
    ifstream input(infilename.c_str()); // otvori ulaznu datoteku
    if (input.fail() )
    {   cout << "Ne moze se otvoriti: " << infilename << endl;
        exit(1);
    }    
    
    string str;             // radni string
    tvector<string> txt;    // vektor za kolekciju stringova

    // rezerviraj memoriju za 1000 stringova. 
    // Time se smanjuje broj potrebnih alokacija
    // rezerviranjem se ne mijenja trenutna veli�ina vektora 

    txt.reserve(1000);    

    while (getline(input, str))   // �itaj iz datoteke liniju teksta u str
    {
	  string out;
	  Decomment(str, out);
	  txt.push_back(out);			
    }

    input.close();

    // ispi�i u izlaznu datoteku
    ofstream output(outfilename.c_str());
    if (output.fail() )
    {   cout << "Ne moze kreirati: " << outfilename << endl;
        exit(1);
    }
    
    for(int i=0; i<txt.size(); i++)
    {
        output << txt[i] << endl;
    }
    output.close();
    return 0;
}

