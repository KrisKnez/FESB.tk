#ifndef _STACK_VEC_H_
#define _STACK_VEC_H_

// Class Stack realiziran pomo�u vektora  
/////////////////////////////////////// 

#include <vector>
template <class T>
class Stack
{
   std::vector<T> m_v;
public:
   Stack(){}       
   ~Stack(){}       

   bool empty() const {return m_v.empty();}
   // vraca true ako je stog prazan 

   int size() {return m_v.size();}
   // vraca broj elemenata na stogu 

   T& top() {return (m_v.back()); }
   const T& top() const {return (m_v.back()); }   
   // vraca vrijednost elementa na vrhu stoga u elem
   // ne odstranjuje element sa stoga 

   void pop() {m_v.pop_back(); }
   // PRE: na stogu je bar jedan elemant 
   // odstranjuje element sa vrha stoga    
      
    void push(const T& elem) {m_v.push_back(elem); }
   // postavlja element na vrh stoga 
   // POST: na stogu je jedan element vise 
   
};
#endif
