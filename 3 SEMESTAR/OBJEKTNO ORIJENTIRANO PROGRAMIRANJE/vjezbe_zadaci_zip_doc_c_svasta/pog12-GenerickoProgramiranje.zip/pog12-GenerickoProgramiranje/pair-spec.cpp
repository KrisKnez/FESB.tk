//datoteka: pair-spec.cpp
#include <iostream.h>

template <class T1, class T2>
class pair {
    T1 value1;
	T2 value2;
  public:
    pair (T1 first=0, T2 second=0)
    {value1=first; value2=second;}
	int module () {return 0;}
};

template <>                 // specijalizacija predlo�ka
class pair <int,int> {
    int value1, value2;
  public:
    pair (int first, int second)
      {value1=first; value2=second;}
    int module () {return value1 % value2;}
};

int main () {
  pair <int,int> myints (100,75);
  pair <float,int> myfloats (100.0,75);
  cout << myints.module() << '\n';
  cout << myfloats.module() << '\n';
  return 0;
}
