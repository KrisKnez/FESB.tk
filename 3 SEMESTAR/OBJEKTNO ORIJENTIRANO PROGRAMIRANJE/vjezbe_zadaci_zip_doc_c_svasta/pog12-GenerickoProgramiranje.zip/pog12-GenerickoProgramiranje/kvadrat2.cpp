//datoteka: kvadrat2.cpp
#include <iostream.h>

template <class T>
T Kvadrat(T x) 
{
  return x*x;
}

int main () 
{
  int i=5, k;
  float a=10.9, b;
  k=Kvadrat(i);
  b=Kvadrat(a);
  cout << k << endl;
  cout << b << endl;
  return 0;
}
