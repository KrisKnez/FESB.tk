// datoteka: vec-avg.cpp
#include <iostream>
#include "tvector.h"
using namespace std;
int main()
{
    tvector<double> vec;
    double val;
	// unos proizvoljnog niza brojeva u vektor
	// unos zavr�ava kada se otkuca neko slovo 
    while (cin >> val)
	{
		vec.push_back(val);
	}
    //nakon zavr�enog unosa ra�unamo sumu i srednju vrijednost
    double sum = 0;
    for (int i=0; i<vec.size(); i++)
        sum += vec[i];
    double avg =sum /vec.size();
    cout <<"Suma od "<<vec.size()
         <<" elemenata: "<< sum
        <<". Srednja vrijednost:"<< avg << endl;
	return 0;
}
