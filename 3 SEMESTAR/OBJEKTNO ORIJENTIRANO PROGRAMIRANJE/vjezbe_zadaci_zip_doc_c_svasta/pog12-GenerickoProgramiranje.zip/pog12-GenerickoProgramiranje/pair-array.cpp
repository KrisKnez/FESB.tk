//datoteka pair-array.cpp
#include <iostream>
#include <cmath>
using namespace std;

template <class T>
class array 
{
    T *m_pbuff;
	int  m_size;
public:
	array(int N = 10): m_size(N) {m_pbuff=new T[N];}
	~array() {delete [] m_pbuff;}
	int size() {return m_size;}
    T & operator [] (int i) {return m_pbuff[i];}
	const T & operator [] (int i) const {return m_pbuff[i];}
};

template <class T1, class T2>
class pair {
    T1 value1;
	T2 value2;
  public:
    pair (T1 first=0, T2 second=0)
    {value1=first; value2=second;}
    T1 GetFirst () {return value1;}
	void SetFirst (T1 val) {value1 = val;}
	T2 GetSecond () {return value2;}
	void SetSecond (T2 val) {value2 = val;}	  
};


int main () 
{
  array <pair<int,float> > arr(5);
  for(int i=0; i<arr.size(); i++)
  {
	arr[i].SetFirst(i); 
	arr[i].SetSecond(sqrt(i));  
  }
  
  for(int i=0; i<arr.size(); i++)
  cout << arr[i].GetFirst() <<':' <<arr[i].GetSecond()<< endl;
  cout << endl;
  return 0;
}
