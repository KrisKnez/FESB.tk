//datoteka arrtempl.cpp
#include <iostream.h>

template <class T>
class array 
{
    T *m_pbuff;
	int  m_size;
public:
	array(int N = 10): m_size(N) {m_pbuff=new T[N];}
	~array() {delete [] m_pbuff;}
	int size() {return m_size;}
    void set(int x, T value);
    T get(int x);
    T & operator [] (int i) {return m_pbuff[i];}
	const T & operator [] (int i) const {return m_pbuff[i];}
};

template <class T>
void array<T>::set(int x, T value) 
{
  m_pbuff[x]=value;
}

template <class T>
T array<T>::get(int x) 
{
  return m_pbuff[x];	
}

int main () {
  array <int> myints(5);
  array <float> myfloats(5);
  myints.set (0, 100);
  myfloats.set(3, 3.1416);
  cout << "myints ima: "<< myints.size() <<" elemenata"<< '\n';
  cout << myints[0] << '\n';
  cout << myfloats[3] << '\n';
  return 0;
}
