//Datoteka: params2.cpp
//Program racuna sumu elemenata niza od 5 elemenata
#include <iostream>
#include <vector>
using namespace std;

vector<int> S;                // simulator izvrsnog stoga
int Reg;                           // registar u kojeg se upisuje rezultat funkcija

void push(int n)   {S.push_back(n);} 
int & top(int n=0) {return S[S.size()-1+n];}
void pop()         {S.pop_back();}

void suma_niza();

int main()
{
int A[5] = {1,2,3,4,5};
int len = 5, rezultat;
   push((int)A);       // prvo stavljamo na stog adresu niza
   push(len);          // zatim na stog stavljamo duljinu niza
   suma_niza();          // pozivamo funkciju
   rezultat = Reg;     // rezultat je u registru Reg
   pop();              // konacno ocistimo stog
   pop();
   cout << "suma niza je "<< Reg << endl;	
   return 0;
}

void suma_niza()            // funkcija definirana bez parametara
{ //ocekuje se da pozivna funkcija postaviti argumente na vrh stoga 
  int &n =  top();          // duljina niza je argument na vrhu stoga
  int* &A =(int*&) top(-1); // adresa niza 
  Reg = 0;
petlja:
  if(n == 0) goto end_while;
  n--;
  Reg += A[n];
  goto petlja;
end_while: 
  ;         // rezultat se nalazi  u registaru Reg
}
	