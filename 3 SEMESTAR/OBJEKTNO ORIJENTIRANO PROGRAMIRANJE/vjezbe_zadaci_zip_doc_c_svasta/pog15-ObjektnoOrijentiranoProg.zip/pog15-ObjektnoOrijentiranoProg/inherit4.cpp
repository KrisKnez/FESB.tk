// inherit4.cpp
#include <iostream>
using namespace std;

class Poligon {
  protected:
    int sirina, visina;
  public:
    void init (int a, int b)
      { sirina=a; visina=b;}
	int Sirina() {return sirina;}  
	int Visina() {return visina;}  	
  };

class Pravokutnik: public Poligon {
  public:
    int Povrsina (void)
      { return (sirina * visina); }
  };

class Trokut: public Poligon {
  public:
    int Povrsina (void)
      { return (sirina * visina / 2); }
  };


void IspisDimenzija(Poligon & p)
{
	cout << "sirina = " << p.Sirina() << endl;
	cout << "visina = " << p.Visina() << endl;
}  

int main () 
{
  Pravokutnik pr;
  Trokut tr;
  pr.init (4,5);
  tr.init (4,5);
  cout << "Pravokutnik:" << endl;
  IspisDimenzija(pr);
  cout << "povrsina =" << pr.Povrsina() << endl;
  cout << "Trokut:" << endl;
  IspisDimenzija(pr);
  cout << "povrsina =" << tr.Povrsina() << endl;  
  return 0;
}
  
