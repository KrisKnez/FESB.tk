// inherit6.cpp
#include <iostream>
using namespace std;

class Poligon {
  protected:
    int sirina, visina;
  public:
    void init (int a, int b)    { sirina=a; visina=b; }
	int Sirina() {return sirina;}  
	int Visina() {return visina;}  	
    virtual int Povrsina (void) { return (0); }
  };


class Pravokutnik: public Poligon {
  public:
    int Povrsina (void)
      { return (sirina * visina); }
  };

class Trokut: public Poligon {
  public:
    int Povrsina (void)
      { return (sirina * visina / 2); }
  };
 

int main () 
{
  Pravokutnik pravokutnik;
  Trokut trokut;
  Poligon * pPol1 = &pravokutnik;
  Poligon * pPol2 = &trokut;
  pPol1->init (4,5);
  pPol2->init (4,5);
  cout << pPol1->Povrsina() << endl;
  cout << pPol2->Povrsina() << endl;
  return 0;
}

