// inherit3.cpp
// redoslijed poziv konstuktora
#include <iostream>
using namespace std;

class Otac {
  public:
    Otac ()      { cout << "otac: konstruktor bez argumenta\n"; }
    Otac (int a) { cout << "otac: konstruktor sa argumentom\n"; }
};

class Kcer : public Otac {
  public:
    Kcer (int a) {cout << "kcer: konstruktor sa argumentom\n\n";}
};

class Sin : public Otac {
  public:
    Sin (int a) : Otac (a) { cout << "sin: konstruktor sa argumentom\n\n"; }
};

int main () 
{
  Kcer marija(1);
  Sin anton(1);
  return 0;
}
