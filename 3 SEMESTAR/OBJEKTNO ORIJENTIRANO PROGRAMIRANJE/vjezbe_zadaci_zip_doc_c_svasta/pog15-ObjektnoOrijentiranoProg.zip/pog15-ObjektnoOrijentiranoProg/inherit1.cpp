// inherit1.cpp
#include <iostream>
using namespace std;

class Poligon {
  protected:
    int sirina, visina;
  public:
    void init (int a, int b)
      { sirina=a; visina=b;}
	int Sirina() {return sirina;}  
	int Visina() {return visina;}  	
  };

class Pravokutnik: public Poligon {
  public:
    int Povrsina (void)
      { return (sirina * visina); }
  };

class Trokut: public Poligon {
  public:
    int Povrsina (void)
      { return (sirina * visina / 2); }
  };
  
int main () {
  Pravokutnik pr;
  Trokut tr;
  pr.init (4,5);
  tr.init (4,5);
  cout << pr.Povrsina() << endl;
  cout << tr.Povrsina() << endl;
  return 0;
}
