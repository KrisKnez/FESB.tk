#include <iostream>
using namespace std;
	
class ExprNode  // temeljna klasa za sve tipove cvorova kod izraza
{
   friend ostream& operator<< (ostream&, const ExprNode *);
public:    
	ExprNode() {}     
	virtual ~ExprNode() { }
	virtual void print (ostream&) const = 0;
	virtual double interpret () const = 0;       
};

ostream&   operator<<(ostream& out, const ExprNode *p)
{
    p->print(out); // virtualni poziv, vrijedi za sve  subklase
    return out;
}


class NumNode: public ExprNode 
{
	double n;
public:
    NumNode (double x): n (x) { }
	~NumNode() { };
    void print (ostream& out) const { out << n; }
	double interpret () const {return n;}
};

class UnaryExprNode: public ExprNode 
{
    const int op;      // tip operatora ('+' ili '-')
    ExprNode * oprnd;  // pokazivac na operand 
public:
    UnaryExprNode (const int a,  ExprNode * b): op (a), oprnd (b) { }	
	~UnaryExprNode () {delete oprnd;}	
	double interpret () const 
	{  return (op=='-')? - oprnd->interpret() : oprnd->interpret(); }
	void print (ostream& out) const
	{  out << "(" << (char)op << oprnd << ")";}
};
   
class BinaryExprNode: public ExprNode {
private:
	const int op;      // tip operatora ('+',  '-', '*' ili '/')
	ExprNode * left;   // pokazivac na lijevi operand
	ExprNode * right;  // pokazivac na desni operand
public:
	BinaryExprNode (const int a, ExprNode *b, ExprNode *c):
		op (a), left (b), right (c) { }
	~BinaryExprNode(){delete left; delete right;}	
	double interpret() const;
    void print (ostream& out) const 
	{  out << left << " "<< right << " "<< (char)op << ""; }	
};

double BinaryExprNode::interpret()  const
{
	switch(op)
	{
		case '+': return	left->interpret() + right->interpret();
		case '-': return	left->interpret() - right->interpret();
		case '*': return	left->interpret() * right->interpret();
		case '/': // provjeri dijeljenje s nulom
		{  double val = right->interpret();
			if(val != 0)
				return	left->interpret() / val;	
			else 
				return 0;
		}
		default: return 0;
	}
}


// (-5) * (3+4) formiraj stablo  ->  lijevi_opr  op  desni-opr  
//                   *
//                 /   \
//                -     + 
//               /     / \
//              5     3   4
//

int   main()
{	
	ExprNode* t=new BinaryExprNode('*', 
	            new UnaryExprNode ('-', new NumNode(5)), 
	            new BinaryExprNode ('+',new NumNode(3), new NumNode(4)));
	cout << t << "=" << t->interpret() << "\n";
	delete t;
	return 0;
}
