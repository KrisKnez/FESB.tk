#ifndef LIST1_H
#define LIST1_H

#include "list.h"


template <class Type>
class List1: public List<Type>
{
public:
  void    concat(List<Type> & L);
  void    reverse(); 
};



template <class Type>
void 
List1<Type>::concat(List<Type> &otherList) 
{ 
    ListElem *pElem = otherList.First;

    while (pElem != NULL) 
      {
        push_back(pElem->Elem);
        pElem = pElem->Next; 
      }
} 

template <class Type>
void
List1<Type>::reverse() 
{ 

  if (First == NULL || First->Next == NULL) return;
  
  ListElem *pElem = First; 
  ListElem *prevElem = NULL; 

  First = Last;
  Last  = pElem;

  while (pElem != First) 
    {
      ListElem *tmp = pElem->Next;
      pElem->Next = prevElem;
      prevElem = pElem; 
      pElem = tmp;
    }
  First->Next = prevElem;
} 


#endif


