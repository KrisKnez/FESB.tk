// inherit8.cpp
#include <iostream>
using namespace std;

class Superclass{
    public:
    Superclass (){cout << "Konstruktor temeljne klase\n"; }
	virtual ~Superclass() 
	{cout << "Destruktor temeljne klase\n";}

  };

class Subclass : public Superclass 
{
  public:
	  Subclass () {cout << "Konstruktor izvedene klase\n"; }
	 virtual ~Subclass() 
	{cout << "Destruktor izvedene klase\n";} 	  
};


int main () 
{
  
  Superclass * p = new Subclass;
  delete p;
  
  return 0;
}

