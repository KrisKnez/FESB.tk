// inherit1.cpp
#include <iostream>
using namespace std;

class Poligon {
  protected:
    int sirina, visina;
  public:
    void init (int a, int b)
      { sirina=a; visina=b;}
	int Sirina() {return sirina;}  
	int Visina() {return visina;}  	
  };

class Pravokutnik: public Poligon {
  public:
    int Povrsina (void)
      { return (sirina * visina); }
  };

class Romb: public Pravokutnik {
 public:
    int Povrsina (void)
     { return Pravokutnik::Povrsina(); }
};
  
int main () {
  Romb romb;
  romb.init (4,5);
  cout <<romb.Povrsina() << endl;
  cout << romb.Pravokutnik::Povrsina() << endl;
  return 0;
}
