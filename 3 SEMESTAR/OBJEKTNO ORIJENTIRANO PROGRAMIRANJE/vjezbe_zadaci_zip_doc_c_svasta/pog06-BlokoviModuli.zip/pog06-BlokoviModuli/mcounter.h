/* Datoteka: counter.h
* specifikacija funkcija broja�a po modulu mod
*/

void reset_counter(int mod);
/* Funkcija: inicira broja� na po�etnu vrijednost nula 
 * i modul broja�a na vrijednost mod. Ako je  mod<=1, 
 * modul brojaca se postavlja na vrijednost INT_MAX 
 */

int get_count(void);
/* Funkcija: vra�a trenutnu vrijednost broja�a */
 

int get_modulo(void);
/* Funkcija: vra�a trenutnu vrijednost modula broja�a */


int incr_count(void); 
/* Funkcija: incrementira vrijednost broja�a za 1
 * Ako vrijednost broja�a postane jednaka ili ve�a, 
 * od zadamog modula vrijednost broja�a postaje nula. 
 * Vra�a: trenutnu vrijednost broja�a 
 */

