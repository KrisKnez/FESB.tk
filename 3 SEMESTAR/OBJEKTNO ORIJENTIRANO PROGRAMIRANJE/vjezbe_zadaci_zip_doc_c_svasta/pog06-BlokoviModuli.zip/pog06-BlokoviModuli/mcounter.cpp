/* Datoteka: counter.cpp 
 * Implementacija funkcija broja�a po modulu: mod
 */
#include <limits.h>          /* zbog definicija INT_MAX*/    

/* globalne varijable */

 static int _count = 0;       /* po�etno stanje broja�a */
 static int _mod = INT_MAX;   /*2147483647*/

 void reset_counter(int mod)
 {
    _count= 0;
    if(mod <= 1)   _mod = INT_MAX;
    else           _mod =  mod;
    
 }

 int get_count(void) { return _count;}
 
 int get_modulo(void){ return _mod; }            
  
 int incr_count(void) 
 {
    _count++;
    if(_count >= _mod) _count = 0; 
    return _count;
 }

