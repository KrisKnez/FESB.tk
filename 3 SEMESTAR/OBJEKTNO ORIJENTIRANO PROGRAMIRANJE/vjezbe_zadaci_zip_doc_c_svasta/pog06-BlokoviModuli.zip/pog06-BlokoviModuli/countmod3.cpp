// Datoteka: countmod3.cpp 

#include <iostream> 
using namespace std;

int incr_count(int mod) 
{
   static int count=0;
   count++;
   if(count == mod) 
      count = 0; 
   return count;
}

int main(void) 
{
  int i,mod=3;
  for(i=0; i<=10; i++)
      cout << incr_count(mod) <<  "," ; 
  cout << "...\n";
  return 0;
}


