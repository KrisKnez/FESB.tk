// Datoteka: static.cpp 
// primjer stati�kih �lanova klase
#include <iostream>
using namespace std;

// klasa CL: jedini joj je zadatak da bilje�i pojavnost objekata
class CL { 
  public:
    static int n;       // n je broj aktivnih objekata klase CL
    CL () { n++; };     // konstruktor pove�ava n
    ~CL () { n--; };    // destruktor smanjuje n
};

int CL::n = 0;          // inicijalizira se kao globalna varijabla

int main () 
{
  CL a, b, c;             // n = 3
  CL * d = new CL;        // n = 4
  cout << a.n << endl;
  delete d;               // n = 3
  cout << CL::n << endl;
  return 0;
}



