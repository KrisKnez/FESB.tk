// Datoteka: globdoseg2.cpp 

#include <iostream> 
using namespace std;

namespace grupa
{
    float max = 5.6;
	// .....
};

void add2max(int max ) 
{
    // max je lokalna varijabla, a  ::max je globalna varijabla iz namespace grupa
   grupa::max += max; 
}

int main( void) 
{
    cout << "max - pocetna vrijednost: " << grupa::max << endl;  
	add2max(6) ;
	cout << "max - konacna vrijednost: " << grupa::max << endl;  
    return 0;
}
