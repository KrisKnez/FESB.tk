/* Datoteka2: countmain.cpp */

#include <iostream> 
using namespace std;
extern int count;
void incr_count(int mod);

int main(void) 
{
  int i,mod=3;
  for(i=0; i<=10; i++)
  {   
      incr_count(mod);
      cout << count << endl; 
  } 
  cout << "...\n";
  return 0;
}
