// Datoteka: globdoseg.cpp 

#include <iostream> 
using namespace std;

float max = 5.6;
void add2max(int max ) 
{
    // max je lokalna varijabla, a  ::max je globalna varijabla
   :: max += max; 
}

int main( void) 
{
    cout << "max - pocetna vrijednost: " << max << endl;  
	add2max(6) ;
	cout << "max - konacna vrijednost: " << max << endl;  
    return 0;
}
