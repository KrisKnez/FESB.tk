/* Datoteka: testcount.cpp */

#include <iostream> 
#include "counter.h"  
using namespace std;

int main(void) 
{
  int i;
  reset_counter(0,5);
  cout << "Brojac po modulu " << get_modulo() << endl; 
  for(i=0; i<=10; i++)
  {
     inc_count();
     cout << get_count(); 
  }
  cout << "...\n");
  return 0;
}
