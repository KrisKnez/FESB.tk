/* Datoteka doseg.cpp */

#include <iostream> 

using namespace std;

void f( int a, int x) 
{
   cout << " a =" << a << ", x = " << x <<endl;

   a = 3;
   {
     int x = 4;
     cout << " a =" << a << ", x = " << x <<endl;
   }
   cout << " a =" << a << ", x = " << x <<endl;
   x = 5; /*nema nikakovi efekt*/
}

int main( void) 
{
  int a = 1, b = 2;
  f( a, b);
  cout << " a =" << a << ", b = " << b <<endl;
  return 0;
}
