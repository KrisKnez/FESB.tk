/* Datoteka1: count.cpp */

/* stanje broja�a prije poziva  funkcije counter */

  int count=0;

  incr_count(int mod) 
  {
    count++;
    if(count >= mod) 
       count = 0; 
  }
