/* Datoteka this1.cpp */

#include <iostream> 
using namespace std;

class Tocka
{
	int *m_px; 
	int *m_py;
public:
	  Tocka ()                         // konstruktor
    { m_px = new int; m_py = new int;} // alocira memoriju

    ~Tocka ()                          // destruktor
    {                                  // osloba�a memoriju
		delete m_px;   
		delete m_py; 
	}

    Tocka(const Tocka &);              // kopirni konstruktor

    Tocka & operator =(const Tocka &); // operator =

    int x() const {return *m_px;}      // pristupnici 
    int y() const {return *m_py;}
    void x(int x) {*m_px = x;}         // mutatori 
    void y(int y) {*m_py = y;}
};

Tocka::Tocka(const Tocka & t)
{
	cout << "kopiram:" << endl;
    m_px = new int;
    m_py = new int;
    *m_px = t.x();
    *m_py = t.y();
}

Tocka& Tocka::operator=(const Tocka &desno)
{
	cout << "pridjela:" << endl;
    *m_px = desno.x(); // pridjeli vrijednosti
    *m_py = desno.y();
    return *this;
}

int main( void) 
{
	Tocka a, c;
    a.x(5);
    a.y(7);
    cout << "a = " << a.x() << "," << a.y() << endl;	
	
	Tocka b = a;  // poziv kopirnog konstruktora
    cout << "b = " << b.x() << "," << b.y() << endl;	
	
	c=a=b;  // poziv operator=()
	cout << "c = " << c.x() << "," << c.y() << endl;	
	
  return 0;
}

