// Datoteka: krug.cpp 
// friend class
#include <iostream>
using namespace std;

class CKvadrat;

class CKrug 
{
    double m_radius; 
public:
	friend class CKvadrat;		
	void Radius(double r) {m_radius=r;}
	double Radius() {return m_radius;}
    double Povrsina (void) const {return (3.14*m_radius*m_radius );}
    void Ukvadratu (CKvadrat k);
};

class CKvadrat 
{
    double m_stranica;
public:
    friend class CKrug;      
    void Stranica(double s) {m_stranica=s;}
	double Stranica() {return m_stranica;}
	double Povrsina() const {return m_stranica*m_stranica;}
    void OkoKruga(CKrug k);
};

void CKrug::Ukvadratu (CKvadrat kv) 
{
  m_radius = kv.m_stranica /2;
}

void CKvadrat::OkoKruga(CKrug k)
{
   m_stranica = k.m_radius*2;	
}

int main () 
{
  CKvadrat kvadrat;
  CKrug krug;
  kvadrat.Stranica(5);
  krug.Ukvadratu(kvadrat);
  cout <<"povrsina kruga:" << krug.Povrsina() << endl;
  kvadrat.OkoKruga(krug);
  cout <<"povrsina kvadrata:" << kvadrat.Povrsina() << endl;
  return 0;
}
