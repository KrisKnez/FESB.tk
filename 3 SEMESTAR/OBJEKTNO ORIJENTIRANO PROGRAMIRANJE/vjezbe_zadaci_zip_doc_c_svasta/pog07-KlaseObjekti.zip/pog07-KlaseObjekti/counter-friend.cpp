// Datoteka: counter-friend.cpp 
// Klasa i objekti broja�a po modulu
// primjer  prijateljskih funkcija

#include <limits.h>          // zbog definicija INT_MAX

class Counter {         // specifikacija �lanova klase

	int m_count;        // stanje broja�a 
	int m_mod;          // modul izbroja  

public:
	Counter(): m_count(0), m_mod(INT_MAX) {} // "default" konstruktor
    
	Counter(int mod): m_count(0), m_mod(mod) {}
	
	Counter(const Counter &c )  // kopirni konstruktor
	{
		m_count = c.m_count;
		m_mod = c.m_mod; 
	}
	// specifikacija �lanskih funkcija broja�a

	void reset() {m_count= 0;}
	// Funkcija: inicira broja� na po�etnu vrijednost nula  
	int get_count(void) const { return m_count;}
	// Funkcija: vra�a trenutnu vrijednost broja�a 
	int get_modulo(void) const {return m_mod;};  
	// Funkcija: vra�a trenutnu vrijednost modula broja�a 
	void set_modulo(int mod); 
	// Funkcija: postavlja trenutnu vrijednost modula broja�a 	
	int incr_count(void); 
	// Funkcija: incrementira vrijednost broja�a za 1
	// Ako vrijednost broja�a postane jednaka ili ve�a, 
	// od zadamog modula vrijednost broja�a postaje nula. 
	// Vra�a: trenutnu vrijednost broja�a 

	friend int CompareCounters (const Counter *pc1, const Counter *pc2);
	friend int CompareCounters (Counter &c1, Counter &c2);

};

void  Counter::set_modulo(int mod)
{  
	if(mod <= 1)   m_mod = INT_MAX;
    else           m_mod =  mod;
}           
  
int Counter::incr_count(void) 
{
    m_count++;
    if(m_count >= m_mod) m_count = 0; 
    return m_count;
}

int CompareCounters (const Counter *pc1, const Counter *pc2)
{
	return pc1->m_count - pc2->m_count;
}

int CompareCounters (Counter &c1, Counter &c2)
{
	return c1.m_count - c2.m_count;
}

#include <iostream.h>
//using namespace std;

int main()
{
		Counter c1(3), c2;
		c2=c1;
	    for(int i=0; i < 10; i++)
		{
			c1.incr_count();	
			c2.incr_count();	
		    cout << "c1=" << c1.get_count() << '\t'
			     << "c2=" << c2.get_count() << '\n';
		}
		cout << CompareCounters (&c1, &c2) << '\n';
		cout << CompareCounters (c1, c2) << '\n';
		
		return 0;
}
