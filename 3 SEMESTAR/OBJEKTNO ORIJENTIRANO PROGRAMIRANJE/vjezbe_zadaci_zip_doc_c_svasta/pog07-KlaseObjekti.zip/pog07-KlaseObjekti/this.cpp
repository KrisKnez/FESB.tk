/* Datoteka this1.cpp */

#include <iostream> 
using namespace std;

class Tocka
{
	int m_x; 
	int m_y;
public:
	Tocka(): m_x(0),m_y(0) {}
	Tocka(int x, int y): m_x(x), m_y(y) {}		
	int X() {return this->m_x;}
	int Y() {return this->m_y;}
	Tocka *adresa() {return this;}
};
	


int main( void) 
{
	Tocka t(5,10);
    
	cout << "Tocka:" << t.X() << ',' << t.Y() << endl; 
	cout << "adresa objekta: " << &t << endl;
	cout << "this pokazivac: " << t.adresa() << endl;
	
  return 0;
}

