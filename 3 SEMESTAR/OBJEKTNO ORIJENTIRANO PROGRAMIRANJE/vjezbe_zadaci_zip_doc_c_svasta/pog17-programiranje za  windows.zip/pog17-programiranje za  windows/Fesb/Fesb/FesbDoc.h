// FesbDoc.h : interface of the CFesbDoc class
//


#pragma once

class CFesbDoc : public CDocument
{
protected: // create from serialization only
	CFesbDoc();
	DECLARE_DYNCREATE(CFesbDoc)

// Attributes
public:

// Operations
public:

// Overrides
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CFesbDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()

public:
	CString m_text;
	CPoint m_pos;
};


