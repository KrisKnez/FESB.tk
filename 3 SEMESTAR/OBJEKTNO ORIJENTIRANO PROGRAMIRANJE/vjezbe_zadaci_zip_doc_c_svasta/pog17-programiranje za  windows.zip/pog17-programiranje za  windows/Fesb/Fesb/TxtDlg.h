#pragma once
#include "afxwin.h"


// CTxtDlg dialog

class CTxtDlg : public CDialog
{
	DECLARE_DYNAMIC(CTxtDlg)

public:
	CTxtDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CTxtDlg();

// Dialog Data
	enum { IDD = IDD_DIALOG_TEXT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CEdit m_txtEdit;
	CString m_text;
protected:
	virtual void OnOK();
};
