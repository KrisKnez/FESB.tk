// FesbDoc.cpp : implementation of the CFesbDoc class
//

#include "stdafx.h"
#include "Fesb.h"

#include "FesbDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CFesbDoc

IMPLEMENT_DYNCREATE(CFesbDoc, CDocument)

BEGIN_MESSAGE_MAP(CFesbDoc, CDocument)
END_MESSAGE_MAP()


// CFesbDoc construction/destruction

CFesbDoc::CFesbDoc()
{
	// TODO: add one-time construction code here
	m_text = "Hello World";
	m_pos.x=0;
	m_pos.y=0;

}

CFesbDoc::~CFesbDoc()
{
}

BOOL CFesbDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}


// CFesbDoc serialization

void CFesbDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// spremanje u datoteku
		ar << 'F'<< 'E'<< 'S'<< 'B';
		ar << m_pos;
		ar << m_text;		
		
	}
	else
	{
		char c1,c2,c3,c4;
		ar >> c1 >> c2 >> c3 >> c4;
		if(c1 != 'F' || c2 != 'E' || c3 != 'S' || c4 != 'B')
		{
			AfxMessageBox("Ovo nije fesb datoteka");
			return;
		}
		// ok, citaj poziciju i string
		ar >> m_pos;
		ar >> m_text;
		
	}
}


// CFesbDoc diagnostics

#ifdef _DEBUG
void CFesbDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CFesbDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CFesbDoc commands
