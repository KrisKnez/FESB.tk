// FesbView.cpp : implementation of the CFesbView class
//

#include "stdafx.h"
#include "Fesb.h"
#include "FesbDoc.h"
#include "FesbView.h"
#include "TxtDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CFesbView

IMPLEMENT_DYNCREATE(CFesbView, CView)

BEGIN_MESSAGE_MAP(CFesbView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
	ON_WM_LBUTTONDOWN()
	ON_WM_KEYDOWN()
	ON_COMMAND(ID_EDIT_NOVITEXT, OnEditNovitext)
END_MESSAGE_MAP()

// CFesbView construction/destruction

CFesbView::CFesbView()
{
	// TODO: add construction code here
	m_txtColor = RGB(0,0,0);   // crna 
	m_penColor = RGB(128,0,0); // crvena
	

}

CFesbView::~CFesbView()
{
}

BOOL CFesbView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CFesbView drawing

void CFesbView::OnDraw(CDC* pDC)
{
	CFesbDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	//ispisi text
	pDC->SetTextColor(m_txtColor);
	pDC->TextOut(pDoc->m_pos.x,pDoc->m_pos.y,pDoc->m_text);
	
	//nacrtaj liniju dijagonalno preko cijelog prikaza	
	CRect r; 
	GetClientRect(&r);
		
	CPen pen;
	pen.CreatePen(PS_SOLID,1,m_penColor);
	CPen *oldpen= pDC->SelectObject(&pen);

	pDC->MoveTo(r.left,r.bottom);
	pDC->LineTo(r.right,r.top);
	
	pDC->SelectObject(oldpen); // vrati staro stanje

}


// CFesbView printing

BOOL CFesbView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CFesbView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CFesbView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CFesbView diagnostics

#ifdef _DEBUG
void CFesbView::AssertValid() const
{
	CView::AssertValid();
}

void CFesbView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CFesbDoc* CFesbView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CFesbDoc)));
	return (CFesbDoc*)m_pDocument;
}
#endif //_DEBUG


// CFesbView message handlers

void CFesbView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	CFesbDoc* pDoc = GetDocument();
	pDoc->m_pos=point;
	Invalidate();  // poruka da se treba obnoviti ispis View-a
	CView::OnLButtonDown(nFlags, point);
}

void CFesbView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: Add your message handler code here and/or call default
	CFesbDoc* pDoc = GetDocument();
	CPoint curr_pos = pDoc->m_pos;
	CRect r; 
	GetClientRect(&r);
	switch(nChar)
	{
		case VK_UP:    curr_pos.y--; break;			
		case VK_DOWN:  curr_pos.y++;break;
		case VK_LEFT:  curr_pos.x--; break;
		case VK_RIGHT: curr_pos.x++;break;
	}
	if(curr_pos.y > r.top && curr_pos.y < r.bottom)
		pDoc->m_pos.y = curr_pos.y;
	if(curr_pos.x > r.left && curr_pos.x < r.right)
		pDoc->m_pos.x = curr_pos.x;
	Invalidate();

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CFesbView::OnEditNovitext()
{// TODO: Add your command handler code here
	CFesbDoc* pDoc = GetDocument();
	CTxtDlg dlg;                 // deklariranje dijaloga

	int response = dlg.DoModal(); //poziv dijaloga

	if(IDOK == response)  // samo ako je pritisnut botun OK
	{
		CString s;
		 // dobavi txt iz dijaloga
		if(dlg.m_text.IsEmpty()) // ako je prazan
			AfxMessageBox("Unijeli ste prazan tekst");
		else
			pDoc->m_text = dlg.m_text;  // stavi tekst u dokument

		Invalidate();

	}
}
