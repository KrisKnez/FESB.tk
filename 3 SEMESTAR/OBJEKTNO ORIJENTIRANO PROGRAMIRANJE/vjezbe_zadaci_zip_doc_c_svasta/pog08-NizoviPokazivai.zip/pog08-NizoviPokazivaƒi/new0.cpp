#include <iostream>
using namespace std;

int main()
{
	char* p = new char[1000000000];
	
	cout << "kraj, p = " << long(p) << endl;
	return 0;
}

// neki kompajleri daju rezultat:
//  kraj, p=0
// a neki prekidaju program kada se ne mo�e izvr�iti alokacija memorije