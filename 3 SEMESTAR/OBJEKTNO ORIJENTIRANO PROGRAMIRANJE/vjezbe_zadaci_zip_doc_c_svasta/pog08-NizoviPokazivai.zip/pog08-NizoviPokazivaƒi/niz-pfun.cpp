/* program: niz-pfun.c 
 * koristenje niza pokazivaca na funkciju
 */
 #include <iostream>
 #include <cmath>
 using namespace std;
    
 double Kvadrat (double x) {return x*x;}
                 
 int main()
 {
	double val=1;
	int izbor;
       
	double (*pF[3])(double)={Kvadrat, sin, cos};

	cout <<  "Upisi broj:";
    cin >> val;	    
	
    cout <<  "\n(1)Kvadrat  \n(2)Sinus  \n(3)Kosinus \n";
	cout <<  "\nOdaberi 1, 2 li 3\n";    
    cin >> izbor;
	
	if (izbor >=1 && izbor <=3)
		cout << "\nRezultat je " << (*pF[izbor-1])(val) << endl;       
	return 0;
 }    
