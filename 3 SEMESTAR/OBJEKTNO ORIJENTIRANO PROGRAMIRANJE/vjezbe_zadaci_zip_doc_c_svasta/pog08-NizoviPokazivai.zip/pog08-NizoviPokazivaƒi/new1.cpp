#include <iostream>
#include <new>

using namespace std;

void no_memory()
{
	cerr << "operator new: nema slobodne memorije\n";
	exit(1);
}

int main()
{
	set_new_handler(no_memory);
		
	char* p = new char[1000000000];
	
	cout << "Kraj, p = " << long(p) << endl;
	return 0;
}
