 /* program: niz-pfun1.c 
 * koristenje niza pokazivaca na funkciju
 */
 #include <iostream>
 #include <cmath>
 using namespace std;
    
 typedef double t_Fdd(double);  /* tip funkcije koja ... */
 typedef t_Fdd *t_pFdd;    /* tip pokaziva�a na funkciju koja ...*/
    
 double Kvadrat (double x) {return x*x;}
    
  void PrintVal(t_pFdd pFunc, double  x)
 {
       cout << "\nZa x=" << x 
	        << " dobije se " << pFunc(x) << endl;       
 } 
         

 int main()
 {
	double val=1;
	int izbor;
	t_pFdd  pF[3] = {Kvadrat, sin, cos}; 	    

	cout <<  "Upisi broj:";
    cin >> val;	    
	
    cout <<  "\n(1)Kvadrat  \n(2)Sinus  \n(3)Kosinus \n";
	cout <<  "\nOdaberi 1, 2 li 3\n";    
    cin >> izbor;
	
	if (izbor >=1 && izbor <=3)
	     PrintVal(pF[izbor-1], val);	
	return 0;
 }    
