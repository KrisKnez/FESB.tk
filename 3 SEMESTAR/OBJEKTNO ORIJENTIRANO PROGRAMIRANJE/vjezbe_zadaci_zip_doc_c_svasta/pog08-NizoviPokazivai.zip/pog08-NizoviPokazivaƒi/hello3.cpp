//Datoteka; hello3.cpp
//Prvi C++ program - drugi put. 
#include <iostream>
using namespace std;

unsigned strlen(char *s)
{
   unsigned len = 0;
   while (*s++ != '\0')  // petlja se prekida kada je *s==0, ina�e 
     len++;              // inkrementira se broja� znakova i pokaziva�
   return len;           // len sadr�i duljinu stringa (bez nultog znaka)
}

int main() 
{
    char hello[] = "Hello, world!";
    cout << hello << endl;
    cout << "Duljina stringa je " << strlen(hello) << endl;
    cout << "Zauzece memorije je" << sizeof(hello)*sizeof(char) 
         << " bajta" << endl;
    return 0;
}
