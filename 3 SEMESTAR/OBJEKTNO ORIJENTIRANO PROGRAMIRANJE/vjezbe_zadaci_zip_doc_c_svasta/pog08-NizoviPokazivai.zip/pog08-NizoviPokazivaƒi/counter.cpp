// Datoteka: counter.cpp 
// implementacija klase Counter

#include "counter.h"

void  Counter::set_modulo(int mod)
{  
	if(mod <= 1)   m_mod = INT_MAX;
    else           m_mod =  mod;
}           
  
int Counter::incr_count(void) 
{
    m_count++;
    if(m_count >= m_mod) m_count = 0; 
    return m_count;
}


int CompareCounters (Counter &c1, Counter &c2)
{
	return c1.m_count - c2.m_count;
}

