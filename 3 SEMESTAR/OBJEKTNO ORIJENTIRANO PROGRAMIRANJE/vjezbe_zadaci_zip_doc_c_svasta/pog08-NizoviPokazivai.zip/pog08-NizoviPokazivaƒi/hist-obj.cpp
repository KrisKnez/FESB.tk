// datoteka: hist-obj.cpp 
// realizacija histograma pomo�u objekata klase counter

#include <iostream>
#include "counter.h"

using namespace std;

void record( int ocjena, Counter counts[]) 
{
     counts[ocjena-1].incr_count();
}

void printstars(int n) 
{
	while (n-- > 0)
        cout << '*';
	cout << '\n'; 
}

void printhistogram(Counter counts[]) 
{
	for (int i = 10; i > 0; i--) 
	{
	    cout <<  i << '\t';
	    printstars(counts[i-1].get_count()); 
	}
}


int main(void) 
{
int ocjena;
Counter counts[10];

    while (cin >> ocjena)  
    {
        if(ocjena <1 || ocjena >10)
            break;
        record(ocjena, counts);
    }

    cout << "Histogram" << '\n';
    printhistogram(counts); 
    return 0;
}

