//Datoteka; hello2.cpp
//Prvi C++ program - drugi put. 
#include <iostream>
#include <cstring>
using namespace std;

int main() 
{
    char hello[14] = { 'H', 'e', 'l', 'l', 'o', ',', ' ',
                       'W', 'o', 'r', 'l', 'd', '!', '\0' };
    cout << hello << endl;
    cout << "Duljina stringa je " << strlen(hello) << endl;
    return 0;
}
