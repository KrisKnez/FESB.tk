/* datoteka: hist.cpp */

#include <iostream>
using namespace std;

int main(void) 
{
int i, counts[10], ocjena;

/*counts[] sadrzava podatak o tome
koliko je ocjena iz pojedine grupe (1,2,..9,10). */

  for (i = 0; i < 10; i++)
     counts[i] = 0;
  
	while (cin >> ocjena)  
	{
		if(ocjena <1 || ocjena >10) break;
	    counts[ocjena-1]++;
	}
	
	cout << "Histogram:" << '\n';
	for (i = 10; i > 0; i--) 
	{
        cout <<  i << '\t';
	    for (int n = counts[i-1]; n> 0; n--)
            cout << '*';
		cout << '\n';
  }
  return 0;
}
