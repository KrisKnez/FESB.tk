/* program: pfun.cpp 
 * kori�tenje pokaziva�a na funkciju
 */

 #include <iostream>
 #include <cmath>
 using namespace std;
 
 double Kvadrat (double x) 
 {
   return x*x;
 }
     
 void PrintVal( double (*pFunc)(double), double  x)
 {
       cout << "\nZa x=" << x 
	        << " dobije se " << pFunc(x) << endl;       
 } 
         
 int main()
 {
    double val=1;
    char choice;
       
    double (*pFunc)(double);

    cout << "Upisi broj:";
    cin >> val;	    
    
    cout << "\n(1)Kvadrat  \n(2)Sinus  \n(3)Kosinus \n";
    cout << "\nOdaberi 1, 2 li 3\n";    

    cin >> choice;
    switch (choice)
    {
        case '1': pFunc = Kvadrat; break;
        case '2': pFunc = sin; break;
	    case '3': pFunc = cos; break;		         
        default: return 0;
    }
    PrintVal (pFunc, val);
    return 0;
}

