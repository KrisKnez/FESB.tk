/* datoteka: histf.cpp */

#include <iostream>
using namespace std;

void record( int ocjena, int counts[]) 
{
     counts[ocjena-1]++;
}

void printstars(int n) 
{
	while (n-- > 0)
        cout << '*';
	cout << '\n';
}

void printhistogram(int counts[]) 
{
	for (int i = 10; i > 0; i--) 
	{
	    cout <<  i << '\t';
	    printstars(counts[i-1]); 
	}
}

int main(void) 
{

int ocjena, counts[10] = {0};

	while (cin >> ocjena)  
	{
		if(ocjena <1 || ocjena >10) break;
		record(ocjena, counts);
	}
	cout << "Histogram" << '\n';
	printhistogram(counts);
	return 0;
}
