//datoteka: dynamicArray.cpp

#include <iostream.h>
using namespace std;

int main()
{
  int n;                      // Broj elemenata niza
  float *A;                // Pokaziva� niza
  
  cout << "Unesite broj elemenata niza? ";
  cin >> n;
  
// Alocira se  niz A od n float elemenata.
A = new float [n];
 
//  A[i] = i^2.
for (int i = 0; i < n; i++) 
    A[i] = i * i;
    
// Ispis vrijednosti elemenata niza.
for (int i = 0; i < n; i++) 
    cout << "A[" << i << "] == " << A[i] << endl;
    
// Dealokacija niza.
delete [] A;
return 1;
} 

