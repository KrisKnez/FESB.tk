// iterfind.cpp
// find() returns a list iterator
#include <iostream>
#include <algorithm>
#include <list>
using namespace std;

int main()
   {
   list<int> iList(5);           // empty list holds 10 ints
   list<int>::iterator it;       // iterator
   int data = 0;
                                 // fill list with data
   for(it = iList.begin(); it != iList.end(); it++)
      *it = data += 2;
                                 // look for number 8
   it = find(iList.begin(), iList.end(), 8);
   if( it != iList.end() )
      cout << "\nFound 8";
   else
      cout << "\nDid not find 8.";
	return 0;
}
