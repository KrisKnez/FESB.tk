// map.cpp
// a map used as an English-language dictionary

#include <iostream>
#include <iomanip>
#include <map>
#include <string>

using namespace std;

int main()
{
   enum {SIZE = 80};
   char def[SIZE];             // definition (C string)
   string word = "";           // key (string object)
                               // shorten type name
   typedef map< string, string, less<string> > map_type;

   map_type diction;           // define a dictionary
                               // insert sample entries
   diction.insert( map_type::value_type("cat",
                   "A small furry animal that chases mice.") );
   diction.insert( map_type::value_type("dog",
                   "A large hairy animal that chases sticks.") );

   while(true)                 // get entries from user
   {
      cout << "\nEnter word (or \"done\"): ";
      cin >> word;	   cin.ignore(10, '\n');
      if(word == "done")
         break;
      cout << "Enter definition: ";
      cin.getline(def, SIZE);      // (reads embedded blanks)
      diction.insert( map_type::value_type(word, def) );
   }
   map_type::iterator iter;    // make an iterator
   iter = diction.begin();     // set to beginning of dictionary
   cout << endl << endl;
   while( iter != diction.end() )
   {                       // display "word -- definition"
      cout << (*iter).first << " -- " << (*iter).second << endl;
      ++iter;
   }
   return 0;
}
