// dinsiter.cpp
// demonstrates insert iterators with queues

#include <iostream>
#include <deque>
#include <algorithm>
using namespace std;

int main()
{
   int arr1[] = { 1, 3, 5, 7, 9 };    // initialize d1

   deque<int> d1(arr1, arr1+5);
   int arr2[] = {2, 4, 6};           // initialize d2
   deque<int> d2(arr2, arr2+3);

   copy( d1.begin(), d1.end(), back_inserter(d2) );

   cout << "\nd2: ";                 // display d2
   for(int j=0; j<d2.size(); j++)
      cout << d2[j] << ' ';
   return 0;
}
