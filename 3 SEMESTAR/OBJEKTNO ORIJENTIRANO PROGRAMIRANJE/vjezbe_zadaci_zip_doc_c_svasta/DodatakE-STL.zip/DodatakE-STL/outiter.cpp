// outiter.cpp
// demonstrates ostream_iterator

#include <iostream>
#include <algorithm>
#include <iterator>
#include <list>
using namespace std;

int main()
{
   int arr[] = { 10, 20, 30, 40, 50 };
   list<int> iList(arr, arr+5);                  // initialized list
   ostream_iterator<int> ositer(cout, "--");     // ostream iterator
   cout << "\nContents of list: ";
   copy(iList.begin(), iList.end(), ositer);     // display the list
   return 0;
}
