// sortpers.cpp
// sorts person objects by name and phone number
#include <iostream>
#include <string> 
#include <vector>
#include <set>
#include <algorithm>
#include <functional>
using namespace std;

class person
   {
   private:
      string lastName;
      string firstName;
      long phoneNumber;
   public:
      person() :              // default constructor
           lastName("blank"), firstName("blank"), phoneNumber(0L)
         {  }
                              // 3-arg constructor
     person(string lana, string fina, long pho) :
              lastName(lana), firstName(fina), phoneNumber(pho)
         {  }

      friend bool operator<(const person&, const person&);
      friend bool operator==(const person&, const person&);


     void display() const     // display person's data
         {
         cout << endl << lastName << ",\t" << firstName
              << "\t\tPhone: " << phoneNumber;
         }
      long get_phone() const   // return phone number
         { return phoneNumber; }
   };
                               // overloaded < for person class
bool operator<(const person& p1, const person& p2)
   {
   if(p1.lastName == p2.lastName)

     return (p1.firstName < p2.firstName) ? true : false;
   return (p1.lastName < p2.lastName) ? true : false;
   }
                               // overloaded == for person class
bool operator==(const person& p1, const person& p2)
   {
   return (p1.lastName == p2.lastName &&
           p1.firstName == p2.firstName ) ? true : false;
   }

// function object to compare person's phone number

class phoneLess : binary_function<person, person, bool>
   {
   public:
      bool operator() (const person& p1, const person& p2) const
         {
         return p1.get_phone() < p2.get_phone();
         }
   };

////////////////////////////////////////////////////////////////
int main()
   {                          // a multiset of persons
   multiset< person, less<person> > persSet;
                              // put persons in set
   persSet.insert( person("Deauville", "William", 8435150) );
   persSet.insert( person("McDonald", "Stacey", 3327563) );
   persSet.insert( person("Bartoski", "Peter", 6946473) );
   persSet.insert( person("KuangThu", "Bruce", 4157300) );
   persSet.insert( person("Wellington", "John", 9207404) );
   persSet.insert( person("McDonald", "Amanda", 8435150) );
   persSet.insert( person("Fredericks", "Roger", 7049982) );
   persSet.insert( person("McDonald", "Stacey", 7764987) );

                              // iterator to multiset
   multiset< person, less<person> >::iterator iterset;
   cout << "\nPersons sorted by name:";
   iterset = persSet.begin(); // display contents of set
   while( iterset != persSet.end() )
      (*iterset++).display();
                              // an empty vector of persons
   vector<person> persVect( persSet.size() );
                              // copy from set to vector
   copy( persSet.begin(), persSet.end(), persVect.begin() );
                              // sort vector by phone number
   sort( persVect.begin(), persVect.end(), phoneLess() );

                              // iterator to a vector of persons
   vector<person>::iterator itervect;
   cout << "\n\nPersons sorted by phone number:";
   itervect = persVect.begin();  // display contents of vector
   while( itervect != persVect.end() )
      (*itervect++).display();
   return 0;
}


