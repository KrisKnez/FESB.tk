// mapbrack.cpp
// demonstrates operator [] used for maps

#include <iostream>
#include <map>
using namespace std;

int main()
   {
   typedef map< int, char*, less<int> > map_type;
   map_type flaglist;                        // map holding flag messages
   long code_number;
   flaglist.insert( map_type::value_type(14072,
       "I are listing sharply and will soon founder.") );
   flaglist.insert( map_type::value_type(12023,
       "The enemy is within sight and approaching rapidly.") );
   flaglist.insert( map_type::value_type(16067,
       "I have dispatches. Prepare to receive our longboat.") );
   flaglist.insert( map_type::value_type(13045,
       "Fall in line astern of me.") );
   flaglist.insert( map_type::value_type(19092,
       "Stand off. This coast is rocky and uncharted.") );
   while(true)                               // get code number from user
    {
      cout << "\n\nEnter flag code number (0 to terminate): ";
      cin >> code_number;
      if( !code_number )
         break;
      cout << "Message is:" << endl;
      cout << flaglist[code_number];        // access value with key
    }
	return 0;
 }

