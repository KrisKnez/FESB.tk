// listout.cpp
// iterator and for loop for output
#include <iostream>
#include <list>
using namespace std;

int main()
{
   int arr[] = { 2, 4, 6, 8 };          // array of ints
   list<int> iList(arr, arr+4);         // list initialized to array
   list<int>::iterator it;              // iterator to list-of-ints
   for(it = iList.begin(); it != iList.end(); it++)
      cout << *it << ' ';
	return 0;
}
