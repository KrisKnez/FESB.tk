// foutiter.cpp
// demonstrates ostream_iterator with files

#include <iostream>
#include <fstream>
#include <iterator>
#include <algorithm>
#include <list>
using namespace std;

int main()
{
   int arr[] = { 11, 21, 31, 41, 51 };
   list<int> iList(arr, arr+5);        // initialized 2list
   ofstream outfile("ITER.DAT");       // create file object

   ostream_iterator<int> ositer(outfile, " ");    // iterator
                                       // write list to file
   copy(iList.begin(), iList.end(), ositer);
   return 0;
}
