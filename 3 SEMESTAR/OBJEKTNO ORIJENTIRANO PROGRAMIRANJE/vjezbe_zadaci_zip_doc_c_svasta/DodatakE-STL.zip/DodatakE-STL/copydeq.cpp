// copydeq.cpp
// demonstrates normal copy with queues

#include <iostream>
#include <deque>
#include <algorithm>
using namespace std;

int main()
{
   int arr1[] = { 1, 3, 5, 7, 9 };    // initialize d1
   deque<int> d1(arr1, arr1+5);

   int arr2[] = { 2, 4, 6, 8, 10 };   // initialize d2
   deque<int> d2(arr2, arr2+5);
                                      // copy d1 to d2
   copy( d1.begin(), d1.end(), d2.begin() );

   for(int j=0; j<d2.size(); j++)    // display d2
      cout << d2[j] << ' ';
   return 0;
}
