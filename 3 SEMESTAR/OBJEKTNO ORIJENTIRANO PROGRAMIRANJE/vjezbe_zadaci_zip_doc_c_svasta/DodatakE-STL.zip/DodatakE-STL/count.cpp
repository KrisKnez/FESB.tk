// count.cpp
// counts the number of elements with a specified value
#include <iostream>
#include <algorithm>
using namespace std;

int arr[] = { 33, 22, 33, 44, 33, 55, 66, 77 };

int main()
{
   int n = 0;                      // must initialize
   n=count(arr, arr+8, 33);       // count number of 33's
                                   //    add result to n
   cout << "There are " << n << " 33's in arr." << endl;
   return 0;
}
