// iterev.cpp
// demonstrates reverse iterator
#include <iostream>
#include <list>
using namespace std;

int main()
{
   int arr[] = { 2, 4, 6, 8, 10 };  // array of ints
   list<int> iList(arr, arr+5);     // list initialized to array

   list<int>::reverse_iterator revit;   // reverse iterator

   revit = iList.rbegin();              // iterate backwards
   while( revit != iList.rend() )       // through list,
      cout << *revit++ << ' ';          // displaying output
	return 0;
}
