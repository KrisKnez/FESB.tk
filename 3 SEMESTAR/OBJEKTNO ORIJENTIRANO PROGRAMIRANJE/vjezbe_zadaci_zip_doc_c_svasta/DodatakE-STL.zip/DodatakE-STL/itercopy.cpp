// itercopy.cpp
// uses iterators for copy() algorithm

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main()
{
   int beginRange, endRange;
   int arr[] = { 11, 13, 15, 17, 19, 21, 23, 25, 27, 29 };
   vector<int> v1(arr, arr+10);     // initialized vector
   vector<int> v2(10);              // uninitialized vector

   cout << "Enter range to be copied (example: 2 5): ";
   cin >> beginRange >> endRange;

   vector<int>::iterator it1 = v1.begin() + beginRange;
   vector<int>::iterator it2 = v1.begin() + endRange;
   vector<int>::iterator it3;
                                   // copy range from v1 to v2
   it3 = copy( it1, it2, v2.begin() );
                                   // (it3 -> last item copied)
  it1 = v2.begin();
                                   // iterate through range
   while(it1 != it3)               // in v2, displaying values
      cout << *it1++ << ' ';
	return 0;
}
