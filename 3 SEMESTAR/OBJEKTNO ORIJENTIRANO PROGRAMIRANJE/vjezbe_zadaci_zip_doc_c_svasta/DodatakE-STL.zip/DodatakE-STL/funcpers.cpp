// funcpers.cpp
// demonstrates function objects with person class
#include <iostream>
#include <string> 
#include <list>
#include <algorithm>
#include <functional>
using namespace std;

class person
{   
    string lastName;
    string firstName;
    long phoneNumber;
public:
	person() :                    // default constructor
           lastName("blank"), firstName("blank"), phoneNumber(0L)
         {  }
                              // 3-arg constructor
      person(string lana, string fina, long pho) :
              lastName(lana), firstName(fina), phoneNumber(pho)
         {  }
      friend bool operator<(const person&, const person&);
      friend bool operator==(const person&, const person&);

      void display() const
         {
         cout << endl << lastName << ",\t" << firstName
              << "\t\tPhone: " << phoneNumber;
         }

      long get_phone() const   // return person's phone number
         { return phoneNumber; }
};
                               // overloaded < for person class
bool operator<(const person& p1, const person& p2)
{
   if(p1.lastName == p2.lastName)
      return (p1.firstName < p2.firstName) ? true : false;
   return (p1.lastName < p2.lastName) ? true : false;
}
                               // overloaded == for person class
bool operator==(const person& p1, const person& p2)
{
   return (p1.lastName == p2.lastName &&
        p1.firstName == p2.firstName ) ? true : false;
}

// function object to compare person's phone number
class phoneEqual : binary_function<person, long, bool>
{
public:
    bool operator() (const person& p, const long& n) const
    {
       return (p.get_phone()==n) ? true : false;
    }
};
////////////////////////////////////////////////////////////////
int main()
   {

   list<person> persList;     // list of persons

   list<person>::iterator iter1;  // iterators to a
   list<person>::iterator iter2;  // list of persons
                                        // put persons in list
   persList.push_back( person("Deauville", "William", 8435150) );
   persList.push_back( person("McDonald", "Stacey", 3327563) );
   persList.push_back( person("Bartoski", "Peter", 6946473) );
   persList.push_back( person("KuangThu", "Bruce", 4157300) );
   persList.push_back( person("Wellington", "John", 9207404) );
   persList.push_back( person("McDonald", "Amanda", 8435150) );
   persList.push_back( person("Fredericks", "Roger", 7049982) );
   persList.push_back( person("McDonald", "Stacey", 7764987) );

   // find person or persons with specified phone number
   cout << "\n\nEnter phone number (format 1234567): ";
   long sNumber;                     // get search number
   cin >> sNumber;
                                     // search for first match
   iter1 = find_if( persList.begin(),
                    persList.end(),
                    bind2nd(phoneEqual(), sNumber) ); // func obj
   if( iter1 != persList.end() )
      {
      cout << "\nPerson(s) with that phone number is(are)";
      do
         {
         (*iter1).display();        // display match
         iter2 = ++iter1;           // search for another match
         iter1 = find_if( iter2,
                          persList.end(),
                          bind2nd(phoneEqual(), sNumber) );
         } while( iter1 != persList.end() );
      }
   else
      cout << "There is no person with that phone number.";
   return 0;
} 

