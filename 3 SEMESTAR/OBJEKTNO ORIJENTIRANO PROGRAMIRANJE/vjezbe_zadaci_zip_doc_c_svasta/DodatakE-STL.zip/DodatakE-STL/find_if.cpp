// find_if.cpp
// searches array of strings for first name that matches "Don"
#include <iostream>
#include <algorithm>
#include <string.h>              // for strcmp()
using namespace std;
                                 // array of strings
char* names[] = { "George", "Estelle", "Don", "Mike", "Bob" };

bool isDon(char*);               // prototype

int main()
{
   char** ptr;
                                 // find the first string "Don"
   ptr = find_if( names, names+5, isDon );

   if(ptr==names+5)              // display results
      cout << "Don is not on the list";
   else
      cout << "Don is element "
           << (ptr-names)
           << " on the list."<<endl;
    return 0;
   }

bool isDon(char* name)           // returns true if name=="Don"
   {
   return ( strcmp(name, "Don") ) ? false : true;
   }




