// sortemp.cpp
// sorts array of floats in backwards order,
// uses greater<>()  function object
#include <iostream>
#include <algorithm>
#include <functional>
using namespace std;
                        // array of floats
float fdata[] = { 19.2, 87.4, 33.6, 55.0, 11.5, 42.2 };

int main()
  {                                          // sort the floats
   sort( fdata, fdata+6, greater<float>() );

   for(int j=0; j<6; j++)                    // display sorted floats
      cout << fdata[j] << endl;
   return 0;
}

