#include <iostream.h>
#include <math.h>

double sqroot(double n, double d, double g) 
{
double x;
    x = (d + g)/ 2.0;
    if (g - d < 0.000001)
       return x;
    else if (n - x* x < 0.0)
       return sqroot( n, d, x);
    else
       return sqroot( n, x, g);
}

int main() 
{
int i;
double n, x;
    cout <<"unesi broj: ";
	cin >> n;
    if(n<0) n = -n; 
    // po�etne granice d=0.0, g=n 
    x = sqroot( n, 0.0, n);
    cout << "sqrt("<< n <<") = " << x 
	     <<" treba biti:"<< sqrt(n)<<endl;               
    return 0;
}

