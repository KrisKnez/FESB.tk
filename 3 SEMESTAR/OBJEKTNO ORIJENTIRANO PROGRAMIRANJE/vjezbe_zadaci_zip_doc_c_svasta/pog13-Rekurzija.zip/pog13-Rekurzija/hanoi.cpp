/* Program: hanoi.c */
#include <iostream>
using namespace std;

void pomakni_kulu(int n, char A, char B, char C);
void pomakni_disk(char from, char to);

int main()
{
	int n = 3;  // npr. za slu�aj 3 diska
	pomakni_kulu(n, 'A','B','C');
	return 0;
}


void pomakni_kulu(int n, char A, char B, char C)
{
	if (n > 0) 
	{
		pomakni_kulu (n - 1, A, C, B);
		pomakni_disk (A, B);
		pomakni_kulu (n - 1, C, B, A);
	}
}

void pomakni_disk(char sa_kule, char na_kulu)
{
	cout << sa_kule << " -> " << na_kulu << endl;
}

