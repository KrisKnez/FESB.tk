#include <iostream>
#include <math.h>
#include <stdlib.h>

using namespace std;

#define EPSILON 0.000001

double sqrt_rek(double n, double d, double g) 
{
double x;
    x = (d + g)/ 2.0;
if (g - d < EPSILON)   
    return x;
else if (n < x*x )     
    return sqrt_rek(n, d, x);
else         
    return sqrt_rek(n, x, g);
}

double SquareRoot(double n) 
{
     
      double g, d=0.0;
     
      if(n < 0) n= -n; // samo za poitivne vrijednosti 
      
      // po�etne granice d=0.0, g=n ili 1 ako je n<1
      if(n>1) 
	      g=n; 
      else 
	      g=1.0; 
      return sqrt_rek(n, d, g);
}

int main( int argc, char *argv[]) 
{
int i;
double n;
   for (i = 1; i < argc; i++) 
   {
      n = atof(argv[i]);
      cout <<"Drugi korijen od " << n <<" = " << SquareRoot(n)
	       << "  (treba biti: "<< sqrt(n) << ")\n";
   }
   return 0;
}
