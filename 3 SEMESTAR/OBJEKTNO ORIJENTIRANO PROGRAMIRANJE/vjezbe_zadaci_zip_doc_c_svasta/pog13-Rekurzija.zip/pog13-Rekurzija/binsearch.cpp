/* Program: binsearch.cpp */
#include	<iostream>
#include	<stdlib.h> 
#include	<string.h>                      
using namespace std;

typedef char *string;


void * binsearch( const void *px, const void *niz, size_t n, 
            size_t el_size, int (*pCmpFun)(const void *, const void *)  ) 
{  
   int i, d=0, g=n-1;
   int cmp;
   char * adr;
   while (d <= g)    
   { 
      i = (d + g)/2;
      
      adr = (char *)niz + i*el_size;
      cmp = (*pCmpFun)((void *)adr, (void *)px);

      if (cmp == 0) 
          return (void *) adr;
      if (cmp < 0) 
          d=i+1;        
      else  
          g=i-1;
  }
  return NULL;
}

int  UsporediStringove( const void *pstr1, const void *pstr2 )
{
	  return strcmp( *(string*) pstr1, *(string*)pstr2 );
}


int main( void )
{
	string txt[] = {"Ante", "Ivo", "Marko", "Jure", "Bozo"};	
	int numstrings = sizeof(txt)/sizeof(txt[0]); 
	string key="Ivo";
	int	i, idx;
	string * pstr;
	
	for(i = 0; i < numstrings; i++ )  
		cout << txt[i] << " " ;
	
	// sortiraj niz stringova leksikografski 
	// koristi funkciju qsort i strcmp za leksikografsku usporednu 
	
	qsort((void *)txt, numstrings, sizeof(char*),  UsporediStringove);

	cout << "\nNakon sortiranja:\n";
	for(i = 0; i < numstrings; i++ ) 
		cout << txt[i] << " " ;
	
	// pronadji string key 
	pstr =(string*) binsearch(&key, txt, numstrings, sizeof(char*),  UsporediStringove);
	
	if(pstr != NULL)
		cout << "\nPronadjen string " << *pstr << " na adresi" <<pstr << endl;
	else
		cout << "\nNije pronadjen string " << key << endl;
	return 0 ;
}



