//Program: fakt-stog.c
// Prora�un n!. Vrijednost od n unosi korisnik. 
// vrijednost od n mora biti unutar intervala [0,13]
#include <iostream>
#include <vector>
using namespace std;

vector<int> S;                // simulator izvrsnog stoga
int Reg;                           // registar u kojeg se upisuje rezultat funkcija

void printstog() 
{
   cout <<"Stog: ";	
   for(int i=0; i<S.size(); i++)
		   cout << S[i] <<" ";
   cout << endl;
}
void push(int n) {	S.push_back(n); printstog(); } 
int & top(int n=0) {return S[S.size()-1+n];}
void pop() {S.pop_back(); printstog();}

void factorial()
{
	int n = top();    // n je lokalna varijabla
	if (n == 0) {		
		Reg = 1;      // rezultat za n==1          
	}
    else  {
		push(n-1);     // poziv za arg =n -1
		factorial();
		pop();
		Reg = n * Reg;  // vraca rezultat na stog
    }
}

int main()
{
   int n, result;
   cout << "Unesite broj unutar intervala [0,13]\n";
   cin >> n;                               
   
   if((n < 0) || (n > 13))
   {
      cout << "Otipkali ste nedozvoljenu vrijednost\n" ;
      return 1;
   }
   push(n);
   factorial();
   result = Reg;
   pop();
   cout << "Vrijednost "<< n << "! iznosi: " << result << endl;
   return 0;
}
