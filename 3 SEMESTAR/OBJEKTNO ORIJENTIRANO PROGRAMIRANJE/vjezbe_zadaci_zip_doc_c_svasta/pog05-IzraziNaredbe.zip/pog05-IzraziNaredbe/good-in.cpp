/* Datoteka: good-in.cpp 
 * Primjer do while petlje 
 *****************************/

#include <iostream>
using namespace std;

int main(void)
{
    char ch;
	do {
        cout << "Predjednik SAD je:\n"
             << "(1) Bill Clinton\n(2) Bill Gates\n(3) Bill Third\n"
             << "\nOtipkaj 1, 2 ili 3 <enter>!\n";
        
		cin >> ch;		
		
	}while( ch != '1' && ch != '2'&& ch != '3');
		
  if(ch =='1') cout << "Tocno\n";
  else cout << "Nije tocno\n";
  
  return 0;
}  

