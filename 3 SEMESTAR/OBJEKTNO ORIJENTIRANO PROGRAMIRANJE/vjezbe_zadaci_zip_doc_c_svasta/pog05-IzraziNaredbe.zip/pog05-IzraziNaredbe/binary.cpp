// datoteka: binary.c 
// program ispisuje binarni kod cijelog broja
#include <iostream>

using namespace std;

int getbit (unsigned x, int n)
{  
	if (n>=0 && n<32) // unsigned ima 32 bita
	{
		return (x & 01 << n) != 0;
	}
	return 0;
}

int main() 
{
int x, i, n;

	cout << "Otkucaj cijeli broj:\n";
	cin >> x;
	n = 8*sizeof(x);
	cout << "Binarni kod je: ";
	for (i =n-1; i>=0; i--)
		cout  << getbit(x,i);	    
	cout << endl;
	return 0;
}

