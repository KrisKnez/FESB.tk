/* Datoteka: ifelseif.c 
 * Primjer vi�estruke logi�ke selekcije 
 ****************************************/

#include <iostream>
using namespace std;

int main(void)
{
  char ch;
  cout << "Predjednik SAD je:\n"
       << "(a) Bill Clinton\n(b) Bill Gates\n(c) Bill Third\n"
       << "\nOtipkaj slovo:\n";

  cin >> ch;

  if      (ch =='A' || ch =='a') cout << "Tocno\n";
  else if (ch =='B' || ch =='b') cout << "Nije tocno\n";
  else if (ch =='C' || ch =='c') cout << "Nije tocno\n";
  else    cout << "Otipkali ste pogreno slovo";

  return 0;
}  



