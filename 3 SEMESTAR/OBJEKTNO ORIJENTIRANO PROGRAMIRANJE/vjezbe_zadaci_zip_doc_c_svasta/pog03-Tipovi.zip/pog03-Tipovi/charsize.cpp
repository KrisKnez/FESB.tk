// charsize.cpp-Program kojim se ispituje tip znakovne konstante 

#include <iostream>
using namespace std;

int main()
{
    char c;      // deklaracija varijable c tipa char
    int x;       // deklaracija varijable x tipa int

    c = 'A';     // objema varijablama mo�e se pridijeliti 
    x = 'A';     // vrijednost znakovne konstante 'A' 

    cout << "c = "          << c           << endl;
    cout << "Sizeof c = "   << sizeof (c)  << endl;
    cout << " x = "         << x           << endl;
    cout << "sizeof x = "   << sizeof(x)   << endl;
    cout << "Sizeof 'A' = " << sizeof('A') << endl;

    return 0;
}

