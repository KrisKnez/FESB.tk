//Datoteka: overload1.cpp 
#include <iostream>
using namespace std;

int Podijeli (int a, int b)
{  
  return (a/b);
}

float Podijeli (float a, float b)
{
  return (a/b);
}

int main ()
{
  int   n=5, m=2;
  float x=5.0, y=2.0;
  cout << Podijeli(n, m) << endl;
  cout << Podijeli(x, y) << endl;
  return 0;
}
