 // adresa.cpp - primjer ispisa adrese varijable 

#include<iostream>
using namespace std;

int main()
{
    int y;
    y = 777;
   
    cout << "Vrijednost varijable y je:" << y << endl;
    cout << "Adresa varijable y je " << &y << endl;
    cout << "Vrijednost na toij adresi je:" << *(&y) << endl;
    return 0;
}
