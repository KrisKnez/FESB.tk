#include <iostream> 
using namespace std;

int kvadrat(int);   

int main ()
{
 int x;
     x=kvadrat(5); 
     cout << x;
     return 0; 
}

int kvadrat(int y)
{
	return y * y;
}

