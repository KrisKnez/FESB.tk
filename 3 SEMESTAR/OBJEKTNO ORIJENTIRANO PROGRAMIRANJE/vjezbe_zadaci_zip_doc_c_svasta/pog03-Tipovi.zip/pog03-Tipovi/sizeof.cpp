// sizeof.c-Program koji ispisuje zauze�e memorije 
//         za sve proste tipove C++ jezika 

#include <iostream>
using namespace std;

int main()
{	
    cout << "Sizeof(bool)          = " << sizeof(bool)          << endl;
    cout << "Sizeof(unsigned char) = " << sizeof(unsigned char) << endl;
    cout << "Sizeof(char)          = " << sizeof(bool)          << endl;
    cout << "Sizeof(short)         = " << sizeof(short)         << endl;
    cout << "Sizeof(unsigned short)= " << sizeof(unsigned short)<< endl;
    cout << "Sizeof(int)           = " << sizeof(int)           << endl;
    cout << "Sizeof(unsigned int)  = " << sizeof(unsigned int)  << endl;
    cout << "Sizeof(long)          = " << sizeof(long)          << endl;
    cout << "Sizeof(unsigned long) = " << sizeof(unsigned long) << endl;
    cout << "Sizeof(float)         = " << sizeof(float)         << endl;
    cout << "Sizeof(double)        = " << sizeof(double)        << endl;    
    return 0;
}
