/* limits.cpp - Program koji ispisuje maksimalnu i minimalnu */
/*          vrijednost numeri�kih tipova C++ jezika */

#include<iostream>
#include	<limits.h>
#include	<float.h>
using namespace std;

int main( void )
{
    cout << "Tip         " << "Interval vrijednosti"        << endl;
	cout << "bool        " << false    << "..." << true     << endl;
    cout << "char        " << CHAR_MIN << "..." << CHAR_MAX << endl;
    cout << "short int   " << SHRT_MIN << "..." << SHRT_MAX << endl;
    cout << "int         " << INT_MIN  << "..." << INT_MAX  << endl;
    cout << "long int    " << LONG_MIN << "..." << LONG_MAX << endl;
    cout << "float       " << FLT_MIN  << "..." << FLT_MAX  << endl;
    cout << "double      " << DBL_MIN  << "..." << DBL_MAX  << endl;
    cout << "long double " << LDBL_MIN << "..." << LDBL_MAX << endl;
    return 0 ;
}


