#include <iostream>
using namespace std;

#define MESSAGE "Vrijednost broja pi = "
#define PI 3.141592653589793
#define ENDL cout << "\n"

int main( void) 
{
  cout << MESSAGE;
  cout << PI;
  ENDL; 
  return 0;
}

