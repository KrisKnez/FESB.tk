//Datoteka:fun-obj.cpp
#include <iostream>
using namespace std;

class increment
{
  // generic increment function
  public : 
     int operator() (int x) const { return ++x;}
};

void f(int n, const increment& incr)
{ 
  cout << incr(n) << endl; 
}

int  main()
{
  int i = 0;
  increment incr;
  f(i, incr);  // ispisuje 1
  return 0;
}

