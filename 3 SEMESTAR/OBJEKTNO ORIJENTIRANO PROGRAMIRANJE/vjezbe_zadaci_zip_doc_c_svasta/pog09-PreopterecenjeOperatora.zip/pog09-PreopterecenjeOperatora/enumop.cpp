#include <iostream>
using namespace std;

enum Days 
{
  Monday, Tuesday,  Wednesday,   Thursday, 
  Friday,   Saturday,   Sunday
};

Days& operator++(Days& d, int)  // postfix ++
{
  if (d == Sunday) 
    return d = Monday; 
  int temp = d;        //convert to an int
  return d = (Days) (++temp); 
}

int main()
{
 Days day = Monday;
 for (;;) //prikaz  days kao cjelobrojnioh vrijednosti
 {
   cout<< day <<endl;
   day++;
   if (day == Sunday) 
     break;
 }
 return 0;
}
 
