// Datoteka: counter.cpp 
// implementacija klase Counter

#include "counter.h"

void  Counter::set_modulo(int mod)
{  
	if(mod <= 1)   m_mod = INT_MAX;
    else           m_mod =  mod;
}           
  
int Counter::incr_count(void) 
{
    m_count++;
    if(m_count >= m_mod) m_count = 0; 
    return m_count;
}

const Counter& Counter::operator++() // prefiks operator
{
       ++m_count;;                   // inkrementiraj broja�
       return *this;                 // vrati njegovu referencu
}

const Counter Counter::operator++(int unused) // postfiks operator
{
    Counter temp(*this);  // zapamti trenutno stanje u temp objektu
    ++ m_count;;          // inkrementiraj broja�
    return temp;          // vrati temp objekt
}

// friends  
int CompareCounters (Counter &c1, Counter &c2)
{
	return c1.m_count - c2.m_count;
}

bool operator == (const Counter &c1, const Counter& c2) 
{
  return c1.m_count == c2.m_count;
} 

ostream & operator << (ostream & s, const Counter &c1) 
{
    return s << c1.get_count(); // ostream objekt vra�a referencu
}

