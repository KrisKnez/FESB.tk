#include<assert.h>

const int def_iarray_size = 5;

class iarray { // integer array
	
public:
    iarray(int def_size = def_iarray_size) {// predodre�eni konstruktor
        init((const int *) 0, def_size);
    }
    iarray(const iarray& rhs) {             // kopirni konstruktor
        init(rhs.m_arr, rhs.m_size);
    }
    iarray(const int *array, int size) {    // konstruktor pomo�u postoje�ec int * niza
        init(array, size);
    }
	
    ~iarray(void) { delete [] m_arr; }         // destruktor

    iarray& operator=(const iarray&);
    int size() const {return m_size;}
    
	// indeksni operator
	int& operator[](int index) { return m_arr[index]; }
    const int& operator[](int index) const { return m_arr[index]; }
    
    int * intptr() const {return m_arr;}  // pretvorba tipa
    operator int *() {return m_arr;}  // automatska pretvorba tipa

private:
	void init(const int *array, int size); // pomo�na funkcija 
    int *m_arr; // pokaziva� na  memoriju koja sadr�i niz
    int m_size; // size of array
};


void iarray::init(const int *array, int size) 
{
    // alociraj memoriju veli�ine m_size cijelih brojeva
    m_size = size;
    m_arr = new int [size];
    //inicijaliziraj niz, ako je array != NULL
    if (array != 0) 
	for (int index=0; index<size; index++) 
    { 
	    m_arr[index] = array[index];
    }
}
iarray& iarray::operator=(const iarray& rhs) 
{
    if (this != &rhs) {             // ako se objekti razlikuju
    delete [] m_arr;                // dealociraj zauzetu memoriju
    init(rhs.m_arr, rhs.m_size);  // alociraj lhs-arr  i kopiraj rhs to lhs
    }
    return *this;                   // vrati referencu
}


#include <iostream.h>

int main() 
{ 
    const int num_days = 6;
    int temperature[num_days] =
                         { 23, 28, 21, 33, 35, 27 }; // neki podaci u reg. nizu
    iarray all_temp(temperature, num_days); // konstruktor iz reg.niza
    iarray not_too_hot = all_temp;              // kopirni konstruktor
    void remove_hot(iarray&);               
    remove_hot(not_too_hot);
    
    cout << "Temperature of nice days: ";
    for (int day=0; day<not_too_hot.size(); day++)
           cout << " " << not_too_hot[day];
    cout << endl;
}

void remove_hot(iarray& day_temp) 
{
    const int too_hot = 30;
    int num_nice = 0;
    int day;
    for (day=0; day<day_temp.size(); day++) 
	{
          if (day_temp[day] < too_hot)
              num_nice++;
    }
    iarray dummy(num_nice); 
    num_nice=0;    
    for (day=0; day<day_temp.size(); day++) {
          if (day_temp[day] < too_hot)
         dummy[num_nice++] = day_temp[day];
    }
    day_temp = dummy;
}
