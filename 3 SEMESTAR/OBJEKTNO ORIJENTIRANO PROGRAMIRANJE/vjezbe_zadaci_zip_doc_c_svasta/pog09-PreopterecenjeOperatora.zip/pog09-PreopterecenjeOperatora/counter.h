// Datoteka: counter.h 
// Klasa i broja�a po modulu


#include <limits.h>          // zbog definicija INT_MAX

class Counter {         // specifikacija �lanova klase

	int m_count;        // stanje broja�a 
	int m_mod;          // modul izbroja  

public:
	// konstruktor
	Counter(int mod=INT_MAX ): m_count(0), m_mod(mod) {}

	// specifikacija �lanskih funkcija broja�a

	void reset() {m_count= 0;}
	// Funkcija: inicira broja� na po�etnu vrijednost nula  
	int get_count(void){ return m_count;}
	// Funkcija: vra�a trenutnu vrijednost broja�a 
	int get_modulo(void) {return m_mod;};  
	// Funkcija: vra�a trenutnu vrijednost modula broja�a 
	void set_modulo(int mod); 
	// Funkcija: postavlja trenutnu vrijednost modula broja�a 	
	int incr_count(void); 
	// Funkcija: incrementira vrijednost broja�a za 1
	// Ako vrijednost broja�a postane jednaka ili ve�a, 
	// od zadamog modula vrijednost broja�a postaje nula. 
	// Vra�a: trenutnu vrijednost broja�a 
    Counter & operator++();           //prefiks inkrement 
    Counter & operator++(int unused); //postfiks inkrement
    friend bool operator == (const Counter &c1, const Counter& c2);
    friend bool operator < (const Counter &c1, const Counter& c2);
    friend ostream& operator << (ostream &s, const Counter &c1);
    friend int CompareCounters (Counter &c1, Counter &c2);
};
