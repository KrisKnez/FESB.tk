//  hellomain.cpp: 
//  C++ program s u kojem se poziva  Hello() 

void Hello();

int main()
{
   Hello();
   return 0;
} 

