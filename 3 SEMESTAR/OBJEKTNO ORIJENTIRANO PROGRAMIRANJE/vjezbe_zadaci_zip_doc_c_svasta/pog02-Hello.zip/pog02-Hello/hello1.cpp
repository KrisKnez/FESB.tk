/* Prvi  C++ 	program. */

#include <iostream.h>

int main() 
{
  cout << "Hello world!" << endl;
  return 0;
}
