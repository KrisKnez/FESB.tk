//  hello5.cpp: 
//  C++ program s korisni�ki definiranim funkcijama Hello() i main()
//  i prototipom funkcije Hello()

#include <iostream>

using namespace std;

void Hello();

int main()
{
   Hello();
   return 0;
} 

void Hello()
{
   cout << "Hello world";
   cout << endl;
}