//  hellosub.cpp: 
//  C++ program s definicijom funkcijeHello() 

#include <iostream>

using namespace std;

void Hello()
{
   cout << "Hello world!";
   cout << endl;
}
