//  hello4.cpp: 
//  C++ program s korisni�ki definiranim funkcijama Hello() i main()

#include <iostream>

using namespace std;

void Hello()
{
   cout << "Hello world";
   cout << endl;
}

int main()
{
   Hello();
   return 0;
} 
