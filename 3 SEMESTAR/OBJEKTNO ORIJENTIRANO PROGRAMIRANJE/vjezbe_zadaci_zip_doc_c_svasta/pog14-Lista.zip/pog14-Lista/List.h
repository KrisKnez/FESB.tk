#ifndef LIST_H
#define LIST_H

#include <assert.h>

template <class Type>
class List
{
public:
  List()  { First = Last = Current = NULL; }
  ~List() { clear(); }
  
  void    push_front(const Type & el);
  void    pop_front();
  void    push_back(const Type & el);
  void    pop_back();
  void    clear();
  bool    empty() { return First == NULL ? true : false; }
  int      size();
  int      remove(Type &el);
  bool    is_present(Type &el) ;
  void    to_front() { Current = NULL; }
  Type   *get_next();
  Type  *first_elem() {return (First == NULL) ? NULL : &(First->Elem);}
  Type  *last_elem() {return (Last == NULL) ? NULL : &(Last->Elem);}

protected:  
  class ListElem
  {
  public:
    ListElem(const Type &elem, ListElem *list = NULL) : Elem(elem) { Next = list; }
    Type      Elem;
    ListElem *Next;
  };
  ListElem *Current;
  ListElem *First;
  ListElem *Last;
};


template <class Type>
void 
List<Type>::push_front(const Type &elem) 
{
  ListElem *newElem = new ListElem(elem,First);
  assert(newElem != NULL);

  if (First == NULL) Last = newElem;

  First = newElem;
}

template <class Type>
void    
List<Type>::pop_front() 
{
	if(empty()) 
		return;
	ListElem *tmp = First;
	First = First->Next;
    delete tmp;
}

template <class Type>
void    
List<Type>::pop_back() 
{	
	if(empty()) 
		return;
	if(First == Last)
		pop_front();
	else
	{
	    ListElem *p = First;	
		while (p->Next != Last)
				p = p ->Next;
		delete Last;
		Last = p;
		Last->Next=NULL;
	}
}

template <class Type>
void
List<Type>::push_back(const Type &elem) 
{ 
	
  ListElem *newElem = new ListElem(elem);
  assert(newElem != NULL);
  
  if (First == NULL)
    First = newElem;
  else 
    Last->Next = newElem;
  
  Last = newElem;
}

template <class Type>
void 
List<Type>::clear()
{ 
  ListElem *pElem = First;
    
    while (pElem != NULL)
	{
        ListElem *tmp = pElem;
        pElem = pElem->Next;
        delete tmp;
    }

    First = Last = NULL;
}


template <class Type>
int
List<Type>::size() 
{
  int count = 0;
  
  Current = First;
  while (Current != NULL)
    {
      count++;
      Current = Current->Next;
    }
     
  Current = NULL;
  return count;
}

template <class Type>
Type *
List<Type>::get_next() 
{
  if (Current == NULL)
    Current = First;
  else 
    Current = Current->Next;

  if (Current != NULL)
    return &(Current->Elem);
  else
    return NULL;
}    

template <class Type>
int List<Type>::remove(Type &elem)
{ 
  ListElem *pElem = First;
  int count = 0;
  
  while ( pElem != NULL && pElem->Elem == elem) 
    {
      ListElem *tmp = pElem->Next; 
      delete pElem; 
      count++;
      pElem = tmp; 
    } 
  
  if ((First = pElem) == NULL) 
    {
      Last = NULL; 
      return count; 
    }

  ListElem *prevElem = pElem;
  pElem = pElem->Next;

  while (pElem != NULL) 
    {
      if ( pElem->Elem == elem) 
	{ 
	  prevElem->Next = pElem->Next;
	  if (Last == pElem) Last = prevElem;
	  delete pElem;
	  count++;
	  pElem = prevElem->Next;
	}
      else 
	{
	  prevElem = pElem;
	  pElem = pElem->Next;
	}
    } 
  return count;
}

template <class Type>
bool
List<Type>::is_present(Type &elem) 
{ 
  if (First == NULL) return false;

  ListElem *pElem = First;

  for (;pElem != NULL; pElem = pElem->Next) 
    if (pElem->Elem == elem) 
		return true;
  
  return false;
}

#endif


