//Datoteka: polish.cpp
#include <iostream>
#include <cstring>
//#include <stack>
#include "stack-list.h"
using namespace std;

#define isDigit(c) (((c) >= '0') && ((c) <= '9'))

int main(int argc, char *argv[])
{   
    char *str; 
    int i, len;
	int arg1, arg2;
    Stack<int> S;   
    
    if (argc < 2) {
      cout << "Za proracun (30/(5-2))*10  otkucaj:\n";
      cout << "c:> polish  \"30 5 2 - / 10 *\n\"";
      exit(1);
    }                   
    str = argv[1];
    len = strlen(str);
    
    for (i = 0; i < len; i++)
    {   
        if (str[i] == '+')
		{
			arg2 = S.top(); S.pop(); 
			arg1 = S.top(); S.pop();
			S.push(arg1+arg2);
		}
        if (str[i] == '*')
		{
			arg2 = S.top(); S.pop(); 
			arg1 = S.top(); S.pop();
			S.push(arg1*arg2);          
		}
        if (str[i] == '-') 
		{
			arg2 = S.top(); S.pop(); 
			arg1 = S.top(); S.pop();
			S.push(arg1-arg2);          
        }
        if (str[i] == '/') {
			arg2=S.top(); S.pop(); 
			arg1= S.top();S.pop();
			if (arg2==0) { 
				cout << "Djeljenje s nulom\n"; exit(1);
			} 
			S.push(arg1/arg2);                    
		}
        if (isDigit(str[i])) /* konverzija niza znamenki u broj */
        {
          S.push(0);        
          do {
			 arg1 = S.top(); S.pop();
             S.push(10*arg1 + ((int)str[i]-'0')); 
             i++;
          } while (isDigit(str[i])); 
          i--;
        }
    }
	arg1 = S.top();
    cout << "Rezultat: "<< str <<"="<<arg1<<" \n";
	return 0;
}
