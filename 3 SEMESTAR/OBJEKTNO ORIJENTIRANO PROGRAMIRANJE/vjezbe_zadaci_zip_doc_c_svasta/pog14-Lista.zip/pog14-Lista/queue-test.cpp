//datoteka queue-test.cpp
#include <iostream>
#include <string>
#include "queue.h"
using namespace std;

typedef Queue<string> StringQueue;

void print_queue(StringQueue &Q)
{
  string s;
   while(Q.get(s))	
	   cout << s << endl;
}

int main()
{
   
   StringQueue Q;
   string str;
   
   while (getline(cin, str)) 
	{
      if(str.size()==0) break;
      Q.put(str);         
   }
   
   cout << "\nOtkucali ste\n";
   print_queue(Q);
   return 0;
}
                                        
                                        


                               
