#ifndef _QUEUE_H_
#define _QUEUE_H_

// Class Queue realiziran pomo�u liste  
/////////////////////////////////////// 

#include "List.h"

template <class Type>
class Queue
{
public:
   Queue(){}       
   ~Queue(){}       

   bool empty()  {return L.empty();}
   // vraca true ako je red prazan 

   int size() {return L.size();}
   // vraca broj elemenata reda 

    bool get(Type &elem);
   // PRE: u redu je bar jedan elemant 
   // dobavlja vrijednost elementa koji je na po�etku reda  
   // i odstranjuje ga iz reda
   // vra�a true ako postoji element na stogu  

   void put(const Type &elem){ L.push_back(elem); }
   // postavlja element na kraj reda  
   // POST: u redu je jedan element vise 
   
private:
   List<Type> L;
};

template <class Type>
bool Queue<Type>::get(Type &elem)	
{
   if(L.empty()) 
	   return false;
   elem = *L.first_elem();
   L.pop_front();
   return true;
}

#endif
