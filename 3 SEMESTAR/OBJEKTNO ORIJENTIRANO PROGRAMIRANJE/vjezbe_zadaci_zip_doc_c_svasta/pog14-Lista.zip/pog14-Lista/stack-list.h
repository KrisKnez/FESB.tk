#ifndef _STACK_LIST_H_
#define _STACK_LIST_H_

// Class Stack realiziran pomo�u liste  
/////////////////////////////////////// 
#include "List.h"

template <class T>
class Stack
{
   List<T> L;
public:
   Stack(){}       
   ~Stack(){}       

   bool empty()  {return L.empty();}
   // vraca true ako je stog prazan 

   int size() {return L.size();}
   // vraca broj elemenata na stogu 

   T& top() {return *L.first_elem();}
   const T& top() const {return *L.first_elem();}
   // PRE: na stogu mora biti bar jedan element (provjeri sa empty()
   // dobavlja vrijednost elementa na vrhu stoga u elem
   // ne odstranjuje element sa stoga 
   
   void pop() { L.pop_front(); }
   // PRE: na stogu mora biti bar jedan elemant 
   // odstranjuje top element sa stoga 
   // POST: na stogu je jedan element manje 
      
   void push(const T &elem){ L.push_front(elem); }
   // postavlja element na vrh stoga 
   // POST: na stogu je jedan element vise 
   
};

#endif
