
/* Operacije s listom u stilu C-jezika */
#include <iostream.h>


struct node { 
   int item;
   struct node *next;
};

typedef struct node Node;


int isEmpty(Node * first);
Node * append_node(Node * first, Node * thisPtr);
Node * prepend_node(Node * first, Node * newfirst);
Node * insert_node_after(Node * thisPtr, Node * newp);
int delete_node(Node * *first, Node * thisptr);
Node * delete_first(Node * first);

Node * make_new_node(int item);
Node * find_item(Node * first, int value);
void print_list(Node * first);

/* Print the instructions */
void instructions(void)
{
   cout << "Enter your choice:\n"
          "   1 to insert an element at head of the list.\n"
          "   2 to insert an element at end of the list.\n"
          "   3 to insert an element after some element of the list.\n"
          "   4 to delete an element from the list.\n"
          "   0 to end.\n";
}

int main()
{
   
   Node * Head = NULL;
   Node * Current;
   int choice;
   int item;

   instructions();
   cout << "? ";
   cin >> choice;

   while (choice != 0) {

      switch (choice) {
         case 1: /* add to head of list */
            cout << "Enter a number: ";
            cin >> item;
            Current = make_new_node(item);
            if (Current != NULL)
            {
               Head = prepend_node(Head, Current);
               print_list(Head);
            }   
            break;
         case 2: /* append to end of list */
			cout << "Enter a number: ";
            cin >> item;
            Current = make_new_node(item);
            if (Current != NULL)
            {
               append_node(Head, Current);
               print_list(Head);
            }   
            break;   
         case 3: /* insert element after some existing element */
            if (!isEmpty(Head)) {    
               Node * newptr;
				cout << "Enter item after which to insert: ";
               cin >> item;
               
               Current = find_item(Head, item);
               if (Current == NULL) {
                    cout << item << " not found.\n";
                    break;
               }     
			   cout << "Enter item to be inserted: ";
               cin >> item;
               newptr = make_new_node(item);
               if (newptr == NULL)
               {
                  cout << "No memory.\n";
                  break;
               }                                         
               insert_node_after(Current, newptr);
               print_list(Head);
                             
            }
            else
               cout << "List is empty.\n";
            break;
   
         case 4: /* delete some element */
            if (!isEmpty(Head)) {
			   cout <<"Enter number to be deleted: ";
               cin >> item;
               
               Current = find_item(Head, item);
               if (Current == NULL) {
                    cout << item << " not found.\n";
                    break;
               }  
               if (delete_node(&Head, Current)) {
                  cout << item << " deleted.\n";
                  print_list(Head);
               }
               else
                  cout << item << "not found.\n\n";
            }
            else
               cout << "List is empty.\n";
            break;
         default:
            cout << "Invalid choice.\n";
            instructions();
            break;
      }

      cout << "? ";
      cin >> choice;
   }

   cout << "End of run.\n";
   return 0;
}
                                        
                                        


Node * make_new_node(int value)
{
   Node * newptr = new Node;
   if (newptr != NULL) {    /* is space available */
       newptr->item = value;
       newptr->next = NULL;
   }
   return newptr;
}                 
                               
Node * find_item(Node * first, int value)
{
        Node * current =first;  
          	
        while ( current != NULL) { /* go to the end of list */ 
                if(current->item == value) 
                    break;                    
                current = current -> next;
        }             
        return current; /* return NULL if not found */
}


void print_list(Node * first)
{
        Node * current;        // will use to point to each node
        current = first;         // initialize to point to the 1st node
	   	
	   	if (current == NULL)	cout << "List is empty.\n";
   		else                	cout << "The list is:\n";

        while ( current != NULL) {      // check to see if at the end 
                // print out the data for this node:
                cout << current -> item << "->"; 
                    
               // Now shift current to point to the next node:
                current = current -> next;
        }   
        cout << "\n";

 }              


/* Return 1 if the list is empty, 0 otherwise */
int isEmpty(Node * sPtr)
{
   return sPtr == NULL;
}



/* function: prepend_node
 * ---------------------
 * This function add node to the front of the list 
 * Arguments: 
 *    first pointer 
 *    newfirst pointer 
 * Return: new first pointer
 * Precondition: we assume newfirst != NULL (must be allocated)
 */

Node * prepend_node(Node * first, Node * newfirst)
{
   if(newfirst != NULL) /* assure valid pointer*/
      newfirst->next = first;     
   return(newfirst);
}

 
/* function: append_node
 * ---------------------
 * This function add node to the end of the list 
 * Arguments: 
 *    first pointer 
 *    this pointer 
 * Return: new tail pointer
 * Precondition:we assume we don't know the tail pointer
 */
Node * append_node(Node * first, Node * pNew)
{
   Node * tail = first; 
   
   if(first == NULL)
   {
      first = pNew;
      pNew -> next = NULL;  
   }
   else 
   {
       while ( tail->next != NULL)  /* first find tail pointer*/
          tail = tail -> next;

      tail -> next = pNew;
      pNew -> next = NULL;  
   }
   return pNew; /* last pointer*/
 }

                                               
                                          

/* function: insert_node_after
 * ---------------------------
 * Insert new node in the list AFTER the given node.
 *
 * Arguments:
 *   this - pointer to node after which to insert new node.
 *   newp - pointer to node which we insert in the list.
 * Returns:
 *   pointer to the node containing the new data (or NULL
 *   if addition failed) 
 */


Node * insert_node_after(Node * thisptr, Node * newp)
{
     if (thisptr == NULL) {
          newp->next = NULL;
     } else {
          newp->next = thisptr->next;
          thisptr->next = newp;
     }

     return(newp);
}


/* function: delete_first
 * --------------------
 * delete node pointed by first ptr and free memory
 * !! if data item is also allocated dynamically, then 
 * !! data item must be deallocated before the call to delete_node 
 * Arguments: 
 *   first pointer
 * Return: 
 *   TRUE if succefull, or FALSE on error
*/     

Node * delete_first(Node * first)
{
     Node * tmp = first;
     if(first !=  NULL){ 
          first = first -> next;
          delete tmp;
     }
     return first;
         
}

/* function: find_previous_node 
 * Arguments:
 *   this - pointer to some node.
 *   first - pointer first node.
 * Returns:
 *   pointer to node before 'this', 
 *   or NULL if 'this' node cannot be located

 * The following function searches a list and return the address
 * of the node prior to that pointed to by 'thisptr' node. 
 * If this node cannot be located, then NULL indicate an error. 
 * If this node exists, then, the address of its previous
 * node is returned, or, first pointer in the case when this node 
 * is the first node in the list.
*/	

static Node * find_previous_node(Node * first, Node * thisptr )
{
	Node *	previous;
	Node *	current;
	current = previous = first ;	/* start at first */

/*  Algorithm:
 *  define pointers: current = previous = first;
 *  while 'current' is not pointing to the 'thisptr' 
 *  and it is not pointing to the last node in the list then 
 *       move current node on to the next node, 
 *       saving the address of the previous node
*/

    while( (current != thisptr) && (current->next != NULL ))	
    {
        previous = current;
        current = current->next ;
    }
    return (previous) ;					
        /*  return address or NULL on error */
}

/* function: delete_node
 * --------------------
 * delete node pointed by this pointer and free memory
 * !! if data item is allocated dynamically, then 
 * !! data item must be deallocated before the call to delete_node 
 * Arguments: 
 *   first pointer
 *   this pointer 
 * Return: 
 *   TRUE if succefull, or FALSE on error
*/     


int delete_node(Node **pfirst, Node * thisptr)
{
    
    Node * prev;
    if(*pfirst == thisptr) 
    {
     *pfirst = delete_first(thisptr); 
	return 1;
    }

    prev = find_previous_node(*pfirst, thisptr );

    if(prev == NULL) 
        return 0;
    prev -> next = thisptr->next;
    delete thisptr;      
    return 1;
}
