#include <iostream>
#include "list.h"
using namespace std;

typedef List<int> IntList;

void print_list(IntList &L)
{
	int *p;
   L.to_front();
   while(p = L.get_next())	
	   cout << *p << ",";
   cout << endl;
}

/* Print the instructions */
void instructions(void)
{
   cout << "Odaberi :\n"
          "   1 - za unos elementa na pocetak liste.\n"
          "   2 - za unos elementa na kraj liste.\n"
          "   3 - za brisanje pocetnog elementa.\n"
	      "   4 - za brisanje krajnjeg elementa.\n"
          "   5 - za brisanje proizvoljnog elementa.\n"
          "   0 - za kraj.\n";
}

int main()
{
   
   IntList L;
   int choice;
   int element;

   instructions();
   cout << "? ";
   cin >> choice;

   while (choice != 0) {

      switch (choice) {
         case 1: // unos elementa na pocetak liste
            cout << "Enter a number: ";
            cin >> element;
		    L.push_front(element);
            print_list(L);               
            break;
         case 2: // unos elementa na kraj liste
			cout << "Upisi broj: ";
            cin >> element;
		    L.push_back(element);
            print_list(L);               
            break;   
         case 3: // brisanje pocetnog elementa
			L.pop_front();
            print_list(L);               
            break;
         case 4: // brisanje posljednjeg elementa
			L.pop_back();
            print_list(L);               
            break;
         case 5: // brisanje proizvoljnog elementa
			cout << "Upisi broj koji zelis izbrisati: ";
            cin >> element;
		    if(!L.is_present(element))
			{
				cout << "Broj " << element <<" nije u listi!\n";
		    }
			else
			{
			    L.remove(element);
                print_list(L);               			
			}			
            break;
         default:
            cout << "Ponovi  izbor.\n";
            instructions();
            break;
      }

      cout << "? ";
      cin >> choice;
   }

   cout << "Kraj.\n";
   return 0;
}

