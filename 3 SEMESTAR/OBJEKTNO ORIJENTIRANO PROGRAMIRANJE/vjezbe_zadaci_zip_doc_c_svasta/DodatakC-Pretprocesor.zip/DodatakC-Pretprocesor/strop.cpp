/* program strop.cpp */
#include <iostream>
using namespace std;

#define N 10
#define PRINT(x)    cout << #x "= " << x << endl
#define NIZ(ime, tip, n)    tip  ime ## _array [n]

int main()
{
   int i, y=7;
   NIZ(x, int, N);

   for(i=0; i<N;i++) x_array[i] = 10;
	
   PRINT(y); 
   PRINT(x_array[y]); 
   return 0;
}
