/* program fun.cpp */
#include <iostream>
#include <cmath>
using namespace std;

#define PRINT_FUN(fun, x)    cout << #fun "=" << fun((x)) << endl

int main()
{
   PRINT_FUN(sin, 3);
   PRINT_FUN(cos, 3);	
   return 0;
}
