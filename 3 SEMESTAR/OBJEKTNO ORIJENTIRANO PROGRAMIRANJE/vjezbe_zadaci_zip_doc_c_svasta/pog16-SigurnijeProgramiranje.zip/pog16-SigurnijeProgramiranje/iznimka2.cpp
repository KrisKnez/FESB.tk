// Iznimke s korisnickim tipovima
#include <iostream>
using namespace std;

class Range_error {
public:
	Range_error(int i) :m_i(i){} 
	int m_i;
};

char int2char(int i)
{
	if(i < 0  || i>255)  throw Range_error(i);
	return (char) i;
}

int main()
{
	try {
		char c= int2char (600);
	}
	catch(Range_error x) {
		cout << " int2char: nedozvoljen argument "
             << x.m_i <<  endl;
	}
	return 0;
}
