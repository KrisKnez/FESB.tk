// Iznimke s prostim tipovima

#include <iostream>
using namespace std;

int main () {
  try
  {
		int n;
		char *mystring = new(nothrow) char [10];
		if (mystring == NULL) 
			throw "Greska alokacije memorije!";
	
		cout << "Unesi cijeli broj: ";
		cin >> n;
    
		if (n>9) 
			throw n;
		else
		  mystring[n]='z';
  }
  catch (int i)
  {
		cout << "Iznimka: ";
		cout <<"indeks "<<i<<" izvan dozvoljenog intervala!" << endl;
  }
  catch (char * str)
  {
		cout << "Iznimka: " << str << endl;
  }
  return 0;
}