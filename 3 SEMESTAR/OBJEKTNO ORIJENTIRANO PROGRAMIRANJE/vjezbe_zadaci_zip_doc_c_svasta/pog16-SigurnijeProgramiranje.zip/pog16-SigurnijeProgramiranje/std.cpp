// stdexep.cpp
#include <iostream>
#include <exception>
#include <typeinfo>
using namespace std;

class A {virtual f() {}; };

int main () {
  try {
    A * a = NULL;
    typeid (*a);
  }
  catch (exception & e)
  {
    cout << "Iznimka: " << e.what() << endl;
  }
  catch (bad_typeid)
  {
    cout << "Ovo nece biti izvreno" << endl;
  }
  return 0;
}

