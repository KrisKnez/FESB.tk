//SetTerm.cpp
// upotreba set_terminate() za neprihvacene iznimke
#include <exception>
#include <iostream>
#include <cstdlib>
using namespace std;

void terminator() {
  cout << "Unutar terminatora" << endl;
  abort();
}

void (*old_terminate)() = set_terminate(terminator);

class Klasa {
public:
  class Exep {};
  
	void f() {
    cout << "Unutar Klasa::f()" << endl;
    throw Exep();
  }
};

int main() {
    Klasa b;
    b.f();
} 
