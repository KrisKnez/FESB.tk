// stdexep.cpp
#include <iostream>
#include <exception>
#include <typeinfo>
using namespace std;

class A {virtual f() {}; };

int main () {
  try {
    A * a = NULL;
    typeid (*a);
  }
  catch (std::exception & e)
  {
    cout << "Iznimka: " << e.what();
  }
  return 0;
}

