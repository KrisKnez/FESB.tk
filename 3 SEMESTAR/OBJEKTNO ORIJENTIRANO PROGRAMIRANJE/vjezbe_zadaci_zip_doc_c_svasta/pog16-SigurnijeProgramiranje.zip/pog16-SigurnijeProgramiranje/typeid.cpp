// typeid.cpp
#include <iostream>
#include <typeinfo>
using namespace std;

class Cl { };

int main () {
Cl a;
Cl *b;

  if (typeid(a) != typeid(b))
  {
    cout << "Objekti a i b su razlicitog tipa:\n";
    cout << "Tip od a je: " << typeid(a).name() << endl;
    cout << "Tip od b je: " << typeid(b).name() << endl;
  }
  return 0;
}	
