function y = f8(n)
    y = dirac(n+3) + 2*dirac(n+1) - 4*dirac(n) + dirac(n-2) - 6*dirac(n-4) + 5*dirac(n-5);
end