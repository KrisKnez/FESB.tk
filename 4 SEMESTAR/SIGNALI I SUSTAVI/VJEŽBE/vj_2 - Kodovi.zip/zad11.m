n = 0:40;

subplot(4, 1, 1)
stem(n, 2*sin(3*pi/4*n + 1/3))
title('x1[n]')

subplot(4, 1, 2)
stem(n, 1.5*cos(n/7 + pi/5))
title('x2[n]')

subplot(4, 1, 3)
stem(n, cos(pi/4*n) .* cos(pi/8*n))
title('x3[n]')

subplot(4, 1, 4)
stem(n, 3*cos(pi/8*n) + 2*sin(pi/2*n) - 4*sin(pi/4*n))
title('x4[n]')