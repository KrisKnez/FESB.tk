function y = x1(t)

for i = 1 : length(t)
    y(i) = 0;
    
    if (0 <= t(i)) && (t(i) < 1)
        y(i) = t(i);
    end
    
    if (1 <= t(i)) && (t(i) < 2)
        y(i) = -t(i) + 2;
    end
end