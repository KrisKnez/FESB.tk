function y = x2(t)

for i = 1 : length(t)
    y(i) = 0;
    
    if (-2 <= t(i)) && (t(i) < -1)
        y(i) = t(i) + 2;
    end
    
    if (-1 <= t(i)) && (t(i) < 0)
        y(i) = -t(i);
    end
    
    if (0 <= t(i)) && (t(i) < 1)
        y(i) = t(i);
    end
    
    if (1 <= t(i))
        y(i) = 1;
    end
end