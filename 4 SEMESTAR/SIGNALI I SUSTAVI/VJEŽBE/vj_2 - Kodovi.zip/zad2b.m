% --------------------------------------
% x2[n] = u[n]
% za vremenski interval -20 <= n <= 20
% --------------------------------------

n = -20 : 20;
y = heaviside(n);
y(21) = 1;

stem(n, y)
xlabel('n')
ylabel('x2(n)')