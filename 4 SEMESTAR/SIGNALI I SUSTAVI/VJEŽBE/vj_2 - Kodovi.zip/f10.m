function y = f10(K, t)
y = cos((3*pi*t)/K - pi/4).^2;