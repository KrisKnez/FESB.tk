function y = f9(m, n)
y = cos((2 * pi * m)/7 * n);