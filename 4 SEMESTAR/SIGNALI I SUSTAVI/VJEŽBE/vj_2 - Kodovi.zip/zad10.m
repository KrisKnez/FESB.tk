t = -3*pi:0.01:3*pi; 

subplot(3, 1, 1)
plot(t, f10(1, t))
title('K = 1')

subplot(3, 1, 2)
plot(t, f10(3, t))
title('K = 3')

subplot(3, 1, 3)
plot(t, f10(6, t))
title('K = 6')