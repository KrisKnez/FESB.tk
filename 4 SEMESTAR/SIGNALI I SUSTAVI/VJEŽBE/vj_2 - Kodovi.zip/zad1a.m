% -----------------------------------------
% x1(t) = 2cos(3t) + 3sin(2t)
% na vremenskom intervalu -3pi <= t <= 3pi
% -----------------------------------------

t = -3*pi : 0.01 : 3*pi;
plot(t, 2 * cos(3 * t) + 3 * sin(2 * t))
xlabel('t')
ylabel('x1(t)')