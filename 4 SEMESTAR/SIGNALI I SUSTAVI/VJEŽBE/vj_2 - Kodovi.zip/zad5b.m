t = -3 : 0.01 : 4;

subplot(3, 1, 1)
plot(t, x2(t))
title('x2 - originalni signal')

subplot(3, 1, 2)
plot(t, (x2(t) + x2(-t))/2)
title('x2a(t) - parni dio')

subplot(3, 1, 3)
plot(t, (x2(t) - x2(-t))/2)
title('x2b(t) - neparni dio')