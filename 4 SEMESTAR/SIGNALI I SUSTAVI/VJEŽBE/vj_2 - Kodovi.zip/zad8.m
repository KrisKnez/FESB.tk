n = -20:30;

subplot(4, 1, 1)
stem(n, f8(n))
title('f(n)')

subplot(4, 1, 2)
stem(n, f8(-n - 5))
title('f(-n-5)')

subplot(4, 1, 3)
stem(n, f8(2*n + 8))
title('f(2n + 8)')

subplot(4, 1, 4)
stem(n, f8(1/3*n - 2))
title('f(1/3*n - 2)')