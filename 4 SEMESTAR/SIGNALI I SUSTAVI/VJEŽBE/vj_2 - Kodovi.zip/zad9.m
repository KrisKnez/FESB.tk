n = 0:30;

subplot(4, 1, 1)
stem(n, f9(1, n))
title('m = 1')

subplot(4, 1, 2)
stem(n, f9(5/2, n))
title('m = 5/2')

subplot(4, 1, 3)
stem(n, f9(6, n))
title('m = 6')

subplot(4, 1, 4)
stem(n, f9(8, n))
title('m = 8')