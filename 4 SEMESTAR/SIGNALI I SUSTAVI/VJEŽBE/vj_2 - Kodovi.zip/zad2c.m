% --------------------------------------------------------
% x3[n] =   delta[n + 3] + 2delta[n + 1] - 4delta[n] 
%         + delta[n - 2] - 6delta[n - 4] + 5delta[n - 5]
% za vremenski interval -20 <= n <= 20
% --------------------------------------------------------

n = -5 : 10;

stem(n, dirac(n+3) + 2*dirac(n+1) - 4*dirac(n) + dirac(n-2) - 6*dirac(n-4) + 5*dirac(n-5))
xlabel('n')
ylabel('x3(n)')