t = -3:0.01:7;

subplot(4, 1, 1)
plot(t, x3(t))
title('x(t) - originalni signal')

subplot(4, 1, 2)
plot(t, x3(t - 3))
title('x(t - 3) - pomak')

subplot(4, 1, 3)
plot(t, x3(-t))
title('x(-t) - obrtanje')

subplot(4, 1, 4)
plot(t, x3(1/3*t))
title('x(1/3 * t) - skaliranje')