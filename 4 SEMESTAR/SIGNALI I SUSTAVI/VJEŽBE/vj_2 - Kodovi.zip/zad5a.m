t = -3 : 0.01 : 4;

subplot(3, 1, 1)
plot(t, x1(t))
title('x1 - originalni signal')

subplot(3, 1, 2)
plot(t, (x1(t) + x1(-t))/2)
title('x1a(t) - parni dio')

subplot(3, 1, 3)
plot(t, (x1(t) - x1(-t))/2)
title('x1b(t) - neparni dio')