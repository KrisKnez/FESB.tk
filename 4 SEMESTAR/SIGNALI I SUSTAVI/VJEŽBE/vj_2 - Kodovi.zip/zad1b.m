% ----------------------------------------
% x2(t) = |e^j4t + e^j11t|
% na vremenskom intervalu -pi <= t <= pi
% ----------------------------------------

t = -pi : 0.01 : pi;
plot(t, abs(exp(j * 4 * t) + exp(j * 11 * t)))
xlabel('t')
ylabel('x2(t)')