t = -3:0.01:7;

subplot(2, 1, 1)
plot(t, x2(t))
title('x(t) - originalni signal')
subplot(2, 1, 2)
plot(t, x2(-3*t + 2.5))
title('x(-3*t + 2.5) - signal s trans. vrem. varijablom')