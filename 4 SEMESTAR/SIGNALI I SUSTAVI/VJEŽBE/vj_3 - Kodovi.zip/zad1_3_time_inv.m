% ---------------------------------------------------
% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]

in_bounds  = [-1, 11, 0, 3];     % shema za pobude
out_bounds = [-1, 11, 0, 3];     % shema za odzive

% ------------------- Step --------------------------

% pobuda
subplot(2,2,1)
stem(tout,yout(:,1))
axis(in_bounds)
xlabel('n'); ylabel('x1[n]')
title('x1[n] = u[n]')

% odziv
subplot(2,2,3)
stem(tout,yout(:,2))
axis(out_bounds)
xlabel('n'); ylabel('y1[n]')
title('y1[n]')

% ------------ Pomaknuti step signal ----------------

% pobuda
subplot(2,2,2)
stem(tout,yout(:,7))
axis(in_bounds)
xlabel('n'); ylabel('x2[n]')
title('x2[n] = u(t-3)')

% odziv
subplot(2,2,4)
stem(tout,yout(:,8))
axis(out_bounds)
xlabel('n'); ylabel('y2[n]')
title('y2[n]')

% ---------------------------------------------------