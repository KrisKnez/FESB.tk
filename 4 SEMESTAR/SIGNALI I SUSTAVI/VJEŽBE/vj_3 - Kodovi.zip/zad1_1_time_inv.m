% ---------------------------------------------------
% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]

in_bounds  = [-1, 8, 0, 4];     % shema za pobude
out_bounds = [-1, 8, 0, 80];    % shema za odzive

% ------------------- Step --------------------------

% pobuda
subplot(2,2,1)
plot(tout,yout(:,1))
axis(in_bounds)
xlabel('t'); ylabel('x1(t)')
title('x1(t) = u(t)')

% odziv
subplot(2,2,3)
plot(tout,yout(:,2))
axis(out_bounds)
xlabel('t'); ylabel('y1(t)')
title('y1(t)')

% ------------ Pomaknuti step signal ----------------

% pobuda
subplot(2,2,2)
plot(tout,yout(:,7))
axis(in_bounds)
xlabel('t'); ylabel('x2(t)')
title('x2(t) = u(t-3)')

% odziv
subplot(2,2,4)
plot(tout,yout(:,8))
axis(out_bounds)
xlabel('t'); ylabel('y2(t)')
title('y2(t)')

% ---------------------------------------------------