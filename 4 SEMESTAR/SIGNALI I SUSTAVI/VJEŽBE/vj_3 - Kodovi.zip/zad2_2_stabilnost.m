
% Skripta koja crta grafove za ispitivanje stabilnosti sustava 
% y[n] = e^an * sin(3/4 * pi * n) * x[n] pri cemu je a = 2, -2
% Ispitivanje se provodi dovodjenjem step signala na ulaz

% ---------------------------------------------------
% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]

in_bounds  = [-2, 30, 0, 2];     % shema za pobudu

% ------------------- Step --------------------------

% pobuda
subplot(2,1,1)
stem(tout,yout(:,1))
axis(in_bounds)
xlabel('n'); ylabel('x[n]')
title('x[n] = u[n]')

% odziv
subplot(2,1,2)
stem(tout,abs(yout(:,2)))
set (gca, 'yScale', 'log')
xlabel('n'); ylabel('y[n]')
title('|y[n]|')

% ---------------------------------------------------

% NAPOMENA
% Rezultirajuci graf je X-logY graf apsolutne vrijednosti odziva!