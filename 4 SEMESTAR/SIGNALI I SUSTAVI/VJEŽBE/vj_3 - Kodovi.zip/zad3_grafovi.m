% ---------------------------------------------------
% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]

in_bounds  = [-2, 18, 0, 3];     % shema za pobude
out_bounds = [-2, 18, 0, 15];    % shema za odzive

% ------------------- S1, S2 ------------------------

% pobuda
subplot(2,3,1)
stem(tout,yout(:,1))
axis(in_bounds)
xlabel('n'); ylabel('x[n]')
title('x[n] = u[n]')

% odziv
subplot(2,3,4)
stem(tout,yout(:,2))
axis(out_bounds)
xlabel('n'); ylabel('y[n]')
title('S1 serijski sa S2')

% ------------------- S2, S1-------------------------

% pobuda
subplot(2,3,2)
stem(tout,yout(:,1))
axis(in_bounds)
xlabel('n'); ylabel('x[n]')
title('x[n] = u[n]')

% odziv
subplot(2,3,5)
stem(tout,yout(:,3))
axis(out_bounds)
xlabel('n'); ylabel('y[n]')
title('S2 serijski sa S1')

% ------------------- S1 || S2 ----------------------

% pobuda
subplot(2,3,3)
stem(tout,yout(:,1))
axis(in_bounds);
xlabel('n'); ylabel('x[n]')
title('x[n] = u[n]')

% odziv
subplot(2,3,6)
stem(tout,yout(:,4))
axis(out_bounds)
xlabel('n'); ylabel('y[n]')
title('S1 paralelno sa S2')

% ---------------------------------------------------