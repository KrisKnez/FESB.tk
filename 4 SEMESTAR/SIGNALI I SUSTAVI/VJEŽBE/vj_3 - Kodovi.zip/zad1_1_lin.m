% ---------------------------------------------------
% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]

in_bounds  = [-1, 5, 0, 6];     % shema za pobude
out_bounds = [-1, 4, 0, 60];    % shema za odzive

% ------------------- Step --------------------------

% pobuda
subplot(2,3,1)
plot(tout,yout(:,1))
axis(in_bounds)
xlabel('t'); ylabel('x1(t)')
title('x1(t) = u(t)')

% odziv
subplot(2,3,4)
plot(tout,yout(:,2))
axis(out_bounds)
xlabel('t'); ylabel('y1(t)')
title('y1(t)')

% ------------ Linearno rastuca pobuda --------------

% pobuda
subplot(2,3,2)
plot(tout,yout(:,3))
axis(in_bounds)
xlabel('t'); ylabel('x2(t)')
title('x2(t) = t*u(t)')

% odziv
subplot(2,3,5)
plot(tout,yout(:,4))
axis(out_bounds)
xlabel('t'); ylabel('y2(t)')
title('y2(t)')

% -------------- Linearna kombinacija ---------------

% pobuda
subplot(2,3,3)
plot(tout,yout(:,5))
axis(in_bounds);
xlabel('t'); ylabel('x(t)')
title('x(t) = x1(t) + x2(t)')

% odziv
subplot(2,3,6)
plot(tout,yout(:,6))
axis(out_bounds);
xlabel('t'); ylabel('y(t)')

if (yout(:,2) + yout(:,4) == yout(:, 6))
    title('y(t) == y1(t) + y2(t)')
else
    title('y(t) != y1(t) + y2(t)')
end

% ---------------------------------------------------