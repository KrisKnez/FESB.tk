% ---------------------------------------------------
% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]

in_bounds  = [-1, 5, 0, 6];     % shema za pobude
out_bounds = [-1, 5, 0, 10];    % shema za odzive

% ------------------- Step --------------------------

% pobuda
subplot(2,3,1)
stem(tout,yout(:,1))
axis(in_bounds)
xlabel('n'); ylabel('x1[n]')
title('x1[n] = u[n]')

% odziv
subplot(2,3,4)
stem(tout,yout(:,2))
axis(out_bounds)
xlabel('n'); ylabel('y1[n]')
title('y1[n]')

% ------------ Linearno rastuca pobuda --------------

% pobuda
subplot(2,3,2)
stem(tout,yout(:,3))
axis(in_bounds)
xlabel('n'); ylabel('x2[n]')
title('x2[n] = t*u[n]')

% odziv
subplot(2,3,5)
stem(tout,yout(:,4))
axis(out_bounds)
xlabel('n'); ylabel('y2[n]')
title('y2[n]')

% -------------- Linearna kombinacija ---------------

% pobuda
subplot(2,3,3)
stem(tout,yout(:,5))
axis(in_bounds);
xlabel('n'); ylabel('x[n]')
title('x[n] = x1[n] + x2[n]')

% odziv
subplot(2,3,6)
stem(tout,yout(:,6))
axis(out_bounds);
xlabel('n'); ylabel('y[n]')

if (yout(:,2) + yout(:,4) == yout(:, 6))
    title('y[n] == y1[n] + y2[n]')
else
    title('y[n] != y1[n] + y2[n]')
end

% ---------------------------------------------------