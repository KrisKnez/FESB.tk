
% Skripta koja crta grafove za ispitivanje stabilnosti sustava 
% y(t) = e^(3x(t)) + e^(-3 * t * x(t))
% Ispitivanje se provodi dovodjenjem step signala na ulaz

% ---------------------------------------------------
% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]

in_bounds  = [-1, 8, 0, 2];     % shema za pobudu
out_bounds = [-1, 8, 0, 40];    % shema za odziv

% ------------------- Step --------------------------

% pobuda
subplot(2,1,1)
plot(tout,yout(:,1))
axis(in_bounds)
xlabel('t'); ylabel('x(t)')
title('x(t) = u(t)')

% odziv
subplot(2,1,2)
plot(tout,yout(:,2))
axis(out_bounds)
xlabel('t'); ylabel('y(t)')
title('y(t)')

% ---------------------------------------------------