% ========================================================================
% racunanje prijenosne funkcije, njenih polova i nula 
% ========================================================================

% definiranje blokova
% -----------------------------------------------------------
G0_br = [4];    G0_naz = [1];
G1_br = [1];    G1_naz = [1 1];
G2_br = [1 0];  G2_naz = [1 0 2];
G3_br = [1];    G3_naz = [1 0 0];
H0_br = [4 2];  H0_naz = [1 2 1];
H1_br = [50];   H1_naz = [1];
H2_br = [1 2];  H2_naz = [1 0 14];

% povratna veza [1/s] i [50] ==> [L0]
% -----------------------------------------------------------
[L0_br, L0_naz] = feedback (G3_br, G3_naz, H1_br, H1_naz, 1);

% serijska veza [1/(s + 1)] i [s/(s^2 + 2)] ==> [S0]
% -----------------------------------------------------------
[S0_br, S0_naz] = series   (G1_br, G1_naz, G2_br, G2_naz);

% povratna veza [S0] i [(4s + 2)/(s^2 + 2s + 1)] ==> [L1]
% -----------------------------------------------------------
[L1_br, L1_naz] = feedback (S0_br, S0_naz, H0_br, H0_naz);

% serijska veza [L0] i [L1] ==> [S1]
% -----------------------------------------------------------
[S1_br, S1_naz] = series   (L0_br, L0_naz, L1_br, L1_naz);

% povratna veza [S1] i [(s + 2)/(s^2 + 14)] ==> [L2]
% -----------------------------------------------------------
[L2_br, L2_naz] = feedback (S1_br, S1_naz, H2_br, H2_naz);


% prijenosna funkcija {serijska veza [4] i [L2]}
% -----------------------------------------------------------
[W_br, W_naz]   = series   (G0_br, G0_naz, L2_br, L2_naz);

% a) ispis prijenosne funkcije
% -----------------------------------------------------------
printsys(W_br, W_naz)

% b) ispis polno-nultnog dijagrama
% -----------------------------------------------------------
pzmap(W_br, W_naz)

% c) ispis polova i nula
% -----------------------------------------------------------
roots(W_br)
roots(W_naz)