% ========================================================================
% racunanje polova i odziva sustava pomocu prijenosne funkcije
% -------------------------------------------------------------
% a) x(t) = t * u(t)
% b) x(t) = dirac(t)
% c) x(t) = 5 * sin(3t)
% ========================================================================

% definicija prijenosne funkcije
% -------------------------------
W_br=[1];   W_naz=[1 2 1 1];

% ispis polova sustava
% -------------------------------
roots(W_naz)

% a) x(t) = t * u(t)
% -------------------------------
figure(1)
step(W_br, W_naz)
title('Odziv sustava na step pobudu x(t) = u(t)')
xlabel('t')
ylabel('y(t)')

% b) x(t) = dirac(t)
% -------------------------------
figure(2)
impulse(W_br, W_naz)
title('Odziv sustava na dirac-ovu pobudu x(t) = \delta(t)')
xlabel('t')
ylabel('y(t)')

% c) x(t) = 5 * sin(3t)
% -------------------------------
t = 1:0.01:20;
figure(3)
lsim(W_br, W_naz, sin(3*t), t)
title('Odziv sustava na pobudu x(t) = 5 * sin(3t)')
xlabel('t(s)')
ylabel('y(t)')