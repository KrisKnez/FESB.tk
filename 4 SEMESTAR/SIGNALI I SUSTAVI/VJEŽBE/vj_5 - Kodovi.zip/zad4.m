% ========================================================================
% racunanje polova prijenosne funkcije
% ========================================================================

% definicija bloka direktne grane
% -----------------------------------
G_br = [1 1];   G_naz=[1 4 6 10];

% izracun prijenosne funkcije
% -----------------------------------
[W_br, W_naz] = cloop(G_br, G_naz);

% ispis prijenosne funkcije i polova
% -----------------------------------
printsys(W_br,W_naz)
roots(W_naz) 