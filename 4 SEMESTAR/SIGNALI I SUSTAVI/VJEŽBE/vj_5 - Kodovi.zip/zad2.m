% ========================================================================
% racunanje prijenosne funkcije
% ========================================================================

% prijenosna funkcija
% -----------------------------
br = [1];
naz = [10 0.5 1];

% vremenski interval
% -----------------------------
t = 1:0.1:200;

% za silu F = 5N
% -----------------------------
input = 5 * ones(1, length(t));
Ya = lsim(br, naz, input, t);

% za silu F = 3sin(t)
% -----------------------------
input = 3 * sin(t);
Yb = lsim(br, naz, input, t);

% ispis rezultata
% -----------------------------
subplot(2, 1, 1)
plot(t, Ya)
title('narinuta sila f(t) = 5N')
xlabel('t(s)')
ylabel('x(m)')

subplot(2, 1, 2)
plot(t, Yb)
title('narinuta sila f(t) = 3sin(t)')
xlabel('t(s)')
ylabel('x(m)')