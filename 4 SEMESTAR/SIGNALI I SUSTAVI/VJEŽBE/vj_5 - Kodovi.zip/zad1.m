% ========================================================================
% racunanje prijenosne funkcije
% ========================================================================

% definiranje blokova
% -----------------------------------------------------
br_G1 = [1];      naz_G1 = [1 1];
br_G2 = [1 -2];   naz_G2 = [1 10];

% izracun direktne grane {[G1] serijski sa [G2]} ==> G
% -----------------------------------------------------
[br_G, naz_G] = series(br_G1, naz_G1, br_G2, naz_G2);

% izracun prijenosne funkcije
% -----------------------------------------------------
[br_W, naz_W] = cloop(br_G, naz_G);

% ispis prijenosne funkcije
% -----------------------------------------------------
printsys(br_W, naz_W)

% ispis odziva na step signal
% -----------------------------------------------------
step(br_W, naz_W)

title('Odziv sustava na jedinicnu pobudu')
xlabel('t')
ylabel('y(t)')