% ------------------------------------------------------------------------
% Sustav je opisan diferencijalnom jednadzbom:
% y��(t) + y�(t) + 5y(t) = e^(-t)   y(0) = y�(0) = -1
% ------------------------------------------------------------------------

% defincije simbolickih varijabli
syms s t;

% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]
axis_bounds = [-3, 5, -4, 4];


% ------------------------------------------------------------------------
% Laplaceova transformacija glasi:
% Y(s) = -(s^2 + 3*s + 1)/((s + 1)*(s^2 + s + 5))
% ------------------------------------------------------------------------

Y = -(s^2 + 3*s + 1)/((s + 1)*(s^2 + s + 5));
y = ilaplace(Y);
hPlot = ezplot(y, [axis_bounds(1), axis_bounds(2)]);
set(hPlot, 'Color', 'red', 'LineWidth', 1)


% ------------------------------------------------------------------------
% uredi graf
% ------------------------------------------------------------------------

axis(axis_bounds)
ylabel('vremenski odziv: y(t)')
xlabel('vrijeme: t')
title('y��(t) + y�(t) + 5y(t) = e^{-t}   y(0) = y�(0) = -1')
grid on
