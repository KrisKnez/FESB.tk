% ------------------------------------------------------------------------
% Sustav je opisan diferencijalnom jednadzbom:
% y���(t) + y�(t) = x(t)
% ------------------------------------------------------------------------

% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]
axis_bounds = [0, 10, -10, 30];

% I. slucaj
% ------------------------------------------------------------------------
% x(t) = dirac(t)
% X(s) = 1
% ------------------------------------------------------------------------

hPlot = plot(tout, yout(:,2));
set(hPlot, 'Color', 'red', 'LineWidth', 1)


% II. slucaj
% ------------------------------------------------------------------------
% x(t) = u(t)
% X(s) = 1/s
% ------------------------------------------------------------------------

hold on;
hPlot = plot(tout, yout(:,4));
set(hPlot, 'Color', 'blue', 'LineWidth', 1)


% III. slucaj
% ------------------------------------------------------------------------
% x(t) = t
% X(s) = 1/s^2
% ------------------------------------------------------------------------

hold on;
hPlot = plot(tout, yout(:,6));
set(hPlot, 'Color', 'magenta', 'LineWidth', 1);


% IV. slucaj
% ------------------------------------------------------------------------
% x(t) = sin(t)
% X(s) = 1/(s^2 + 1)
% ------------------------------------------------------------------------

hold on;
hPlot = plot(tout, yout(:,8));
set(hPlot, 'Color', 'black', 'LineWidth', 1)


% ------------------------------------------------------------------------
% uredi graf
% ------------------------------------------------------------------------

axis(axis_bounds)
ylabel('vremenski odziv: y(t)')
xlabel('vrijeme: t')
title('Vremenski odzivi sustava y���(t) + y�(t) = x(t) na razlicite pobude')
legend('x(t) = \delta(t)', 'x(t) = u(t)', 'x(t) = t', 'x(t) = sin(t)')
legend('Location', 'NorthWest')
