% ------------------------------------------------------------------------
% Sustav je opisan diferencijalnom jednadzbom:
% y��(t) + 4y�(t) + 4y(t) = 3x(t)� + 2x(t)     uz x(t) = e^(-3t), a y(0) = y�(0) = 0
% ------------------------------------------------------------------------

% defincije simbolickih varijabli
syms s t;

% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]
axis_bounds = [0, 5, -0.4, 0.05];


% ------------------------------------------------------------------------
% Laplaceova transformacija glasi:
% Y(s) = -7/((s + 3) * (s + 2)^2)
% ------------------------------------------------------------------------

Y = -7/((s + 3) * (s + 2)^2);
y = ilaplace(Y);
hPlot = ezplot(y, [axis_bounds(1), axis_bounds(2)]);
set(hPlot, 'Color', 'red', 'LineWidth', 1)


% ------------------------------------------------------------------------
% uredi graf
% ------------------------------------------------------------------------

axis(axis_bounds)
ylabel('vremenski odziv: y(t)')
xlabel('vrijeme: t')
title('y��(t) + 4y�(t) + 4y(t) = 3x�(t) + 2x(t)   x(t) = e^{-3t}, y(0) = y�(0) = 0')
