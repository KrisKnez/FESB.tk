% ------------------------------------------------------------------------
% Sustav je opisan diferencijalnom jednadzbom:
% y��(t) + y�(t) + 5y(t) = e^(-t)   y(0) = y�(0) = -1
% ------------------------------------------------------------------------

% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]
axis_bounds = [-3, 5, -4, 4];

hPlot = plot(tout, yout(:,2));
set(hPlot, 'Color', 'red', 'LineWidth', 1)

% ------------------------------------------------------------------------
% uredi graf
% ------------------------------------------------------------------------

axis(axis_bounds)
ylabel('vremenski odziv: y(t)')
xlabel('vrijeme: t')
title('y��(t) + y�(t) + 5y(t) = e^{-t}   y(0) = y�(0) = -1')
grid on