% ------------------------------------------------------------------------
% Sustav je opisan diferencijalnom jednadzbom:
% y���(t) + y�(t) = x(t)
% ------------------------------------------------------------------------

% defincije simbolickih varijabli
syms s t;

% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]
axis_bounds = [0, 10, -10, 50];

% I. slucaj
% ------------------------------------------------------------------------
% x(t) = dirac(t)
% X(s) = 1
% ------------------------------------------------------------------------

Y1 = 1/(s^3 + s);
y1 = ilaplace(Y1);
hPlot = ezplot(y1, [axis_bounds(1),axis_bounds(2)]);
set(hPlot, 'Color', 'red', 'LineWidth', 1)


% II. slucaj
% ------------------------------------------------------------------------
% x(t) = u(t)
% X(s) = 1/s
% ------------------------------------------------------------------------

Y2 = 1/(s * (s^3 + s));
y2 = ilaplace(Y2);
hold on;
hPlot = ezplot(y2, [axis_bounds(1),axis_bounds(2)]);
set(hPlot, 'Color', 'blue', 'LineWidth', 1)


% III. slucaj
% ------------------------------------------------------------------------
% x(t) = t
% X(s) = 1/s^2
% ------------------------------------------------------------------------

Y3 = 1/(s^2 * (s^3 + s));
y3 = ilaplace(Y3);
hold on;
hPlot = ezplot(y3, [axis_bounds(1),axis_bounds(2)]);
set(hPlot, 'Color', 'magenta', 'LineWidth', 1);


% IV. slucaj
% ------------------------------------------------------------------------
% x(t) = sin(t)
% X(s) = 1/(s^2 + 1)
% ------------------------------------------------------------------------

Y4 = 1/((s^2 + 1) * (s^3 + s));
y4 = ilaplace(Y4);
hold on;
hPlot = ezplot(y4, [axis_bounds(1),axis_bounds(2)]);
set(hPlot, 'Color', 'black', 'LineWidth', 1)


% ------------------------------------------------------------------------
% uredi graf
% ------------------------------------------------------------------------

axis(axis_bounds)
ylabel('vremenski odziv: y(t)')
xlabel('vrijeme: t')
title('Vremenski odzivi sustava y���(t) + y�(t) = x(t) na razlicite pobude')
legend('x(t) = \delta(t)', 'x(t) = u(t)', 'x(t) = t', 'x(t) = sin(t)')
legend('Location', 'NorthWest')
