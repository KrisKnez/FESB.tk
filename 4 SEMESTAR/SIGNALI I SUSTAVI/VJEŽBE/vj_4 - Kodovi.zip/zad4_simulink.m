% ------------------------------------------------------------------------
% Sustav je opisan diferencijalnom jednadzbom:
% y��(t) + y(t) = 3x(t)   uz x(t) = dirac(t), a y(0) = y�(0) = 0
% ------------------------------------------------------------------------

% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]
axis_bounds = [-2, 18, -4, 4];

hPlot = plot(tout, yout(:,2));
set(hPlot, 'Color', 'red', 'LineWidth', 1)

% ------------------------------------------------------------------------
% uredi graf
% ------------------------------------------------------------------------

axis(axis_bounds)
ylabel('vremenski odziv: y(t)')
xlabel('vrijeme: t')
title('y��(t) + y(t) = 3x(t)   x(t) = \delta(t), y(0) = y�(0) = 0')
grid on
