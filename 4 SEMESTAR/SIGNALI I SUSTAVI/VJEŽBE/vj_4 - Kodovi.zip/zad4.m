% ------------------------------------------------------------------------
% Sustav je opisan diferencijalnom jednadzbom:
% y��(t) + y(t) = 3x(t)   uz x(t) = dirac(t), a y(0) = y�(0) = 0
% ------------------------------------------------------------------------

% defincije simbolickih varijabli
syms s t;

% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]
axis_bounds = [-2, 18, -4, 4];


% ------------------------------------------------------------------------
% Laplaceova transformacija glasi:
% Y(s) = 3/(s^2 + 1)
% ------------------------------------------------------------------------

Y = 3/(s^2 + 1);
y = ilaplace(Y);
hPlot = ezplot(y, [axis_bounds(1), axis_bounds(2)]);
set(hPlot, 'Color', 'red', 'LineWidth', 1)


% ------------------------------------------------------------------------
% uredi graf
% ------------------------------------------------------------------------

axis(axis_bounds)
ylabel('vremenski odziv: y(t)')
xlabel('vrijeme: t')
title('y��(t) + y(t) = 3x(t)   x(t) = \delta(t), y(0) = y�(0) = 0')
grid on
