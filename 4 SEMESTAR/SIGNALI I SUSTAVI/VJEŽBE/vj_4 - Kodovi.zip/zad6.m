% ------------------------------------------------------------------------
% Sustav je opisan diferencijalnom jednadzbom:
% y��(t) + y(t) - x�(t) = 0    x(t) = e^(-t), y(0) = y�(0) = 1
% ------------------------------------------------------------------------

% defincije simbolickih varijabli
syms s t;

% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]
axis_bounds = [-2, 18, -3, 3];


% ------------------------------------------------------------------------
% Laplaceova transformacija glasi:
% Y(s) = (s*(s + 6))/((s + 5)*(s^2 + 1))
% ------------------------------------------------------------------------

Y = (s*(s + 6))/((s + 5)*(s^2 + 1));
y = ilaplace(Y);
hPlot = ezplot(y, [axis_bounds(1),axis_bounds(2)]);
set(hPlot, 'Color', 'red', 'LineWidth', 1)


% ------------------------------------------------------------------------
% uredi graf
% ------------------------------------------------------------------------

axis(axis_bounds)
ylabel('vremenski odziv: y(t)')
xlabel('vrijeme: t')
title('y��(t) + y(t) - x�(t) = 0    x(t) = e^{-5t}, y(0) = y�(0) = 1')
grid on
