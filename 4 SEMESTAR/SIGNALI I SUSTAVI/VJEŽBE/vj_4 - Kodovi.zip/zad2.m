% ------------------------------------------------------------------------
% Sustav je opisan diferencijalnom jednadzbom:
% y��(t) + 3y�(t) + 2y(t) = 5e^(-4t)     uz y(0) = 1 i y�(0) = -2
% ------------------------------------------------------------------------

% defincije simbolickih varijabli
syms s t;

% definiranje minimuma i maksimuma koordinatnih osi
% [xMin, xMax, yMin, yMax]
axis_bounds = [0, 5, 0, 1.05];


% ------------------------------------------------------------------------
% Laplaceova transformacija glasi:
% Y(s) = (s^2 + 5s + 9)/((s + 1)*(s + 2)*(s + 4))
% ------------------------------------------------------------------------

Y = (s^2 + 5*s + 9)/((s + 1)*(s + 2)*(s + 4));
y = ilaplace(Y);
hPlot = ezplot(y, [axis_bounds(1), axis_bounds(2)]);
set(hPlot, 'Color', 'red', 'LineWidth', 1)


% ------------------------------------------------------------------------
% uredi graf
% ------------------------------------------------------------------------

axis(axis_bounds)
ylabel('vremenski odziv: y(t)')
xlabel('vrijeme: t')
title('y��(t) + 3y�(t) + 2y(t) = 5e^{-4t}   y(0) = 1 i y�(0) = -2')
