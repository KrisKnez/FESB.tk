clear all
T_br=[1]; T_naz=[1,2,1,1];
roots(T_naz)
%[R,P] = residue(T_br,T_naz)
step(T_br,T_naz)

figure(2)
impulse(T_br,T_naz)

t=0:0.01:50;
x=5*sin(3*t);
y=lsim(T_br,T_naz,x,t);
figure(3)
plot(t,x,'r',t,y)