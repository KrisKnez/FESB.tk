clear all
G1_br=[4]; G1_naz=[1];
G2_br=[1]; G2_naz=[1,1];
G3_br=[1,0]; G3_naz=[1,0,2];
G4_br=[1]; G4_naz=[1,0];
H1_br=[4,2]; H1_naz=[1,2,1];
H2_br=[50]; H2_naz=[1];
H3_br=[1,2]; H3_naz=[1,14];

[PV1_br,PV1_naz]=feedback(G4_br,G4_naz,H2_br,H2_naz,+1);
[SV1_br,SV1_naz]=series(G2_br,G2_naz,G3_br,G3_naz);

[PV2_br,PV2_naz]=feedback(SV1_br,SV1_naz,H1_br,H1_naz,-1);
[SV2_br,SV2_naz]=series(PV2_br,PV2_naz,PV1_br,PV1_naz);

[PV_br,PV_naz]=feedback(SV2_br,SV2_naz,H3_br,H3_naz,-1);
[W_br,W_naz]=series(G1_br,G1_naz,PV_br,PV_naz);
printsys(W_br,W_naz)

pzmap(W_br,W_naz)
roots(W_br)
roots(W_naz)