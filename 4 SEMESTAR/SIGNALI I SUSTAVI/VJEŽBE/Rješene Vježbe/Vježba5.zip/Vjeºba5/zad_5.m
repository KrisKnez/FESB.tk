clear all
G_br=[1,1]; G_naz=[1,4,6,10];
[W_br,W_naz]=cloop(G_br,G_naz);
printsys(W_br,W_naz)
roots(W_naz)