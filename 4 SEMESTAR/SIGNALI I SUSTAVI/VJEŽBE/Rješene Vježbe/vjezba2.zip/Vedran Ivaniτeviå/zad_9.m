clear all
n=0:30;
m=[1,5/2,6,8];

for i=1:4
   x=cos((2*pi*m(i)*n)/7);
   subplot(4,1,i);
   stem(n,x);
end


