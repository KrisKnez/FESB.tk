clear all
n=-20:20;
x1=5*sin((pi*n)/8);
stem(n,x1);
xlabel('n');
ylabel('x1[n]');

