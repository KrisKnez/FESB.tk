clear all
t=-pi:0.01:pi;
x2=abs(exp(j*4*t)+exp(j*11*t));
plot(t,x2);
xlabel('t');
ylabel('x2(t)');

