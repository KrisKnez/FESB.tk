clear all
t=-3:0.01:7;
a=x3(t);
b=x3(t-3);
c=x3(-t);
d=x3(t/3);

subplot(4,1,1);
plot(t,a); title('Originalni signal');
subplot(4,1,2);
plot(t,b); title('Pomak');
subplot(4,1,3);
plot(t,c); title('Obrtanje');
subplot(4,1,4);
plot(t,d); title('Skaliranje');