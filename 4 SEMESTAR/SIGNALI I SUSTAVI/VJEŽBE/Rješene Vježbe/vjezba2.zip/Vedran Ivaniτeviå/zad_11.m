clear all
n=0:40;
x1=2*sin(((3*pi*n)/4)+1/3);
x2=1.5*cos(n/7+pi/5);
x3=cos((pi*n)/4).*cos((pi*n)/8);
x4=3*cos((pi*n)/8)+2*sin((pi*n)/2)-4*sin((pi*n)/4);

subplot(4,1,1);
stem(n,x1);
subplot(4,1,2);
stem(n,x2);
subplot(4,1,3);
stem(n,x3);
subplot(4,1,4);
stem(n,x4);