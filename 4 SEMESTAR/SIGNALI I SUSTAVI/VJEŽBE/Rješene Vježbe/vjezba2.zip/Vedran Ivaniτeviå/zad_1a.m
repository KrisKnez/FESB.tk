clear all
t=-3*pi:0.01:3*pi;
x1=2*cos(3*t)+3*sin(2*t);
plot(t,x1);
xlabel('t');
ylabel('x1(t)');