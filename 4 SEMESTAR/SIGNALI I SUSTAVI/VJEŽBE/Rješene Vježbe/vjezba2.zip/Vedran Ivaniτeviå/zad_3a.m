clear all
syms t;
ezplot(2*cos(3*t)+3*sin(2*t),[-3*pi,3*pi]);