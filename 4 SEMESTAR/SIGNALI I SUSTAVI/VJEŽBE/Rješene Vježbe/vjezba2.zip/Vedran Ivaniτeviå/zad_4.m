clear all
t=-3:0.01:4;
plot(t,x1(t));
figure(2);
plot(t,x2(t));
figure(3);
plot(t,x3(t));
