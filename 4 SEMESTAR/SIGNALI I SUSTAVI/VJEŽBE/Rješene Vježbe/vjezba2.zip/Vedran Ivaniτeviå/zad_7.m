clear all
t=-3:0.01:4;
a=x2(t);
b=x2(-3*t+2.5);

subplot(2,1,1);
plot(t,a); title('Originalni signal');
subplot(2,1,2);
plot(t,b); title('Signal s transformiranom vremenskom varijablom');
