clear all
n=-20:20;
x3=d(n+3)+2*d(n+1)-4*d(n)+d(n-2)-6*d(n-4)+5*d(n-5);
stem(n,x3);
xlabel('n');
ylabel('x3[n]');
