clear all
n=-20:20;
subplot(4,1,1);
stem(n,x3n(n));
subplot(4,1,2);
stem(n,x3n(-n-5));
subplot(4,1,3);
stem(n,x3n(2*n+8));
subplot(4,1,4);
stem(n,x3n((n/3)-2));
