function y=x1(t)
for i=1:length(t)
	y(i)=0;
	if t(i)>=0
		y(i)=1;
	end
end