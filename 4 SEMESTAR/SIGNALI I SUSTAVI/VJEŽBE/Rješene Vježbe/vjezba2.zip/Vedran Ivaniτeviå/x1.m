function y=x1(t)
for i=1:length(t)
	y(i)=0;
	if (t(i)>=0)&(t(i)<1)
		y(i)=t(i);
	end
	if (t(i)>=1)&(t(i)<2)
		y(i)=-t(i)+2;
	end
end