clear all
t=-5:0.01:5;
K=[1 3 6];
for i=1:3
    x=cos(((3*pi*t)/K(i))-(pi/4)).^2;
    subplot(3,1,i);
    plot(t,x);
end