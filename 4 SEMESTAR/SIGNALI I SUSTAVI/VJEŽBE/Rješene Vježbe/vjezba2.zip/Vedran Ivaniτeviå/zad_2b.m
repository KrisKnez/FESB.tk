clear all
n=-20:20;
x2=u(n);
stem(n,x2);
xlabel('n');
ylabel('x2[n]');
