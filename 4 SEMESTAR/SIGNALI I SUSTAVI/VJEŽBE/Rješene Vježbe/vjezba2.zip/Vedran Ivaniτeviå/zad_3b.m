clear all
syms t;
x=t*cos(t);
y=t*sin(t);
ezplot(x,y,[0,10*pi]);