clear all
t=-3:0.01:4;
par1=0.5*(x1(t)+x1(-t));
nep1=0.5*(x1(t)-x1(-t));

subplot(3,1,1);
plot(t,x1(t));
subplot(3,1,2);
plot(t,par1);
subplot(3,1,3);
plot(t,nep1);

figure(2);
par2=0.5*(x2(t)+x2(-t));
nep2=0.5*(x2(t)-x2(-t));

subplot(3,1,1);
plot(t,x2(t));
subplot(3,1,2);
plot(t,par2);
subplot(3,1,3);
plot(t,nep2);

figure(3);
par3=0.5*(x3(t)+x3(-t));
nep3=0.5*(x3(t)-x3(-t));

subplot(3,1,1);
plot(t,x3(t));
subplot(3,1,2);
plot(t,par3);
subplot(3,1,3);
plot(t,nep3);