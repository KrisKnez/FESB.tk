function y=x(n)
for i=1:length(n)
	y=d(n+3)+2*d(n+1)-4*d(n)+d(n-2)-6*d(n-4)+5*d(n-5);
end