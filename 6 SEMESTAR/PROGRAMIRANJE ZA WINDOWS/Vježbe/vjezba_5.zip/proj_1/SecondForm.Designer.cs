﻿/*
 * Created by SharpDevelop.
 * User: Dario
 * Date: 10.5.2011
 * Time: 17:21
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace proj_1
{
	partial class SecondForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.Button buttonCopy2b;
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SecondForm));
			this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
			this.comboBox2 = new System.Windows.Forms.ComboBox();
			this.buttonCopy2a = new System.Windows.Forms.Button();
			this.richTextBox2 = new System.Windows.Forms.RichTextBox();
			this.toolTip = new System.Windows.Forms.ToolTip(this.components);
			buttonCopy2b = new System.Windows.Forms.Button();
			this.tableLayoutPanel.SuspendLayout();
			this.SuspendLayout();
			// 
			// buttonCopy2b
			// 
			buttonCopy2b.Location = new System.Drawing.Point(137, 124);
			buttonCopy2b.Name = "buttonCopy2b";
			buttonCopy2b.Size = new System.Drawing.Size(128, 23);
			buttonCopy2b.TabIndex = 1;
			buttonCopy2b.Text = "Action 2";
			this.toolTip.SetToolTip(buttonCopy2b, "Copy RTF content to ListBox at 1st form");
			buttonCopy2b.UseVisualStyleBackColor = true;
			buttonCopy2b.Click += new System.EventHandler(this.ButtonCopy2bClick);
			// 
			// tableLayoutPanel
			// 
			this.tableLayoutPanel.ColumnCount = 2;
			this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel.Controls.Add(this.comboBox2, 0, 0);
			this.tableLayoutPanel.Controls.Add(this.buttonCopy2a, 1, 0);
			this.tableLayoutPanel.Controls.Add(this.richTextBox2, 0, 1);
			this.tableLayoutPanel.Controls.Add(buttonCopy2b, 1, 1);
			this.tableLayoutPanel.Location = new System.Drawing.Point(12, 12);
			this.tableLayoutPanel.Name = "tableLayoutPanel";
			this.tableLayoutPanel.RowCount = 2;
			this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel.Size = new System.Drawing.Size(268, 242);
			this.tableLayoutPanel.TabIndex = 1;
			// 
			// comboBox2
			// 
			this.comboBox2.FormattingEnabled = true;
			this.comboBox2.Location = new System.Drawing.Point(3, 3);
			this.comboBox2.Name = "comboBox2";
			this.comboBox2.Size = new System.Drawing.Size(128, 21);
			this.comboBox2.TabIndex = 0;
			this.toolTip.SetToolTip(this.comboBox2, "ComboBox");
			// 
			// buttonCopy2a
			// 
			this.buttonCopy2a.Location = new System.Drawing.Point(137, 3);
			this.buttonCopy2a.Name = "buttonCopy2a";
			this.buttonCopy2a.Size = new System.Drawing.Size(128, 23);
			this.buttonCopy2a.TabIndex = 1;
			this.buttonCopy2a.Text = "Action 1";
			this.toolTip.SetToolTip(this.buttonCopy2a, "Copy ComboBox content of 1st form to this one");
			this.buttonCopy2a.UseVisualStyleBackColor = true;
			this.buttonCopy2a.Click += new System.EventHandler(this.ButtonCopy2aClick);
			// 
			// richTextBox2
			// 
			this.richTextBox2.Location = new System.Drawing.Point(3, 124);
			this.richTextBox2.Name = "richTextBox2";
			this.richTextBox2.Size = new System.Drawing.Size(128, 115);
			this.richTextBox2.TabIndex = 2;
			this.richTextBox2.Text = "";
			this.toolTip.SetToolTip(this.richTextBox2, "RTF TextEdit");
			// 
			// SecondForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.Add(this.tableLayoutPanel);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "SecondForm";
			this.Text = "ListBox Example [2]";
			this.tableLayoutPanel.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.ToolTip toolTip;
		private System.Windows.Forms.RichTextBox richTextBox2;
		private System.Windows.Forms.Button buttonCopy2a;
		private System.Windows.Forms.ComboBox comboBox2;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
	}
}
