﻿/*
 * Created by SharpDevelop.
 * User: Dario
 * Date: 10.5.2011
 * Time: 16:53
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace proj_1
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void ButtonAddClick(object sender, EventArgs e) {
			if (textBox.Text.Length > 0) {
				listBox.Items.Add(textBox.Text);
				textBox.Text = "";
				textBox.Focus();
			}
		}
		
		void CloseApplicationToolStripMenuItemClick(object sender, EventArgs e) {
			Application.Exit();
		}
		
		void ListAllItemsToolStripMenuItemClick(object sender, EventArgs e) {
			string listBoxContent = "";
			foreach (string line in listBox.Items) {
				if (line.Length > 0)
					listBoxContent += "- " + line + "\n";
			}
			MessageBox.Show(listBoxContent, "ListBox Content:", 
			                MessageBoxButtons.OK,
			                MessageBoxIcon.Information);
		}
		
		void ButtonCopyClick(object sender, EventArgs e){
			comboBox.Items.Clear();
			foreach (string line in listBox.Items) {
				if (line.Length > 0)
					comboBox.Items.Add(line);
			}
		}
		
		void ButtonOpenNextFormClick(object sender, EventArgs e) {
			Program.AppSecondForm = new SecondForm();
			Program.AppSecondForm.Show();
		}
		
		void ButtonOpenNextFormModalClick(object sender, EventArgs e) {
			Program.AppSecondForm = new SecondForm();
			Program.AppSecondForm.ShowDialog();
		}
	}
}