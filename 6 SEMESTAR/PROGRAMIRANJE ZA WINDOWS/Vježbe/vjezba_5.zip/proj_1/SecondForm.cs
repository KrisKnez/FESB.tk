﻿/*
 * Created by SharpDevelop.
 * User: Dario
 * Date: 10.5.2011
 * Time: 17:21
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace proj_1
{
	/// <summary>
	/// Description of SecondForm.
	/// </summary>
	public partial class SecondForm : Form
	{
		public SecondForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void ButtonCopy2aClick(object sender, EventArgs e) {
			foreach (string line in proj_1.Program.AppMainForm.comboBox.Items) {
				if (line.Length > 0)
					comboBox2.Items.Add(line);
			}
		}
		
		void ButtonCopy2bClick(object sender, EventArgs e) {
			foreach (string line in richTextBox2.Lines) {
				if (line.Length > 0)
					proj_1.Program.AppMainForm.listBox.Items.Add(line);
			}
		}
	}
}
