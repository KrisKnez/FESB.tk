﻿/*
 * Created by SharpDevelop.
 * User: Dario
 * Date: 10.5.2011
 * Time: 16:53
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace proj_1
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.textBox = new System.Windows.Forms.TextBox();
			this.listBox = new System.Windows.Forms.ListBox();
			this.buttonAdd = new System.Windows.Forms.Button();
			this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
			this.trayContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.closeApplicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.listAllItemsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.comboBox = new System.Windows.Forms.ComboBox();
			this.buttonCopy = new System.Windows.Forms.Button();
			this.buttonOpenNextForm = new System.Windows.Forms.Button();
			this.buttonOpenNextFormModal = new System.Windows.Forms.Button();
			this.trayContextMenu.SuspendLayout();
			this.SuspendLayout();
			// 
			// textBox
			// 
			this.textBox.Location = new System.Drawing.Point(12, 12);
			this.textBox.Name = "textBox";
			this.textBox.Size = new System.Drawing.Size(178, 20);
			this.textBox.TabIndex = 0;
			// 
			// listBox
			// 
			this.listBox.FormattingEnabled = true;
			this.listBox.Location = new System.Drawing.Point(12, 42);
			this.listBox.Name = "listBox";
			this.listBox.Size = new System.Drawing.Size(268, 173);
			this.listBox.TabIndex = 1;
			// 
			// buttonAdd
			// 
			this.buttonAdd.Location = new System.Drawing.Point(196, 10);
			this.buttonAdd.Name = "buttonAdd";
			this.buttonAdd.Size = new System.Drawing.Size(84, 23);
			this.buttonAdd.TabIndex = 2;
			this.buttonAdd.Text = "Add2List";
			this.buttonAdd.UseVisualStyleBackColor = true;
			this.buttonAdd.Click += new System.EventHandler(this.ButtonAddClick);
			// 
			// notifyIcon
			// 
			this.notifyIcon.ContextMenuStrip = this.trayContextMenu;
			this.notifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon.Icon")));
			this.notifyIcon.Text = "ListBox Example";
			this.notifyIcon.Visible = true;
			// 
			// trayContextMenu
			// 
			this.trayContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.closeApplicationToolStripMenuItem,
									this.listAllItemsToolStripMenuItem});
			this.trayContextMenu.Name = "trayContextMenu";
			this.trayContextMenu.Size = new System.Drawing.Size(167, 70);
			// 
			// closeApplicationToolStripMenuItem
			// 
			this.closeApplicationToolStripMenuItem.Name = "closeApplicationToolStripMenuItem";
			this.closeApplicationToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.closeApplicationToolStripMenuItem.Text = "Close Application";
			this.closeApplicationToolStripMenuItem.Click += new System.EventHandler(this.CloseApplicationToolStripMenuItemClick);
			// 
			// listAllItemsToolStripMenuItem
			// 
			this.listAllItemsToolStripMenuItem.Name = "listAllItemsToolStripMenuItem";
			this.listAllItemsToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.listAllItemsToolStripMenuItem.Text = "List All Items...";
			this.listAllItemsToolStripMenuItem.Click += new System.EventHandler(this.ListAllItemsToolStripMenuItemClick);
			// 
			// comboBox
			// 
			this.comboBox.FormattingEnabled = true;
			this.comboBox.Location = new System.Drawing.Point(13, 233);
			this.comboBox.Name = "comboBox";
			this.comboBox.Size = new System.Drawing.Size(177, 21);
			this.comboBox.TabIndex = 3;
			// 
			// buttonCopy
			// 
			this.buttonCopy.Location = new System.Drawing.Point(196, 231);
			this.buttonCopy.Name = "buttonCopy";
			this.buttonCopy.Size = new System.Drawing.Size(84, 23);
			this.buttonCopy.TabIndex = 4;
			this.buttonCopy.Text = "List2Combo";
			this.buttonCopy.UseVisualStyleBackColor = true;
			this.buttonCopy.Click += new System.EventHandler(this.ButtonCopyClick);
			// 
			// buttonOpenNextForm
			// 
			this.buttonOpenNextForm.Location = new System.Drawing.Point(13, 267);
			this.buttonOpenNextForm.Name = "buttonOpenNextForm";
			this.buttonOpenNextForm.Size = new System.Drawing.Size(267, 23);
			this.buttonOpenNextForm.TabIndex = 5;
			this.buttonOpenNextForm.Text = "Activate Next Form";
			this.buttonOpenNextForm.UseVisualStyleBackColor = true;
			this.buttonOpenNextForm.Click += new System.EventHandler(this.ButtonOpenNextFormClick);
			// 
			// buttonOpenNextFormModal
			// 
			this.buttonOpenNextFormModal.Location = new System.Drawing.Point(13, 296);
			this.buttonOpenNextFormModal.Name = "buttonOpenNextFormModal";
			this.buttonOpenNextFormModal.Size = new System.Drawing.Size(267, 23);
			this.buttonOpenNextFormModal.TabIndex = 6;
			this.buttonOpenNextFormModal.Text = "Activate Next Form (modal)";
			this.buttonOpenNextFormModal.UseVisualStyleBackColor = true;
			this.buttonOpenNextFormModal.Click += new System.EventHandler(this.ButtonOpenNextFormModalClick);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(292, 328);
			this.Controls.Add(this.buttonOpenNextFormModal);
			this.Controls.Add(this.buttonOpenNextForm);
			this.Controls.Add(this.buttonCopy);
			this.Controls.Add(this.comboBox);
			this.Controls.Add(this.buttonAdd);
			this.Controls.Add(this.listBox);
			this.Controls.Add(this.textBox);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "MainForm";
			this.Text = "ListBox Example";
			this.trayContextMenu.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Button buttonOpenNextFormModal;
		private System.Windows.Forms.Button buttonOpenNextForm;
		private System.Windows.Forms.Button buttonCopy;
		public System.Windows.Forms.ComboBox comboBox;
		private System.Windows.Forms.NotifyIcon notifyIcon;
		private System.Windows.Forms.ToolStripMenuItem listAllItemsToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem closeApplicationToolStripMenuItem;
		private System.Windows.Forms.ContextMenuStrip trayContextMenu;
		private System.Windows.Forms.Button buttonAdd;
		public System.Windows.Forms.ListBox listBox;
		private System.Windows.Forms.TextBox textBox;
	}
}
