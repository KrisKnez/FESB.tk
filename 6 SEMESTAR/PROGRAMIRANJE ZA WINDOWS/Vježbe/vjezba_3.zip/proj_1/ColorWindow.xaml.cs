﻿/*
 * Created by SharpDevelop.
 * User: Dario
 * Date: 25.4.2011
 * Time: 15:19
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.ComponentModel;

namespace proj_1
{
	public partial class CColorWindow : Window {
	
		Brush[] BgColorSet     = { Brushes.Blue, Brushes.Yellow, Brushes.Green };
		int     CurrentBgColor = 0;
	
		public CColorWindow() {
			InitializeComponent();
		}
		
		void BtnColorChanger_Click(object sender, RoutedEventArgs e) {
			CurrentBgColor = ++CurrentBgColor % BgColorSet.Length;
			Background     = BgColorSet[CurrentBgColor];
		}
		
		void ColorWindow_Closing(object sender, EventArgs e) {
			MessageBoxResult UserDecision = MessageBox.Show("Exit Color Window?", "Confirm Exit", 
			                                                MessageBoxButton.OKCancel, MessageBoxImage.Question, 
			                                                MessageBoxResult.Cancel);
			                                                 
			if (UserDecision == MessageBoxResult.Cancel)
				(e as CancelEventArgs).Cancel = true;
		}
	}
}