﻿/*
 * Created by SharpDevelop.
 * User: Dario
 * Date: 04/12/2011
 * Time: 19:05
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace proj_3
{
	delegate int sumDelegate(int a, int b);
	
	static class PersonalInfo {
		static string myName = "Dario";
		
		public static string getName() {
			return myName;
		}
	}
	
	class TextContainer {
		protected string content;
		
	 	public void   setContent(string _content) { content = _content; }
		public string getContent()                { return content; }
	}
	
	class Program
	{
		static bool   tBool   = false;
		static char   tChar   = 'a';
		static int    tInt    = 32;
		static float  tFloat  = 3.14F;
		static double tDouble = System.Math.PI;
		
		public static int Sum(int a, int b) {
			return a + b;
		}
		
		public static void Main(string[] args) {	
			Console.WriteLine("My name is {0}!", PersonalInfo.getName());
			Console.WriteLine();
			
			Console.WriteLine("========= Primitive Data Types =========");
			Console.WriteLine("bool   {0}", tBool);
			Console.WriteLine("char   {0}", tChar);
			Console.WriteLine("int    {0}", tInt);
			Console.WriteLine("float  {0}", tFloat);
			Console.WriteLine("double {0}", tDouble);
			Console.WriteLine();
			
			int num1 = 0;
			int num2 = 0;
			sumDelegate mySumDelegate = Sum;
			
			Console.Write("Enter 1st number: "); num1 = int.Parse(Console.ReadLine());
			Console.Write("Enter 2nd number: "); num2 = int.Parse(Console.ReadLine());
			Console.WriteLine("Result: {0} + {1} = {2}", num1, num2, mySumDelegate(num1, num2));
			Console.WriteLine();
			
			TextContainer myTxtContainer = new TextContainer();
			Console.Write("Enter text to store: "); myTxtContainer.setContent(Console.ReadLine());
			Console.WriteLine("Stored text: {0}", myTxtContainer.getContent());
			Console.WriteLine();
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}