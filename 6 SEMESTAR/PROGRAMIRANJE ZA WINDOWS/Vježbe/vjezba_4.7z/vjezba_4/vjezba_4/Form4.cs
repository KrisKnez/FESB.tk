﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace vjezba_4
{
    public partial class Form4 : Form
    {
       private bool first = true;
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_MouseHover(object sender, EventArgs e)
        {
            if(first == true)
                Form1.Upozorenje.poruka();
            first = false;
        }
    }
}
