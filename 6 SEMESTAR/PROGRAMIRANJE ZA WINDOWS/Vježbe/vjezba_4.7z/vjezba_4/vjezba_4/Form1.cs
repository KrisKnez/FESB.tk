﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace vjezba_4
{
    public partial class Form1 : Form
    {
        private bool first = true;
        public static class Upozorenje
        {
            public static void poruka()
            {
               MessageBox.Show("Mijenja se ikona !");
            }
        }
        
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_MouseHover_1(object sender, EventArgs e)
        {
            if (first == true)
                Form1.Upozorenje.poruka();
            first = false;
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            System.Drawing.Icon ico = new System.Drawing.Icon("..\\..\\Resources\\Icon2.ico");
            this.Icon = ico;
        }
    }
}
