﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Threading;
namespace vjezba_4
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {


            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);


            Thread t = new Thread(delegate()
            {
                Application.Run(new Form1());
            });
            t.Start();

            Thread t1 = new Thread(delegate()
                {
                    Application.Run(new Form2());
                });
            t1.Start();

            Thread t2 = new Thread(delegate()
            {
                Application.Run(new Form3());
            });
            t2.Start();

            Thread t3 = new Thread(delegate()
            {
                Application.Run(new Form4());
            });
            t3.Start();

        }

    }
}
