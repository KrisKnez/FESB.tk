﻿/*
 * Created by SharpDevelop.
 * User: Dario
 * Date: 12.4.2011
 * Time: 21:57
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace proj_1
{
	public partial class SecondForm : Form
	{	
		public SecondForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
		
		public event EventHandler myEvent;
		
		void OnEventTriggerClick(object sender, EventArgs e) {
			myEvent(sender, e);
		}
	}
}
