﻿/*
 * Created by SharpDevelop.
 * User: Dario
 * Date: 12.4.2011
 * Time: 21:54
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace proj_1
{
	partial class FirstForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnOpenForm = new System.Windows.Forms.Button();
			this.btnMoveForm = new System.Windows.Forms.Button();
			this.btnInitProp = new System.Windows.Forms.Button();
			this.btnShowProp = new System.Windows.Forms.Button();
			this.btnOpenFormDel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnOpenForm
			// 
			this.btnOpenForm.Location = new System.Drawing.Point(12, 12);
			this.btnOpenForm.Name = "btnOpenForm";
			this.btnOpenForm.Size = new System.Drawing.Size(104, 23);
			this.btnOpenForm.TabIndex = 0;
			this.btnOpenForm.Text = "Open 2nd Form";
			this.btnOpenForm.UseVisualStyleBackColor = true;
			this.btnOpenForm.Click += new System.EventHandler(this.OnBtnClick);
			// 
			// btnMoveForm
			// 
			this.btnMoveForm.Location = new System.Drawing.Point(12, 86);
			this.btnMoveForm.Name = "btnMoveForm";
			this.btnMoveForm.Size = new System.Drawing.Size(104, 23);
			this.btnMoveForm.TabIndex = 1;
			this.btnMoveForm.Text = "Move Form";
			this.btnMoveForm.UseVisualStyleBackColor = true;
			this.btnMoveForm.Click += new System.EventHandler(this.OnBtnClick);
			// 
			// btnInitProp
			// 
			this.btnInitProp.Location = new System.Drawing.Point(122, 57);
			this.btnInitProp.Name = "btnInitProp";
			this.btnInitProp.Size = new System.Drawing.Size(146, 23);
			this.btnInitProp.TabIndex = 2;
			this.btnInitProp.Text = "Initialize Form Property";
			this.btnInitProp.UseVisualStyleBackColor = true;
			this.btnInitProp.Click += new System.EventHandler(this.OnBtnClick);
			// 
			// btnShowProp
			// 
			this.btnShowProp.Location = new System.Drawing.Point(122, 86);
			this.btnShowProp.Name = "btnShowProp";
			this.btnShowProp.Size = new System.Drawing.Size(146, 23);
			this.btnShowProp.TabIndex = 3;
			this.btnShowProp.Text = "Show Property Value";
			this.btnShowProp.UseVisualStyleBackColor = true;
			this.btnShowProp.Click += new System.EventHandler(this.OnBtnClick);
			// 
			// btnOpenFormDel
			// 
			this.btnOpenFormDel.Location = new System.Drawing.Point(122, 12);
			this.btnOpenFormDel.Name = "btnOpenFormDel";
			this.btnOpenFormDel.Size = new System.Drawing.Size(146, 23);
			this.btnOpenFormDel.TabIndex = 4;
			this.btnOpenFormDel.Text = "Open 2nd Form Delegated";
			this.btnOpenFormDel.UseVisualStyleBackColor = true;
			this.btnOpenFormDel.Click += new System.EventHandler(this.OnBtnClick);
			// 
			// FirstForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(280, 121);
			this.Controls.Add(this.btnOpenFormDel);
			this.Controls.Add(this.btnShowProp);
			this.Controls.Add(this.btnInitProp);
			this.Controls.Add(this.btnMoveForm);
			this.Controls.Add(this.btnOpenForm);
			this.Name = "FirstForm";
			this.Text = "1st Form ...";
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button btnOpenFormDel;
		private System.Windows.Forms.Button btnShowProp;
		private System.Windows.Forms.Button btnInitProp;
		private System.Windows.Forms.Button btnMoveForm;
		private System.Windows.Forms.Button btnOpenForm;
	}
}
