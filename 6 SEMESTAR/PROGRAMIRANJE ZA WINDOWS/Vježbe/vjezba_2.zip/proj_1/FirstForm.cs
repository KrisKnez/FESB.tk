﻿/*
 * Created by SharpDevelop.
 * User: Dario
 * Date: 12.4.2011
 * Time: 21:54
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace proj_1
{
	delegate void OpenFormDelegate();
	
	public partial class FirstForm : Form
	{
		SecondForm nextForm = new SecondForm();
	 	OpenFormDelegate OpenNextFormDC;
		
		void OpenNextForm() {
			if(nextForm.IsDisposed) {
				nextForm          = new SecondForm();
				nextForm.myEvent += new EventHandler(this.OnSecondFormBtnClick);
			}
			nextForm.Show();
		}
		
		public FirstForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			nextForm.myEvent += new EventHandler(this.OnSecondFormBtnClick);
			OpenNextFormDC    = OpenNextForm;
		}
		
		private string txtStorage = null;
		public  string myData {
			get {
				return txtStorage;
			}
			set {
				txtStorage = value.ToString();
			}
		}
		
		void OnBtnClick(object sender, EventArgs e)
		{
			// open new form
			if ((sender as Button) == btnOpenForm) {
				OpenNextForm();
			}
			
			// open new form through delegated call
			if ((sender as Button) == btnOpenFormDel) {
				OpenNextFormDC();
			}
			
			// move current form
			if ((sender as Button) == btnMoveForm) {
				this.Location = new Point(this.Location.X + 10, this.Location.Y + 10);
				this.Update();
			}
			
			// assign form property
			if ((sender as Button) == btnInitProp) {
				this.myData = "NOVO SVOJSTVO";
			}
			
			// show property value
			if ((sender as Button) == btnShowProp) {
				MessageBox.Show("\"" + this.myData + "\"", "Content of [myData]:",
				                MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
		}
		
		void OnSecondFormBtnClick(object sender, EventArgs e) {
			MessageBox.Show("Received event from second form!", "Event triggered...",
			                MessageBoxButtons.OK, MessageBoxIcon.Information);
		}
	}
}
